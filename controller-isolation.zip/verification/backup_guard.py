"""ISOLATION ONLY: legacy first-backup controller, not a production entrypoint.

Requires old worker exited and external operator writes stopped. Advisory locks
cannot protect against arbitrary same-UID file operations. A crash deliberately
leaves a persistent marker; legacy uncooperative writers remain a known gap.
"""
import os
import sqlite3
from pathlib import Path
from contextlib import ExitStack, contextmanager
import maintenance

@contextmanager
def guard(root, timeout=120):
    if not 0 < timeout <= 120:
        raise ValueError('maximum drain budget is 120 seconds')
    root = Path(root)
    with ExitStack() as stack:
        stack.enter_context(maintenance.file_lock(root/'controller.lock', exclusive=True))
        # This controller is AFTER old exit, not a way to drain a live worker.
        stack.enter_context(maintenance.file_lock(root/'worker.lock', exclusive=True))
        marker = root/'maintenance.pending'
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT, 0o600)
        with os.fdopen(fd, 'wb') as f:
            f.write(b'first-backup-closed-v1\n'); f.flush(); os.fsync(f.fileno())
        directory = os.open(root, os.O_RDONLY)
        try: os.fsync(directory)
        finally: os.close(directory)
        stack.enter_context(maintenance.file_lock(root/'maintenance.lock', exclusive=True, timeout=timeout))
        stack.enter_context(maintenance.file_lock(root/'io.lock', exclusive=True, timeout=0))
        import public_backup
        names = public_backup.FILES | {n for n in public_backup.OPTIONAL_FILES if n.endswith('.sqlite3') and (root/n).exists()}
        for name in sorted(names):
            db = sqlite3.connect((root/name).resolve().as_uri()+'?mode=rw', uri=True, timeout=0)
            stack.callback(db.close)
            db.execute('BEGIN IMMEDIATE')
        yield
        # Keep marker even on success; only explicit verified handover reopens.
