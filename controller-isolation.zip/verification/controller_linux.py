"""Targeted synthetic controller evidence, including expected negative cases."""
import os,sys,time,json,sqlite3,tempfile,subprocess,ast
from pathlib import Path
BASE=Path(__file__).parent
sys.path.insert(0,str(BASE/'legacy'))
sys.path.append(str(BASE/'candidate'))
import backend,hosting,maintenance,public_backup
from backup_guard import guard
class K:
    def context(self,q):return {'question':q,'rules':[{'id':'synthetic'}],'reference_cases':[]}
backend.Knowledge=K
backend.PAID_CALLS_APPROVED=False
def deny(*a,**k):raise AssertionError('no AI allowed')
backend.live_request=deny

def snapshot(root):
    out={}
    for name in sorted(public_backup.FILES):
        db=sqlite3.connect((root/name).as_uri()+'?mode=ro',uri=True)
        try:
            assert db.execute('pragma integrity_check').fetchone()[0]=='ok'
            out[name]={n:db.execute('SELECT * FROM "'+n+'" ORDER BY rowid').fetchall() for n, in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        finally:db.close()
    return out

def probe(root,kind):
    try:
        if kind in ('worker','admin'):
            with maintenance.file_lock(root/('worker.lock' if kind=='worker' else 'io.lock'),exclusive=True):pass
        elif kind=='cooperating':
            with maintenance.writer(root):pass
        elif kind=='raw':
            db=sqlite3.connect(root/'access/access.sqlite3',timeout=.1)
            try:db.execute('CREATE TABLE IF NOT EXISTS isolated_probe(value TEXT)');db.commit()
            finally:db.close()
        elif kind=='service':
            svc=backend.Service(str(root/'records/consultations.sqlite3'),'locked');svc.db.close()
        elif kind=='cleanup':
            from handoff_events import HandoffEvents
            e=HandoffEvents.__new__(HandoffEvents)
            import threading
            e.lock=threading.RLock();e.clock=lambda:1800000000
            e.db=sqlite3.connect(root/'handoff-events.sqlite3',timeout=.1)
            try:e.prune()
            finally:e.db.close()
        return 'allowed'
    except (maintenance.Busy,sqlite3.OperationalError,BlockingIOError):return 'blocked'

def child(root,kind):
    p=subprocess.run([sys.executable,__file__,'probe',str(root),kind],capture_output=True,text=True,timeout=8)
    assert p.returncode==0,p.stderr
    return p.stdout.strip()

def waiting():
    # Execute the exact legacy waiting function only. No fake /var/data mount.
    tree=ast.parse((BASE/'legacy/hosting.py').read_text())
    node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='waiting')
    env={};exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'legacy-waiting-handler','exec'),env)
    return env['waiting']

def main():
    assert sys.platform=='linux'
    start=time.monotonic();result={}
    with tempfile.TemporaryDirectory(prefix='flower-controller-synthetic-') as temp:
        r=Path(temp)/'data';hosting.bootstrap(r,'synthetic',False)
        app=hosting.Hosting(r,'synthetic','http://127.0.0.1:8790','synthetic-key-'*5,production=False,accepting=False,mode='locked')
        app.close();before=snapshot(r)
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        key=rsa.generate_private_key(public_exponent=65537,key_size=3072)
        pub=key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
        with guard(r):
            result['controller_locks_acquired']=True
            for k in ('worker','admin','cooperating','raw','service','cleanup'):
                result[k+'_blocked_while_guarded']=child(r,k)=='blocked'
            handler=waiting();statuses={}
            for path in ('/healthz','/api/consult','/api/feedback','/api/handoff-events','/admin'):
                code=[];handler({'PATH_INFO':path},lambda s,h:code.append(s));statuses[path]=code[0]
            result['waiting_health_and_business_status']=statuses
            b=time.monotonic();public_backup.backup(r,pub,Path(temp)/'synthetic.enc')
            result['guarded_backup_seconds']=round(time.monotonic()-b,3)
            result['snapshot_unchanged_during_backup']=snapshot(r)==before
        result['success_keeps_closed_marker']=(r/'maintenance.pending').exists()
        try:
            with guard(r):public_backup.backup(r,b'invalid synthetic key',Path(temp)/'failure.enc')
        except ValueError:pass
        else:raise AssertionError('failure not injected')
        result['failure_releases_locks_keeps_marker']=child(r,'worker')=='allowed' and child(r,'admin')=='allowed' and child(r,'cooperating')=='blocked'
        proc=subprocess.Popen([sys.executable,__file__,'hold',str(r)],stdout=subprocess.PIPE,text=True)
        try:
            assert proc.stdout.readline().strip()=='READY'
            proc.kill();proc.wait(timeout=5)
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
        result['crash_releases_os_locks']=child(r,'worker')=='allowed' and child(r,'admin')=='allowed'
        result['crash_marker_blocks_cooperating_writer']=child(r,'cooperating')=='blocked'
        with guard(r):result['restart_reacquires_locks']=child(r,'raw')=='blocked'
        result['data_unchanged_after_failure_crash_restart']=snapshot(r)==before
        # Explicit negative acceptance: unmodified legacy does not honor marker.
        result['legacy_service_ignores_persistent_marker']=child(r,'service')=='allowed'
        result['raw_sql_ignores_persistent_marker']=child(r,'raw')=='allowed'
        result['overall_safe_for_production']=False
        result['scope']='Linux build synthetic only; no Render edge or persistent disk lifecycle; no restore/r2 rerun'
        result['elapsed_seconds']=round(time.monotonic()-start,3)
        result['production_operations']=0;result['paid_ai_calls']=0
        print('CONTROLLER_RESULT '+json.dumps(result),flush=True)

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='probe':print(probe(Path(sys.argv[2]),sys.argv[3]))
    elif len(sys.argv)>1 and sys.argv[1]=='hold':
        with guard(Path(sys.argv[2])):
            print('READY',flush=True);time.sleep(30)
    else:main()
