"""Closed preparation release candidate. No business imports or DB access.

Deliberately has no unlock endpoint, environment toggle, scheduler or backup
trigger. Replacing this release is the only path back to a business application.
Operator backup is separate; its failure cannot change this HTTP application's
state. This is NOT an OS security boundary against an authorized shell user.
"""
BODY = ('紫微牌卡占卜花房｜系統維護中\n'
        '花房正在進行短暫的系統維護，目前暫停新的占卜服務。\n'
        '請稍後再回來，感謝您的耐心等候。\n'
        '維護不會任意清除原有占卜紀錄；若剛才已送出問題，請先不要重複提交。\n'
        '侯孜餘老師・紫微牌卡占卜花房').encode('utf-8')

def application(environ, start_response):
    method = environ.get('REQUEST_METHOD', '')
    healthy = environ.get('PATH_INFO') == '/healthz' and method in ('GET', 'HEAD')
    body = b'{"process_alive":true,"ready":false,"mode":"closed-preparation"}' if healthy else BODY
    headers = [('Content-Type', 'application/json' if healthy else 'text/plain; charset=utf-8'),
               ('Content-Length', str(len(body))), ('Cache-Control', 'no-store'),
               ('X-Content-Type-Options', 'nosniff')]
    if not healthy: headers.append(('Retry-After', '60'))
    start_response('200 OK' if healthy else '503 Service Unavailable', headers)
    return [] if method == 'HEAD' else [body]
