import os
bind = '0.0.0.0:' + os.environ.get('PORT', '10000')
workers = 1
worker_class = 'gthread'
threads = 2
timeout = 30
graceful_timeout = 20
preload_app = False
accesslog = None
errorlog = '-'
capture_output = False
