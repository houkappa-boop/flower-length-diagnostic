"""Delta acceptance of closed release. Synthetic DBs; real Linux Gunicorn.

Process restarts are not Render disk/edge lifecycle tests. No prior backup,
restore, r2, LINE or 120-second suite is rerun.
"""
import os,sys,time,json,tempfile,subprocess,socket,http.client,sqlite3,hashlib,shutil,signal
from pathlib import Path
BASE=Path(__file__).parent
class UnixHTTP(http.client.HTTPConnection):
    def connect(self):
        self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
        self.sock.settimeout(3);self.sock.connect(self.host)

def request(sock,path,method='GET',headers=None):
    c=UnixHTTP(str(sock))
    try:
        c.request(method,path,body=b'synthetic' if method not in ('GET','HEAD') else None,headers=headers or {})
        r=c.getresponse();return r.status,r.read()
    finally:c.close()

def hashes(root):
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}

def wait_for(fn):
    until=time.monotonic()+10
    while time.monotonic()<until:
        try:
            if fn():return
        except (OSError,http.client.HTTPException):pass
        time.sleep(.03)
    raise AssertionError('condition timeout')

def run():
    assert sys.platform=='linux'
    started=time.monotonic();result={};proc=None
    with tempfile.TemporaryDirectory(prefix='flower-closed-preparation-') as temp:
        root=Path(temp);data=root/'data';data.mkdir();release=root/'release'
        shutil.copytree(BASE/'closed_preparation',release)
        for rel in ('records/consultations.sqlite3','access/access.sqlite3','handoff-events.sqlite3'):
            p=data/rel;p.parent.mkdir(exist_ok=True)
            with sqlite3.connect(p) as db:
                db.execute('CREATE TABLE sentinel(value TEXT)');db.execute("INSERT INTO sentinel VALUES('synthetic unchanged')")
        before=hashes(data);sock=root/'closed.sock';log=(root/'server.log').open('w+')
        env={**os.environ,'BETA_MODE':'student-beta','PAID_CALLS_ENABLED':'true','BOOTSTRAP_PENDING':'false','FLOWER_TEST_DATA_ROOT':str(data),'PYTHONDONTWRITEBYTECODE':'1'}
        # These legacy flags must have no effect on the separate closed module.
        def start():
            p=subprocess.Popen([sys.executable,'-m','gunicorn','-c',str(release/'gunicorn.conf.py'),'--bind','unix:'+str(sock),'app:application'],cwd=release,env=env,stdout=log,stderr=log,start_new_session=True)
            wait_for(lambda:request(sock,'/healthz')[0]==200)
            return p
        def suite():
            assert request(sock,'/healthz')[0]==200
            assert json.loads(request(sock,'/healthz')[1])['ready'] is False
            for path in ('/','/api/consult','/api/feedback','/api/handoff-events','/admin','/unlock','/internal/cleanup','/api/forum-handoff'):
                for method in ('GET','POST','PUT','DELETE','PATCH','HEAD','OPTIONS'):
                    assert request(sock,path,method,{'Host':'private.internal','X-Forwarded-For':'127.0.0.1','Authorization':'synthetic'})[0]==503
            assert request(sock,'/healthz','POST')[0]==503
            assert hashes(data)==before
        try:
            proc=start();suite();result['normal_start_all_business_methods_503']=True
            result['legacy_open_flags_cannot_unlock']=True
            children=Path('/proc')/str(proc.pid)/'task'/str(proc.pid)/'children'
            worker=int(children.read_text().strip().split()[0]);os.kill(worker,signal.SIGKILL)
            wait_for(lambda:children.read_text().strip() and str(worker) not in children.read_text().split())
            wait_for(lambda:request(sock,'/healthz')[0]==200);suite();result['worker_crash_respawn_closed']=True
            proc.terminate();proc.wait(timeout=6);proc=start();suite();result['normal_restart_closed']=True
            os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=6)
            proc=start();suite();result['process_group_crash_restart_closed']=True
            proc.terminate();proc.wait(timeout=6)
            shutil.copyfile(BASE/'closed_preparation/app.py',release/'app.py')
            proc=start();suite();result['same_release_relaunch_closed']=True
            # Exercise existing backup failure only, not full backup/restore suite.
            sys.path.insert(0,str(BASE/'candidate'));import public_backup
            try:public_backup.backup(data,b'invalid synthetic public key',root/'invalid.enc')
            except ValueError:pass
            else:raise AssertionError('backup failure not raised')
            suite();result['backup_failure_does_not_open_http']=True
            result['all_db_file_hashes_unchanged']=hashes(data)==before
            result['no_business_imports_in_closed_source']=not any(x in (release/'app.py').read_text() for x in ('import backend','import hosting','import sqlite3','import handoff_events'))
            result['health_seconds']=None
            t=time.monotonic();assert request(sock,'/healthz')[0]==200;result['health_seconds']=round(time.monotonic()-t,4)
            # Prove access-control boundary: authorized shell can still write.
            with sqlite3.connect(data/'access/access.sqlite3') as db:db.execute("INSERT INTO sentinel VALUES('synthetic operator write')")
            result['same_uid_shell_not_prevented']=hashes(data)!=before
            result['render_disk_lifecycle_tested']=False
            result['external_scheduler_inventory_complete']=False
            result['elapsed_seconds']=round(time.monotonic()-started,3)
            result['paid_ai_calls']=0;result['production_operations']=0
            print('PREPARATION_RESULT '+json.dumps(result),flush=True)
        finally:
            if proc and proc.poll() is None:proc.terminate();proc.wait(timeout=6)
            log.close()
if __name__=='__main__':run()
