"""Synthetic-only acceptance. Report negative findings, never hide legacy gaps."""
import sys,os,time,json,sqlite3,threading,uuid,io,fcntl,tempfile,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
BASE=Path(__file__).parent
stage=sys.argv[1] if len(sys.argv)>1 else 'run'
def snap(r):
 out={}
 for p in sorted(r.rglob('*.sqlite3')):
  with closing(sqlite3.connect(p)) as c:
   assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
   out[str(p.relative_to(r))]={n:sorted(c.execute('SELECT * FROM "'+n+'"').fetchall(),key=repr) for n, in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
 return out
def setup(old=True):
 sys.path.insert(0,str(BASE/('legacy' if old else 'candidate')))
 import backend
 class K:
  empty='Synthetic only'
  def context(self,q):return {'question':q,'rules':[{'id':'synthetic-rule'}],'reference_cases':[]}
 backend.Knowledge=K
 def deny(*a,**k):raise AssertionError('paid transport forbidden')
 backend.live_request=deny;backend.PAID_CALLS_APPROVED=False
 return backend
def request(app,path,data=None,token=''):
 raw=json.dumps(data).encode() if data is not None else b'';status=[]
 env={'PATH_INFO':path,'REQUEST_METHOD':'POST' if data is not None else 'GET','HTTP_HOST':'127.0.0.1:8790','HTTP_ORIGIN':'http://127.0.0.1:8790','HTTP_COOKIE':'flower_session='+token,'HTTP_X_CSRF_TOKEN':app.mac('csrf:'+token),'CONTENT_TYPE':'application/json','CONTENT_LENGTH':str(len(raw)),'wsgi.input':io.BytesIO(raw),'REMOTE_ADDR':'127.0.0.1'}
 value=b''.join(app(env,lambda s,h:status.append(s)))
 return status[0],json.loads(value)
def legacy(r):
 backend=setup();import hosting
 hosting.bootstrap(r,'synthetic',False)
 app=hosting.Hosting(r,'synthetic','http://127.0.0.1:8790','synthetic-key-'*5,production=False,accepting=True,mode='mock',clock=lambda:1800000000.)
 app.production=True
 owner,_=app.invite();token='synthetic-session'
 app.db.execute('INSERT INTO sessions VALUES(?,?,?)',(hosting.digest(token),owner,1800100000));app.db.commit()
 entered=threading.Event();release=threading.Event();calls=[]
 def slow(ctx):
  calls.append(1);entered.set();assert release.wait(130);return backend.mock_request(ctx)
 app.svc.transport=slow
 q={'consultation_id':str(uuid.uuid4()),'question_category':'工作事業','question_text':'合成過渡驗證問題','drawn_card':'main_03','orientation':'upright'}
 result={}
 with ThreadPoolExecutor(max_workers=5) as pool:
  f=pool.submit(request,app,'/api/consult',q,token);assert entered.wait(5)
  g=(r/'io.lock').open('a+b');start=time.monotonic();cancelled=False
  print('PROGRESS real 120-second legacy drain begins',flush=True)
  while True:
   try:fcntl.flock(g,fcntl.LOCK_EX|fcntl.LOCK_NB);raise AssertionError('lock acquired during accepted AI')
   except BlockingIOError:
    if time.monotonic()-start>=120:cancelled=True;break
    time.sleep(.025)
  g.close();result['drain_timeout_seconds']=round(time.monotonic()-start,3);result['timeout_cancelled_without_kill']=cancelled
  release.set();status,_=f.result(8)
  row=app.svc.db.execute('SELECT * FROM consultations WHERE consultation_id=?',(q['consultation_id'],)).fetchone()
  result['accepted_ai_saved_once']=status.startswith('200') and backend.saved_complete(row) and len(calls)==1
  app.svc.feedback(owner,{'consultation_id':q['consultation_id'],'feedback_status':'部分貼近','feedback_text':'合成舊版回饋'})
  g=(r/'io.lock').open('a+b');fcntl.flock(g,fcntl.LOCK_EX)
  event={'flow_id':str(uuid.uuid4()),'event':'teacher_clicked'}
  queued=pool.submit(request,app,'/api/handoff-events',event);health=pool.submit(request,app,'/healthz');time.sleep(.15)
  result['health_blocked_by_legacy_lock']=not health.done()
  prune=pool.submit(app.handoff_events.prune);prune.result(2)
  result['cleanup_bypasses_http_lock']=True
  guards=[]
  try:
   for p in sorted(r.rglob('*.sqlite3')):
    c=sqlite3.connect(p,timeout=.1);c.execute('BEGIN IMMEDIATE');guards.append(c)
   def adminwrite():
    with closing(sqlite3.connect(r/'handoff-events.sqlite3',timeout=5)) as c:
     c.execute('INSERT INTO events VALUES(?,?,?)',(str(uuid.uuid4()),'teacher_clicked',1800000000));c.commit()
   admin=pool.submit(adminwrite);bg=pool.submit(app.handoff_events.prune);time.sleep(.15)
   result['db_barrier_blocks_admin_and_cleanup']=not admin.done() and not bg.done()
   stable=snap(r);result['stable_snapshot_readable']=bool(stable)
  finally:
   for c in reversed(guards):c.rollback();c.close()
  admin.result(6);bg.result(6);result['background_admin_resume']=True
  result['queued_request_waits']=not queued.done()
  fcntl.flock(g,fcntl.LOCK_UN);g.close();qs,_=queued.result(6);health.result(6)
  result['queued_request_writes_after_unlock']=qs.startswith('200')
  request(app,'/api/handoff-events',event)
  result['duplicate_event_not_duplicated']=app.handoff_events.db.execute('SELECT COUNT(*) FROM events WHERE flow_id=?',(event['flow_id'],)).fetchone()[0]==1
 app.close()
 (r.parent/'legacy-result.json').write_text(json.dumps(result))
 print('LEGACY_RESULT '+json.dumps(result),flush=True)
def cycle(r):
 backend=setup(False);import hosting,public_backup,maintenance
 from public_experience import PublicHosting
 from cryptography.hazmat.primitives.asymmetric import rsa
 from cryptography.hazmat.primitives import serialization
 before=snap(r);k=rsa.generate_private_key(public_exponent=65537,key_size=3072)
 pub=k.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
 priv=k.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
 enc=r.parent/'synthetic.enc';dest=r.parent/'restored'
 public_backup.backup(r,pub,enc);public_backup.restore(enc,priv,dest)
 result={'closed_old_three_db_restore_exact':snap(dest)==before}
 app=PublicHosting(dest,'synthetic','http://127.0.0.1:8790','synthetic-key-'*5,production=False,mode='mock',accepting=True,clock=lambda:1800000010.)
 now=snap(dest);result['r2_preserves_all_legacy_rows']=all(now[n].get(t)==rows for n,ts in before.items() for t,rows in ts.items())
 _,owner=app.new_visitor();q={'consultation_id':str(uuid.uuid4()),'question_category':'工作事業','question_text':'合成第二階段問題','drawn_card':'main_01','orientation':'upright','parent_id':None}
 status,value=app.consultation(owner,q);result['r2_new_result_saved']=status==200 and value.get('delivery_status')=='complete'
 app.svc.feedback(owner,{'consultation_id':q['consultation_id'],'feedback_status':'部分貼近','feedback_text':'合成新資料'})
 app.close();saved=snap(dest)
 # Actual recovery factory, configured with synthetic root and mock transport.
 import public_recovery,public_entry
 original=public_recovery.normal_app
 public_recovery.normal_app=lambda:public_entry.build_app({'PUBLIC_EXPERIENCE_MODE':'mock','EXPECTED_VOLUME_ID':'synthetic','PUBLIC_ORIGIN':'http://127.0.0.1:8790','SESSION_SECRET':'synthetic-key-'*5},dest,production=False)
 app=public_recovery.create_app();result['recovery_drain_enabled']=app.recovery_drain
 result['recovery_preserves_all_old_new_rows']=snap(dest)==saved
 app.svc.feedback(owner,{'consultation_id':q['consultation_id'],'feedback_status':'部分貼近','feedback_text':'合成回復後保存'})
 app.close();reopened=snap(dest)
 result['feedback_after_recovery_saved']=any('合成回復後保存' in str(rows) for ts in reopened.values() for rows in ts.values())
 result['scope']='offline closed-old data compatibility only; first live transition and minimal patch installation NOT proven'
 print('CYCLE_RESULT '+json.dumps(result),flush=True)
if stage=='legacy':legacy(Path(sys.argv[2]))
elif stage=='cycle':cycle(Path(sys.argv[2]))
else:
 assert sys.platform=='linux'
 print('PLATFORM '+sys.platform+' '+sys.version.split()[0],flush=True)
 with tempfile.TemporaryDirectory(prefix='flower-verification-transition-') as tmp:
  r=Path(tmp)/'data'
  for step in ('legacy','cycle'):
   subprocess.run([sys.executable,__file__,step,str(r)],check=True,timeout=165)
 print('ACCEPTANCE first_live_transition=BLOCKED health_and_queued_admission; patch_install=NOT_RUN; paid_ai=0; production=0',flush=True)
