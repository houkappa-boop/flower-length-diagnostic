"""Isolation candidate adapter; installing into a running legacy worker is NOT solved.

Retains legacy business code. Cooperating admin calls only; direct SQL must still
be excluded or guarded at database level. No production entry point is provided.
"""
from pathlib import Path
import hosting,maintenance

OriginalEvents=hosting.HandoffEvents
class GuardedEvents(OriginalEvents):
 def __init__(self,path,*args,**kwargs):
  self.root=Path(path).parent
  with maintenance.writer(self.root):super().__init__(path,*args,**kwargs)
 @maintenance.method
 def prune(self):return super().prune()
 @maintenance.method
 def record(self,data):return super().record(data)
 def _clean(self):
  import sqlite3
  while not self.stop.wait(3600):
   try:self.prune()
   except (sqlite3.Error,maintenance.Busy):pass
hosting.HandoffEvents=GuardedEvents

class PatchedHosting(hosting.Hosting):
 @maintenance.constructor
 def __init__(self,root,*args,**kwargs):super().__init__(root,*args,**kwargs)
 @maintenance.method
 def invite(self,*args,**kwargs):return super().invite(*args,**kwargs)
 @maintenance.method
 def consultation(self,*args,**kwargs):return super().consultation(*args,**kwargs)
 def __call__(self,env,start_response):
  if env.get('PATH_INFO')=='/healthz' and env.get('REQUEST_METHOD','GET')=='GET':
   return self.respond(env,start_response)
  try:
   with maintenance.writer(self.root):return super().__call__(env,start_response)
  except maintenance.Busy:return maintenance.unavailable(start_response)
