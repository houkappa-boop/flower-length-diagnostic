"""Targeted legacy process exit only. Synthetic, Unix sockets, no paid/network AI."""
import os,sys,time,json,uuid,sqlite3,threading,subprocess,tempfile,fcntl,socket,http.client
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
BASE=Path(__file__).parent
sys.path.insert(0,str(BASE/'legacy'))
import backend,hosting
class K:
 def context(self,q):return {'question':q,'rules':[{'id':'synthetic'}],'reference_cases':[]}
backend.Knowledge=K
backend.PAID_CALLS_APPROVED=False
def deny(*a,**k):raise AssertionError('paid AI forbidden')
backend.live_request=deny
def app_at(r):return hosting.Hosting(r,'synthetic','http://127.0.0.1:8790','synthetic-key-'*5,production=False,accepting=True,mode='mock',clock=lambda:1800000000.)
def create_app():
 r=Path(os.environ['EXIT_TEST_ROOT']);app=app_at(r);app.production=True
 app.singleton=(r/'worker.lock').open('a+b');fcntl.flock(app.singleton,fcntl.LOCK_EX|fcntl.LOCK_NB)
 def slow(ctx):
  (r/('entered-'+str(threading.get_ident()))).write_text('1')
  end=time.monotonic()+15
  while not (r/'release').exists():
   assert time.monotonic()<end;time.sleep(.01)
  return backend.mock_request(ctx)
 app.svc.transport=slow
 def clean():
  while True:
   app.handoff_events.prune()
   with (r/'cleanup-ticks').open('a') as f:f.write('1\n')
   time.sleep(.03)
 threading.Thread(target=clean,daemon=True).start()
 def wrapped(env,start):
  if env['PATH_INFO']=='/synthetic-hold':
   (r/('slot-'+str(threading.get_ident()))).write_text('1')
   end=time.monotonic()+15
   while not (r/'release').exists():
    assert time.monotonic()<end;time.sleep(.01)
   start('200 OK',[('Content-Type','text/plain')]);return [b'held synthetic read']
  return app(env,start)
 return wrapped
class U(http.client.HTTPConnection):
 def connect(self):
  self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);self.sock.settimeout(20);self.sock.connect(self.host)
def run():
 assert sys.platform=='linux'
 with tempfile.TemporaryDirectory(prefix='flower-verification-exit-') as temp:
  r=Path(temp)/'data';hosting.bootstrap(r,'synthetic',False);app=app_at(r)
  tokens=[];csrf={}
  for i in range(4):
   owner,_=app.invite();t='synthetic-'+str(i);tokens.append(t);csrf[t]=app.mac('csrf:'+t)
   app.db.execute('INSERT INTO sessions VALUES(?,?,?)',(hosting.digest(t),owner,1800100000))
  app.db.commit();app.close();sock=str(Path(temp)/'old.sock')
  log=(Path(temp)/'server.log').open('w+')
  proc=subprocess.Popen([sys.executable,'-m','gunicorn','-c',str(BASE/'legacy/gunicorn.conf.py'),'--bind','unix:'+sock,'exit_linux:create_app()'],env={**os.environ,'EXIT_TEST_ROOT':str(r)},stdout=log,stderr=log,cwd=BASE)
  def req(path,data=None,t=tokens[0]):
   c=U(sock)
   try:
    c.request('POST' if data is not None else 'GET',path,json.dumps(data) if data is not None else None,{'Host':'127.0.0.1:8790','Origin':'http://127.0.0.1:8790','Cookie':'flower_session='+t,'X-CSRF-Token':csrf[t],'Content-Type':'application/json'})
    res=c.getresponse();return res.status,res.read()
   finally:c.close()
  def wait(check):
   end=time.monotonic()+10
   while not check():
    assert time.monotonic()<end;time.sleep(.02)
  result={}
  try:
   wait(lambda:Path(sock).exists());wait(lambda:req('/healthz')[0]==200)
   qs=[dict(consultation_id=str(uuid.uuid4()),question_category='工作事業',question_text='Synthetic exit question',drawn_card='main_03',orientation='upright') for i in range(2)]
   with ThreadPoolExecutor(max_workers=5) as pool:
    fs=[pool.submit(req,'/api/consult',q,t) for q,t in zip(qs,tokens)]
    wait(lambda:len(list(r.glob('entered-*')))==2)
    holds=[pool.submit(req,'/synthetic-hold') for _ in range(2)]
    wait(lambda:len(list(r.glob('slot-*')))==2)
    event={'flow_id':str(uuid.uuid4()),'event':'teacher_clicked'}
    queued=pool.submit(req,'/api/handoff-events',event);time.sleep(.3)
    result['queued_with_two_ai_and_two_synthetic_reads']=not queued.done()
    start=time.monotonic();proc.terminate();time.sleep(1.2)
    try:result['new_connection_rejected']=req('/healthz')[0]!=200
    except (OSError,http.client.HTTPException):result['new_connection_rejected']=True
    result['worker_alive_until_accepted_released']=proc.poll() is None
    (r/'release').write_text('1')
    result['accepted_http_success']=all(f.result(15)[0]==200 for f in fs+holds)
    try:result['queued_http_status']=queued.result(15)[0]
    except (OSError,http.client.HTTPException):result['queued_http_status']='disconnected'
    proc.wait(timeout=15);result['exit_seconds']=round(time.monotonic()-start,3);result['normal_exit']=proc.returncode==0
   c=sqlite3.connect(r/'records/consultations.sqlite3');c.row_factory=sqlite3.Row
   result['both_ai_saved_once']=all(c.execute('SELECT COUNT(*) FROM consultations WHERE consultation_id=?',(q['consultation_id'],)).fetchone()[0]==1 and backend.saved_complete(c.execute('SELECT * FROM consultations WHERE consultation_id=?',(q['consultation_id'],)).fetchone()) for q in qs);c.close()
   c=sqlite3.connect(r/'handoff-events.sqlite3');result['queued_event_count']=c.execute('SELECT COUNT(*) FROM events WHERE flow_id=?',(event['flow_id'],)).fetchone()[0];c.close()
   ticks=(r/'cleanup-ticks').read_bytes();time.sleep(.2);result['worker_background_stopped']=(r/'cleanup-ticks').read_bytes()==ticks
   lock=(r/'worker.lock').open('a+b');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);result['singleton_released']=True;lock.close()
   guards=[]
   for p in r.rglob('*.sqlite3'):
    c=sqlite3.connect(p,timeout=.1);assert c.execute('pragma integrity_check').fetchone()[0]=='ok';c.execute('BEGIN IMMEDIATE');guards.append(c)
   result['all_db_write_locks_available']=True
   for c in guards:c.rollback();c.close()
   result['scope']='real legacy Gunicorn graceful exit; not Render edge, watchdog, external admin or 120s cancellation after TERM'
   print('EXIT_RESULT '+json.dumps(result),flush=True)
   assert result['both_ai_saved_once'] and result['normal_exit'] and result['new_connection_rejected']
  finally:
   if proc.poll() is None:proc.kill();proc.wait()
   log.seek(0);print('SERVER_LOG '+log.read(),flush=True);log.close()
if __name__=='__main__':run()
