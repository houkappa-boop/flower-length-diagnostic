花房第二階段：既有免費診斷服務隔離驗收包（本機候選，尚未部署）

原始 Node 六個檔案保持逐位元組一致：package.json、server.cjs、core.cjs、client.js、index.html、test.cjs。
Start Command 仍為 npm start。此包不自動修改 package.json、不建立部署工作流程。
verification 是建置用目錄，server.cjs 使用固定檔案允許清單，不對外提供此目錄；不要新增任何檔案瀏覽或測試端點。

候選必要 Python 程式保留原檔 SHA-256（candidate-sha256.json）。未複製正式資料庫、session 憑證、API 密鑰、圖片或母資料 JSON；output_policy 是明確標示的合成替身，Knowledge 是合成物件。
這是基礎設施驗收，不能作為學理、解牌內容或正式掛載的新證據。
套件保持候選需求 cryptography==50.0.1、gunicorn==23.0.0；本機已安裝 cryptography 50.0.2，因此本機通過不等於固定版 50.0.1 的 Linux 通過。

本機命令：python verification/run.py
Linux 命令（須老師另批准診斷建置）：npm test && sh verification/run-linux.sh
建議部署建置命令如上；不得把 synthetic_wsgi 設為公開服務 Start Command。
run-linux.sh 不自動安裝套件；先檢查原建置環境是否有需要的 Python／套件，缺少即失敗。若需臨時 venv，另核准在建置臨時目錄下載上述固定版本及其必要相依套件，先完成版本／wheel 清單審查，不修改正式服務的 Python、環境變數或 requirements。
Render 原生環境工具清單已包含 python3-dev/pip/setuptools/sqlite3；套件文件支援範圍與本程式 Python>=3.10 有交集，但實際版本、wheel 安裝、Gunicorn 載入仍需建置取得證據。

隔離措施：
• 所有資料置於系統臨時目錄 flower-verification-*，另需 .synthetic-only 標記；測試不使用正式 /var/data 路徑。
• 子程序使用允許清單環境與明確載入的拒絕 IP 網路／DNS hook；模型固定 mock，live_request 明確拒絕。僅 Gunicorn 本機 Unix socket 允許通訊。
• 實測 public_ops verify 子程序；Linux 才跑 backup CLI 與真實 fcntl，不以 Windows 替代鎖模擬通過。
• 本機回復入口以合成 normal_app 替身測試；Linux synthetic_wsgi 保留 create_app 的 worker.lock 與 recovery_drain，只適配掛載／合成設定及生產 WSGI 鎖分支。沒有驗證真實 /var/data 掛載；未開背景遙測清理執行緒。
• io.lock 只能擋合作式 WSGI 寫入；背景清理不是 io.lock 的保證。完整備份要求 worker.lock 可獨占（服務已停止），測試驗證服務運作時拒絕備份。
• 每個子程序最長 30 秒；Linux 整套最多 300 秒，自己的 Gunicorn 群組在清理時終止；不操作平台或其他服務程序。測試後刪除合成臨時檔。

仍待 Render：三個 Linux 整合案例（真實跨程序停寫／CLI 備份鎖與一致性／Gunicorn 載入與兩次啟停）、固定套件版本、當期免費用量。免費診斷不能驗證跨 redeploy 磁碟持久化。
本機新增驗證是測試包本身的整合與故障注入；未重跑原 656／59 次名額與跨日等驗收。

另行批准的操作與風險：
1. 唯讀確認目前免費 pipeline minutes、流量及超額規則；五分鐘測試上限不包含平台排隊、套件安裝與原 Node 建置，不保證完全無額外費用。無法確定零新增費用則停止。
2. 核對診斷服務自動部署設定與來源 commit，審查此包是否適合其程式庫公開程度。批准後才提交專用變更／改建置命令／觸發一次建置；正式花房不動。
3. 成功建置可能發布診斷服務的新映像；保留原 Node 功能，仍需驗收診斷入口。若失敗保留既有 Live，不盲目重試。回退只針對診斷原 commit cd8897742b89da86aeb69cb7f1fed0a97ff81abc 與 npm test；任何回退仍需授權。
4. 脫敏日誌需記錄 Python、SQLite、cryptography、Gunicorn、各案例、耗時、版本雜湊。合成私鑰／資料庫／備份不得放進發布內容或公開日誌。

參考：https://render.com/docs/native-runtimes 、https://render.com/docs/free
https://pypi.org/project/cryptography/50.0.1/ 、https://pypi.org/project/gunicorn/23.0.0/
