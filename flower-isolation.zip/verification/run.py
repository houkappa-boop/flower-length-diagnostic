import argparse, json, os, pathlib, subprocess, sys, unittest
base=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(base),str(base/'candidate')]
import sitecustomize
import preflight
from test_integration import Integration
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--linux-required',action='store_true');a=p.parse_args()
    if a.linux_required and sys.platform!='linux':raise SystemExit('Linux required; no simulated pass')
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Integration)
    r=unittest.TextTestRunner(verbosity=2).run(suite)
    unsuccessful={t.id() for t,_ in r.failures+r.errors+r.skipped}
    print(json.dumps({'run':r.testsRun,'passed':r.testsRun-len(unsuccessful),'skipped':len(r.skipped),'failures':len(r.failures),'errors':len(r.errors)}))
    raise SystemExit(not r.wasSuccessful())
