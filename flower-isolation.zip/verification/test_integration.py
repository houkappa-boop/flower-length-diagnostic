import hashlib, json, os, signal, socket, sqlite3, subprocess, sys, tempfile, time, unittest
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
import fixture, public_backup
from contextlib import closing

BASE=Path(__file__).resolve().parent
LINUX=sys.platform=='linux'
class Integration(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='flower-verification-')
        self.base=Path(self.temp.name);self.root=self.base/'data';self.meta=fixture.seed(self.root)
        self.env={k:os.environ[k] for k in ('PATH','SYSTEMROOT','WINDIR') if k in os.environ}
        self.env.update(PYTHONPATH=os.pathsep.join([str(BASE),str(BASE/'candidate')]),PYTHONDONTWRITEBYTECODE='1',
            TEMP=tempfile.gettempdir(),TMP=tempfile.gettempdir(),TMPDIR=tempfile.gettempdir(),
            FLOWER_SYNTHETIC_ROOT=str(self.root),PUBLIC_EXPERIENCE_MODE='mock',EXPECTED_VOLUME_ID='synthetic',
            PUBLIC_ORIGIN='http://127.0.0.1:8790',SESSION_SECRET='synthetic-not-a-secret-'*3)
        # Temp parent remains the OS temp dir so the synthetic marker boundary is stable.
        self.children=[]
    def tearDown(self):
        for p in self.children:
            if LINUX:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
            elif p.poll() is None:p.kill()
            p.communicate(timeout=10)
        self.temp.cleanup()
    def run_child(self,*args):
        return subprocess.run([sys.executable,str(BASE/'child.py'),*map(str,args)],env=self.env,cwd=BASE,capture_output=True,text=True,timeout=30)
    def start(self,*args):
        p=subprocess.Popen([sys.executable,str(BASE/'child.py'),*map(str,args)],env=self.env,cwd=BASE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=LINUX)
        self.children.append(p);return p
    def wait_file(self,path,p):
        end=time.monotonic()+10
        while not path.exists() and p.poll() is None and time.monotonic()<end:time.sleep(.025)
        self.assertTrue(path.exists(),'child did not reach expected checkpoint')
    def keys(self):
        k=rsa.generate_private_key(public_exponent=65537,key_size=3072)
        self.pub=k.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
        self.priv=k.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
        (self.base/'public.pem').write_bytes(self.pub);(self.base/'private.pem').write_bytes(self.priv)
    def test_packaged_backup_roundtrip_all_tables_and_newer_data(self):
        self.keys();before=fixture.snapshot(self.root);archive=self.base/'snapshot.enc'
        digest=public_backup.backup(self.root,self.pub,archive)
        self.assertEqual(digest,hashlib.sha256(archive.read_bytes()).hexdigest())
        dst=self.base/'restore';public_backup.restore(archive,self.priv,dst)
        self.assertEqual(before,fixture.snapshot(dst))
        verify=self.run_child(BASE/'candidate/public_ops.py','verify','--archive',archive,'--private-key',self.base/'private.pem')
        self.assertEqual(verify.returncode,0,verify.stderr)
        with closing(sqlite3.connect(self.root/'handoff-events.sqlite3')) as db:db.execute("INSERT INTO synthetic_old_events VALUES('newer record')");db.commit()
        newer=fixture.snapshot(self.root)
        with self.assertRaises(ValueError):public_backup.restore(archive,self.priv,self.root)
        self.assertEqual(newer,fixture.snapshot(self.root))
    def test_packaged_interruption_and_process_restart(self):
        before=fixture.snapshot(self.root)
        r=self.run_child(BASE/'worker.py','interrupt',self.root);self.assertEqual(r.returncode,19,r.stderr)
        for _ in range(2):
            r=self.run_child(BASE/'worker.py','check',self.root);self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(before,fixture.snapshot(self.root))
    def test_rejects_external_network_and_non_synthetic_root(self):
        r=self.run_child('-c',"import socket; socket.create_connection(('api.openai.com',443))")
        self.assertNotEqual(r.returncode,0);self.assertIn('verification forbids',r.stderr)
        with self.assertRaises(RuntimeError):fixture.validate_root(self.base/'not-marked')
    def test_saved_result_before_ledger_commit_process_crash(self):
        r=self.run_child(BASE/'worker.py','crash-saved',self.root);self.assertEqual(r.returncode,22,r.stderr)
        r=self.run_child(BASE/'worker.py','verify-saved',self.root);self.assertEqual(r.returncode,0,r.stderr)
    def test_unknown_transport_process_crash_never_retries(self):
        r=self.run_child(BASE/'worker.py','crash-unknown',self.root);self.assertEqual(r.returncode,21,r.stderr)
        r=self.run_child(BASE/'worker.py','verify-unknown',self.root);self.assertEqual(r.returncode,0,r.stderr)
    @unittest.skipUnless(LINUX,'requires real Linux flock; not emulated on Windows')
    def test_real_wsgi_writer_waits_for_cross_process_stop_lock(self):
        import fcntl
        with (self.root/'io.lock').open('rb') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            before=fixture.snapshot(self.root)
            p=self.start(BASE/'worker.py','write',self.root);self.wait_file(self.root/'ready',p)
            time.sleep(.2);self.assertIsNone(p.poll());self.assertFalse((self.root/'done').exists())
            # Startup schema reconciliation already happened before ready; no new visitor written.
            self.assertEqual(before,fixture.snapshot(self.root))
            fcntl.flock(lock,fcntl.LOCK_UN)
        out,err=p.communicate(timeout=10);self.assertEqual(p.returncode,0,err)
        self.assertTrue((self.root/'done').exists())
        with closing(sqlite3.connect(self.root/'access/access.sqlite3')) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM public_visitors').fetchone()[0],2)
    @unittest.skipUnless(LINUX,'requires real Linux CLI locks')
    def test_backup_cli_worker_refusal_and_consistent_snapshot(self):
        import fcntl
        self.keys();dest=self.base/'cli.enc'
        args=[BASE/'candidate/public_ops.py','backup','--root',self.root,'--public-key',self.base/'public.pem','--destination',dest]
        with (self.root/'worker.lock').open('rb') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            r=self.run_child(*args);self.assertNotEqual(r.returncode,0);self.assertFalse(dest.exists())
        with (self.root/'io.lock').open('rb') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            p=self.start(*args);time.sleep(.2);self.assertIsNone(p.poll());self.assertFalse(dest.exists())
            fcntl.flock(lock,fcntl.LOCK_UN)
        out,err=p.communicate(timeout=15);self.assertEqual(p.returncode,0,err)
        dst=self.base/'cli-restored';public_backup.restore(dest,self.priv,dst)
        self.assertEqual(fixture.snapshot(self.root),fixture.snapshot(dst))
    @unittest.skipUnless(LINUX,'Gunicorn Unix process lifecycle requires Linux')
    def test_gunicorn_recovery_factory_restart_and_worker_lock(self):
        import fcntl
        sock=self.base/'gunicorn.sock';before=fixture.snapshot(self.root)
        for _ in range(2):
            p=self.start('-m','gunicorn','--workers','1','--bind','unix:'+str(sock),'--timeout','10','--graceful-timeout','2','synthetic_wsgi:create_app()')
            end=time.monotonic()+10;response=b''
            while time.monotonic()<end and p.poll() is None:
                try:
                    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
                        s.settimeout(1);s.connect(str(sock));s.sendall(b'GET /healthz HTTP/1.0\r\nHost: 127.0.0.1:8790\r\n\r\n');response=s.recv(4096)
                    if b'200 OK' in response:break
                except OSError:time.sleep(.05)
            self.assertIn(b'200 OK',response)
            with (self.root/'worker.lock').open('rb') as lock:
                with self.assertRaises(BlockingIOError):fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            # Terminate master gracefully: kills only owned Gunicorn tree, never a platform process.
            # Abrupt process failure itself is covered by the standalone worker os._exit case.
            p.terminate();p.communicate(timeout=10)
            with (self.root/'worker.lock').open('rb') as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        self.assertEqual(before,fixture.snapshot(self.root))
