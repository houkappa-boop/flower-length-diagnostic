import argparse, io, json, os, time
from pathlib import Path
import fixture
import public_recovery
p=argparse.ArgumentParser();p.add_argument('action');p.add_argument('root');args=p.parse_args()
root=fixture.validate_root(args.root)
meta=json.loads((root/'fixture.json').read_text(encoding='utf-8'))
def recovery():
    # Windows-capable seam; Linux Gunicorn test covers the actual normal factory.
    public_recovery.normal_app=lambda:fixture.app(root)
    return public_recovery.create_app()
if args.action=='check':
    a=recovery();assert a.recovery_drain
    assert a.session(meta['token'])==meta['owner']
    assert a.state(meta['owner'])['started_followup']['cid']==meta['start']['cid']
    assert a.saved_result(meta['owner'],meta['first']['consultation_id'])['result']['delivery_status']=='complete'
    a.close();print('restart state verified')
elif args.action.startswith('crash-'):
    a=recovery()
    q={**meta['first'],'consultation_id':meta['start']['cid'],'parent_id':meta['first']['consultation_id'],'question_text':'合成延伸復原測試'}
    if args.action=='crash-unknown':
        a.svc.transport=lambda context:os._exit(21)
    else:
        original=a.svc.consult
        def save_then_exit(*values):
            original(*values);os._exit(22)
        a.svc.consult=save_then_exit
    a.consultation(meta['owner'],q)
    raise AssertionError('fault point not reached')
elif args.action.startswith('verify-'):
    a=recovery();calls=[]
    a.svc.transport=lambda context:calls.append(context)
    cid=meta['start']['cid'];expected='unknown' if args.action=='verify-unknown' else 'complete'
    assert a.db.execute('SELECT state FROM public_rounds WHERE cid=?',(cid,)).fetchone()[0]==expected
    q={**meta['first'],'consultation_id':cid,'parent_id':meta['first']['consultation_id'],'question_text':'合成延伸復原測試'}
    try:a.consultation(meta['owner'],q)
    except Exception:pass
    assert not calls,'recovery must not repeat transport'
    assert a.saved_result(meta['owner'],meta['first']['consultation_id'])['result']['delivery_status']=='complete'
    if expected=='complete':assert a.saved_result(meta['owner'],cid)['result']['delivery_status']=='complete'
    a.close();print('fault recovery verified: '+expected)
elif args.action=='interrupt':
    a=fixture.app(root)
    (root/'ready').write_text('ready')
    os._exit(19)  # emulate unclean process exit, no app.close()
elif args.action=='write':
    import synthetic_wsgi
    a=synthetic_wsgi.create_app()
    (root/'ready').write_text('before WSGI request')
    env={'PATH_INFO':'/api/session','QUERY_STRING':'','REQUEST_METHOD':'GET','HTTP_HOST':a.host,'wsgi.input':io.BytesIO()}
    statuses=[];b''.join(a(env,lambda s,h:statuses.append(s)))
    assert statuses[0].startswith('200'),statuses
    (root/'done').write_text('after WSGI commit');a.close()
else: raise ValueError('unknown worker action')
