"""Test-only adapter: same create_app worker lock, overridden mount/config only.
Never set this as a Render service Start Command.
"""
import os
import fixture
import public_entry, public_recovery

original_build=public_entry.build_app
def build(config,root,**kwargs):
    a=original_build(config,root,production=False)
    a.production=True  # execute the real Hosting.__call__ flock branch
    return a
def mount(path,expected):
    assert path=='/var/data/flower' and expected=='synthetic'
    root=fixture.validate_root(os.environ['FLOWER_SYNTHETIC_ROOT'])
    return fixture.hosting.check_volume(root,expected,False)
public_entry.check_volume=mount
public_entry.build_app=build
def create_app():
    return public_recovery.create_app()
