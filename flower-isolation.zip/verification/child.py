import sys,runpy
from pathlib import Path
base=Path(__file__).resolve().parent
sys.path[:0]=[str(base),str(base/'candidate')]
import sitecustomize
args=sys.argv[1:]
if args[0]=='-m':
    sys.argv=args[1:];runpy.run_module(args[1],run_name='__main__',alter_sys=True)
elif args[0]=='-c':
    sys.argv=['-c'];exec(args[1],{'__name__':'__main__'})
else:
    sys.argv=args;runpy.run_path(args[0],run_name='__main__')
