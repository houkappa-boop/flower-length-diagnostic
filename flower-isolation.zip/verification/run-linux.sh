#!/bin/sh
# REVIEW ONLY. Running on Render requires separate explicit approval.
set -eu
cd "$(dirname "$0")/.."
test "$(uname -s)" = Linux
command -v python3 >/dev/null
python3 -c 'import sys,fcntl,sqlite3; assert sys.version_info >= (3,10)'
# Does not install dependencies, change runtime, or fall back to a paid service.
# A separately approved, pinned dependency preparation is required if unavailable.
V="$PWD/verification"
T="$(mktemp -d -t flower-verification-build-XXXXXX)"
trap 'rm -rf -- "$T"' EXIT HUP INT TERM
env -i PATH="$PATH" HOME="$T" TMPDIR="$T" PYTHONPATH="$V:$V/candidate" PYTHONDONTWRITEBYTECODE=1 \
  timeout 300 python3 "$V/run.py" --linux-required
