import importlib.metadata, json, platform, sqlite3, sys
from pathlib import Path
import hashlib
base=Path(__file__).resolve().parent
manifest=json.loads((base/'candidate-sha256.json').read_text())
for name,digest in manifest.items():
    assert hashlib.sha256((base/'candidate'/name).read_bytes()).hexdigest()==digest,name
assert sys.version_info>=(3,10),'Python >=3.10 required'
import cryptography
from zoneinfo import ZoneInfo
ZoneInfo('Asia/Taipei')
data={'python':platform.python_version(),'platform':platform.system(),'sqlite':sqlite3.sqlite_version,'cryptography':cryptography.__version__}
if platform.system()=='Linux':
    import fcntl,gunicorn
    data['gunicorn']=gunicorn.__version__
    assert cryptography.__version__=='50.0.1'
    assert gunicorn.__version__=='23.0.0'
else:data['linux_checks']='PENDING: no flock/Gunicorn runtime evidence on this OS'
print(json.dumps(data))
