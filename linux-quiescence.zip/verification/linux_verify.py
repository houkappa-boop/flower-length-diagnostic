"""Fixed synthetic Linux/Gunicorn acceptance; no public maintenance endpoint."""
import os,sys,time,json,sqlite3,threading,subprocess,tempfile,uuid,fcntl,http.client,socket,hashlib
from pathlib import Path
from contextlib import contextmanager,closing
from concurrent.futures import ThreadPoolExecutor
import fixture,hosting,backend,public_backup

def root():return fixture.validate_root(os.environ['FLOWER_SYNTHETIC_ROOT'])
def wait_file(p,limit=8):
    end=time.monotonic()+limit
    while not p.exists():
        if time.monotonic()>end:raise TimeoutError(p.name)
        time.sleep(.01)

@contextmanager
def admission(r):
    with (r/'maintenance.lock').open('a+b') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_SH|fcntl.LOCK_NB)
        except BlockingIOError:yield False;return
        try:yield not (r/'maintenance.pending').exists()
        finally:fcntl.flock(lock,fcntl.LOCK_UN)

@contextmanager
def maintenance(r,timeout):
    with (r/'controller.lock').open('a+b') as owner:
        fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
        with (r/'maintenance.lock').open('a+b') as lock:
            if (r/'maintenance.pending').exists():raise RuntimeError('explicit orphan recovery required')
            (r/'maintenance.pending').write_text('synthetic-maintenance')
            try:
                end=time.monotonic()+timeout
                while True:
                    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
                    except BlockingIOError:
                        if time.monotonic()>end:raise TimeoutError('drain timeout')
                        time.sleep(.01)
                yield
            finally:
                (r/'maintenance.pending').unlink(missing_ok=True)
                fcntl.flock(lock,fcntl.LOCK_UN)

def create_app():
    r=root();app=fixture.app(r)
    app.production=True # Exercise unchanged Hosting.__call__ Linux io.lock.
    singleton=(r/'worker.lock').open('a+b');fcntl.flock(singleton,fcntl.LOCK_EX|fcntl.LOCK_NB)
    app.singleton=singleton
    def transport(ctx):
        with (r/'calls').open('a') as f:f.write('mock\n')
        if (r/'slow').exists():
            (r/'entered').write_text('entered');wait_file(r/'release',15)
        return backend.mock_request(ctx)
    app.svc.transport=transport
    def cleanup():
        while True:
            with admission(r) as allowed:
                if allowed:
                    app.handoff_events.prune()
                    with closing(sqlite3.connect(r/'public-handoff-events.sqlite3')) as db:
                        db.execute('update synthetic_bg set n=n+1');db.commit()
            time.sleep(.02)
    threading.Thread(target=cleanup,daemon=True).start()
    def wsgi(env,start):
        if env.get('PATH_INFO')=='/healthz':
            start('200 OK',[('Content-Type','application/json')]);return [b'{"ok":true}']
        with admission(r) as allowed:
            if not allowed:
                start('503 Service Unavailable',[('Content-Type','application/json'),('Retry-After','30'),('Cache-Control','no-store')])
                return [b'{"code":"MAINTENANCE_NOT_ACCEPTED"}']
            return list(app(env,start))
    return wsgi

def admin(r):
    with admission(r) as allowed:
        if allowed:
            with closing(sqlite3.connect(r/'access/access.sqlite3')) as db:
                db.execute('update synthetic_admin set n=n+1');db.commit()
    print('ADMIN_ALLOWED' if allowed else 'ADMIN_BLOCKED',flush=True)

def snap(r):
    out={}
    for rel in sorted(public_backup.FILES|{x for x in public_backup.OPTIONAL_FILES if (r/x).exists()}):
        if rel=='volume-id':out[rel]=(r/rel).read_text();continue
        with closing(sqlite3.connect(r/rel)) as db:
            assert db.execute('pragma integrity_check').fetchone()[0]=='ok'
            out[rel]={n:sorted(db.execute('select * from "'+n+'"').fetchall(),key=repr) for n, in db.execute("select name from sqlite_master where type='table' order by name")}
    return out

def controller(r,mode):
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization
    from unittest.mock import patch
    k=rsa.generate_private_key(public_exponent=65537,key_size=3072)
    pub=k.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
    priv=k.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
    started=time.monotonic();result={'mode':mode}
    try:
        with maintenance(r,.15 if mode=='timeout' else 5):
            result['drain_seconds']=round(time.monotonic()-started,4)
            (r/'held').write_text('held')
            if mode=='crash':os._exit(23)
            wait_file(r/'backup-release')
            before=snap(r);t=time.monotonic()
            if mode=='failure':
                with patch.object(public_backup.os,'fsync',side_effect=OSError('synthetic failure')):public_backup.backup(r,pub,r/'failure.enc')
            else:
                dest=r/('snapshot-'+str(uuid.uuid4())+'.enc');public_backup.backup(r,pub,dest)
                restored=r/('restore-'+str(uuid.uuid4()));public_backup.restore(dest,priv,restored)
                assert snap(restored)==before and snap(r)==before
                result['backup_restore_seconds']=round(time.monotonic()-t,4)
                result['snapshot_exact']=True
    except TimeoutError:result['timeout_cancelled']=True
    except OSError:result['injected_backup_error']=True
    result['maintenance_seconds']=round(time.monotonic()-started,4)
    result['gate_released']=not (r/'maintenance.pending').exists()
    print('CONTROLLER '+json.dumps(result),flush=True)

class UnixHTTP(http.client.HTTPConnection):
    def connect(self):
        self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);self.sock.settimeout(12);self.sock.connect(self.host)

def run():
    assert sys.platform=='linux'
    result={'platform':sys.platform,'python':sys.version.split()[0],'results':[]}
    with tempfile.TemporaryDirectory(prefix='flower-verification-quiescence-') as tmp:
        r=Path(tmp)/'data';hosting.bootstrap(r,'synthetic',False);(r/'.synthetic-only').write_text('synthetic-only')
        for name in ('worker.lock','io.lock','maintenance.lock','controller.lock'):(r/name).touch()
        events=hosting.HandoffEvents(r/'handoff-events.sqlite3');events.close()
        app=fixture.app(r)
        app.db.execute('create table synthetic_admin(n integer)');app.db.execute('insert into synthetic_admin values(0)');app.db.commit()
        with closing(sqlite3.connect(r/'public-handoff-events.sqlite3')) as db:
            db.execute('create table synthetic_bg(n integer)');db.execute('insert into synthetic_bg values(0)');db.commit()
        tokens=[app.new_visitor()[0] for _ in range(3)]
        csrf={t:app.mac('csrf:'+t) for t in tokens};app.close()
        env={**os.environ,'FLOWER_SYNTHETIC_ROOT':str(r)}
        sock=str(Path(tmp)/'gunicorn.sock')
        log=open(Path(tmp)/'gunicorn.log','w+')
        proc=subprocess.Popen([sys.executable,'-m','gunicorn','--bind','unix:'+sock,'--workers','1','--worker-class','gthread','--threads','4','--timeout','30','--graceful-timeout','5','linux_verify:create_app()'],env=env,stdout=log,stderr=log)
        def request(path,data=None,token=tokens[0]):
            c=UnixHTTP(sock);body=json.dumps(data) if data is not None else None
            headers={'Host':'127.0.0.1:8790','Origin':'http://127.0.0.1:8790','Cookie':'flower_visitor='+token,'X-CSRF-Token':csrf[token],'Content-Type':'application/json'}
            try:
                c.request('POST' if data is not None else 'GET',path,body,headers);reply=c.getresponse();return reply.status,json.loads(reply.read())
            finally:c.close()
        def child(mode):return subprocess.Popen([sys.executable,__file__,mode],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        def done(p):
            out,err=p.communicate(timeout=12);assert p.returncode==0,(out,err);return out
        def question():return dict(consultation_id=str(uuid.uuid4()),question_category='其他',question_text='Synthetic only',drawn_card='main_03',orientation='upright',parent_id=None)
        try:
            wait_file(Path(sock));end=time.monotonic()+8
            while True:
                try:
                    if request('/healthz')[0]==200:break
                except (OSError,http.client.HTTPException):pass
                assert time.monotonic()<end;time.sleep(.02)
            with ThreadPoolExecutor(max_workers=2) as pool:
                for index,mode in enumerate(('normal','failure','timeout')):
                    for name in ('held','backup-release','entered','release'):(r/name).unlink(missing_ok=True)
                    (r/'slow').write_text('slow');q=question();future=pool.submit(request,'/api/consult',q,tokens[index]);wait_file(r/'entered')
                    control=child(mode);wait_file(r/'maintenance.pending')
                    blocked=[]
                    for path,data in [('/api/consult',question()),('/api/feedback',{'consultation_id':q['consultation_id'],'feedback_status':'部分貼近','feedback_text':'blocked'}),('/api/handoff-events',{'flow_id':str(uuid.uuid4()),'event':'teacher_clicked'}),('/api/forum-handoff',{}),('/api/session',None)]:blocked.append(request(path,data)[0])
                    assert blocked==[503]*5 and request('/healthz')[0]==200
                    assert 'ADMIN_BLOCKED' in done(child('admin'))
                    if mode=='timeout':
                        output=done(control);assert 'timeout_cancelled' in output and not (r/'maintenance.pending').exists()
                        assert not future.done()
                        (r/'release').write_text('release');assert future.result(5)[0]==200
                    else:
                        assert not (r/'held').exists()
                        (r/'release').write_text('release');assert future.result(5)[0]==200;wait_file(r/'held')
                        before=snap(r);time.sleep(.12);assert snap(r)==before
                        assert 'ADMIN_BLOCKED' in done(child('admin'))
                        (r/'backup-release').write_text('release');output=done(control)
                    assert not (r/'maintenance.pending').exists();(r/'slow').unlink()
                    fb={'consultation_id':q['consultation_id'],'feedback_status':'部分貼近','feedback_text':'Synthetic resumed'}
                    assert request('/api/feedback',fb,tokens[index])[0]==200
                    assert request('/api/consult',q,tokens[index])[0]==200
                    assert len((r/'calls').read_text().splitlines())==index+1
                    with closing(sqlite3.connect(r/'records/consultations.sqlite3')) as db:assert db.execute('select count(*) from consultations').fetchone()[0]==index+1
                    result['results'].append(json.loads(output.split('CONTROLLER ')[1]))
                # Controller crash: no auto-unpause; recover only after both locks are free.
                for name in ('held','backup-release'):(r/name).unlink(missing_ok=True)
                crashed=child('crash');crashed.wait(8);assert crashed.returncode==23
                assert request('/api/session')[0]==503
                with (r/'controller.lock').open('a+b') as c,(r/'maintenance.lock').open('a+b') as m:
                    fcntl.flock(c,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(m,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    (r/'maintenance.pending').unlink()
                assert request('/api/session')[0]==200 and 'ADMIN_ALLOWED' in done(child('admin'))
                result.update(controller_crash_fail_closed_and_locked_recovery=True,background_and_admin_controlled=True,request_paths_blocked=5,records=3,mock_calls=3,paid_calls=0)
        finally:
            proc.terminate()
            try:proc.wait(8)
            except subprocess.TimeoutExpired:proc.kill();proc.wait();raise AssertionError('test gunicorn failed shutdown')
            log.close()
    print('LINUX_QUIESCENCE_PASS '+json.dumps(result),flush=True)

if __name__=='__main__':
    if len(sys.argv)==1:run()
    elif sys.argv[1]=='admin':admin(root())
    else:controller(root(),sys.argv[1])
