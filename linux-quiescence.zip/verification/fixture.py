import json, os, tempfile, uuid, sqlite3
from contextlib import closing
from pathlib import Path
import backend, hosting, public_entry

class SyntheticKnowledge:
    empty='Synthetic fixture only.'
    def context(self,q):
        return {'question':q,'rules':[{'id':'synthetic-rule'}],'reference_cases':[]}

backend.Knowledge=SyntheticKnowledge
def forbidden(*args,**kwargs): raise AssertionError('paid transport is forbidden')
backend.live_request=forbidden
backend.PAID_CALLS_APPROVED=False

def validate_root(value):
    root=Path(value).resolve()
    temp=Path(tempfile.gettempdir()).resolve()
    if not root.is_relative_to(temp) or not any(p.startswith('flower-verification-') for p in root.parts):
        raise RuntimeError('synthetic temp root required')
    if not (root/'.synthetic-only').is_file() or (root/'.synthetic-only').read_text()!='synthetic-only':raise RuntimeError('missing marker')
    return root

def app(root):
    root=validate_root(root)
    return public_entry.build_app({'PUBLIC_EXPERIENCE_MODE':'mock','EXPECTED_VOLUME_ID':'synthetic',
        'PUBLIC_ORIGIN':'http://127.0.0.1:8790','SESSION_SECRET':'synthetic-not-a-secret-'*3},root,production=False)

def seed(root):
    root=Path(root);hosting.bootstrap(root,'synthetic',False)
    (root/'.synthetic-only').write_text('synthetic-only')
    (root/'worker.lock').touch();(root/'io.lock').touch()
    with closing(sqlite3.connect(root/'handoff-events.sqlite3')) as db:
        db.execute('CREATE TABLE synthetic_old_events(value TEXT)');db.execute("INSERT INTO synthetic_old_events VALUES('old synthetic event')");db.commit()
    a=app(root);token,owner=a.new_visitor();q=question()
    status,result=a.consultation(owner,q)
    assert status==200 and result['delivery_status']=='complete',result
    a.svc.feedback(owner,{'consultation_id':q['consultation_id'],'feedback_status':'很貼近','feedback_text':'synthetic feedback'})
    start=a.start_followup(owner,q['consultation_id'])
    with closing(sqlite3.connect(root/'public-handoff-events.sqlite3')) as db:
        db.execute('CREATE TABLE synthetic_new_events(value TEXT)');db.execute("INSERT INTO synthetic_new_events VALUES('new synthetic event')");db.commit()
    a.db.execute("INSERT OR REPLACE INTO public_control VALUES(1,'drain')");a.db.commit();a.close()
    meta={'token':token,'owner':owner,'first':q,'start':start}
    (root/'fixture.json').write_text(json.dumps(meta),encoding='utf-8')
    return meta

def question():
    return dict(consultation_id=str(uuid.uuid4()),question_category='其他',question_text='合成驗收資料，非真實占問',drawn_card='main_03',orientation='upright',parent_id=None)

def snapshot(root):
    result={}
    for rel in ('records/consultations.sqlite3','access/access.sqlite3','handoff-events.sqlite3','public-handoff-events.sqlite3'):
        with closing(sqlite3.connect(Path(root)/rel)) as db:
            tables=[x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
            result[rel]={t:sorted(db.execute('SELECT * FROM "'+t+'"').fetchall(),key=repr) for t in tables}
            assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    result['volume-id']=(Path(root)/'volume-id').read_text()
    return result
