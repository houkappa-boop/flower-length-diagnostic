"""Loaded by every verification subprocess; never included in the served files."""
import sys
def deny_network(event,args):
    if event in ('socket.connect','socket.bind'):
        address=args[1]
        # Linux Gunicorn test uses only Unix-domain sockets, never IP networking.
        if isinstance(address,tuple):
            raise PermissionError('verification forbids IP network operations')
    if event=='socket.getaddrinfo':
        raise PermissionError('verification forbids DNS')
sys.addaudithook(deny_network)
