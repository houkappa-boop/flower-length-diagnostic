"""Only maintenance integration and affected stage-2 differences; synthetic only."""
import fixture
import tempfile,unittest,threading,time,json,os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
import maintenance as m
import public_backup

class Gates(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='flower-verification-gate-')
        self.r=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_pending_does_not_interrupt_accepted_nested_write(self):
        with m.writer(self.r):
            (self.r/'maintenance.pending').write_text('synthetic')
            with m.writer(self.r):pass
            with ThreadPoolExecutor() as pool:
                def fresh():
                    with self.assertRaises(m.Busy):
                        with m.writer(self.r):pass
                pool.submit(fresh).result(3)
        m.recover(self.r)
    def test_orphan_requires_explicit_recovery(self):
        (self.r/'maintenance.pending').write_text('synthetic')
        with self.assertRaises(FileExistsError):
            with m.quiesce(self.r,1):pass
        self.assertTrue((self.r/'maintenance.pending').exists())
        m.recover(self.r)
    def test_unintegrated_live_worker_refused(self):
        with m.file_lock(self.r/'worker.lock',exclusive=True):
            with m.quiesce(self.r,1):
                with self.assertRaises(m.Busy):
                    with m.compatible_worker(self.r):pass
        self.assertFalse((self.r/'maintenance.pending').exists())
    def test_quiesce_timeout_validation_leaves_no_marker(self):
        for val in [0,-1,121,float('nan'),float('inf')]:
            with self.assertRaises(ValueError):
                with m.quiesce(self.r,val):pass
        self.assertFalse((self.r/'maintenance.pending').exists())
    def test_backup_deadline_and_partial_failure_release(self):
        import hosting
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        r=self.r/'data';hosting.bootstrap(r,'synthetic',False)
        h=hosting.HandoffEvents(r/'handoff-events.sqlite3');h.close()
        k=rsa.generate_private_key(public_exponent=65537,key_size=3072)
        pub=k.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
        out=self.r/'failed.enc'
        with self.assertRaises(TimeoutError):
            with m.quiesce(r,1):public_backup.backup(r,pub,out,timeout=1e-12)
        self.assertFalse(out.exists());self.assertFalse((r/'maintenance.pending').exists())
        real=public_backup.os.fsync
        def fail(fd):raise OSError('synthetic write failure')
        with m.quiesce(r,1):
            with patch.object(public_backup.os,'fsync',side_effect=fail):
                with self.assertRaises(OSError):public_backup.backup(r,pub,out)
        self.assertFalse(out.exists());self.assertFalse((r/'maintenance.pending').exists())
        with m.writer(r):pass

names=[
 'test_public_experience.PublicTests.test_ten_people_second_right_and_third_denied',
 'test_public_experience.PublicTests.test_empty_both_rounds_same_id_no_extra_attempt',
 'test_public_experience.PublicTests.test_day_reset_and_old_parent_rejected',
 'test_public_release.ReleaseTests.test_started_before_midnight_question_after_midnight_restart',
 'test_public_release.ReleaseTests.test_same_question_is_checked_after_start',
 'test_public_experience.PublicTests.test_restart_saved_result_feedback_and_reconciliation',
 'test_integration_delta.Integration.test_signed_handoff_at_limit_and_halt_preserves_data',
 'test_integration_delta.Integration.test_csrf_owner_signature_and_destination_rejected',
 'test_integration_delta.Integration.test_feedback_recovery_isolated_no_other_changes',
]
if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Gates)
    suite.addTests(unittest.defaultTestLoader.loadTestsFromNames(names))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    print('INTEGRATION_DELTA '+json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'success':result.wasSuccessful(),'paid_calls':0}),flush=True)
    if not result.wasSuccessful():raise SystemExit(1)
