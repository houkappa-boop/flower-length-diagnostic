"""每日新邀請政策；只新增資料表，保留所有歷史資料及計次。"""
import json
import completion_accounting as accounting
import hashlib
import secrets
from datetime import datetime, timedelta, timezone

TZ = timezone(timedelta(hours=8))
START = datetime(2026, 10, 1, tzinfo=TZ).timestamp()
INVITATION_DAYS = 3  # 新批次含適用當日共三天；已建立批次保留原到期日。


def migrate(db, legacy, now):
    db.executescript('''
      CREATE TABLE IF NOT EXISTS beta_invitations (
        invite_id TEXT PRIMARY KEY REFERENCES invites(id),
        batch TEXT NOT NULL, label TEXT NOT NULL,
        source TEXT NOT NULL, valid_from REAL NOT NULL, created REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS beta_entries (
        id INTEGER PRIMARY KEY, invite_id TEXT NOT NULL, created REAL NOT NULL, day TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS beta_batches (
        day TEXT PRIMARY KEY, created REAL NOT NULL, private_payload TEXT NOT NULL);
    ''')
    for n, ident in enumerate(legacy, 1):
        if not db.execute('SELECT 1 FROM invites WHERE id=?', (ident,)).fetchone():
            raise RuntimeError('舊邀請資料不完整，停止改制')
        db.execute('INSERT OR IGNORE INTO beta_invitations VALUES(?,?,?,?,?,?)',
                   (ident, '舊批次十二人', '舊%02d' % n, '未分類', 0, now))
    db.commit()


def state(db, records, owner):
    import backend
    if accounting.exists(db):
        current=db.execute('SELECT b.state FROM beta_completion b JOIN requests r ON r.cid=b.cid WHERE r.invite_id=?',(owner,)).fetchall()
        if any(r[0]=='reserved' for r in current):return 'unknown'
        if any(r[0]=='failed' for r in current):return 'review'
    rows = db.execute('SELECT cid,state FROM requests WHERE invite_id=? AND charged=1 ORDER BY created', (owner,)).fetchall()
    statuses = []
    for cid, request_state in rows:
        r = records.execute('SELECT * FROM consultations WHERE consultation_id=? AND session_id=?', (cid,owner)).fetchone()
        status = r['api_status'].removeprefix('mock_') if r else 'unknown'
        if status == 'grounded':
            # A model status alone does not prove a committed, readable result.
            if request_state != 'finished' or not backend.saved_complete(r):
                status = 'delivery_incomplete'
        statuses.append(status)
    if 'grounded' in statuses:
        return 'completed'
    if any(s not in ('api_failure_no_retry', 'failure_no_retry', 'needs_clarification', 'insufficient_approved_data', 'delivery_incomplete') for s in statuses):
        return 'unknown'
    if statuses:
        return 'review'  # 未標為成功；保留權利，人工查核前不再觸發付費請求。
    return 'unused'


def capacity(db, records, day, now):
    start = datetime.strptime(day, '%Y-%m-%d').replace(tzinfo=TZ).timestamp()
    end = start + INVITATION_DAYS * 86400
    used = accounting.student_used(db)
    pending = []
    for ident, valid_from, expires in db.execute('''SELECT m.invite_id,m.valid_from,i.expires
            FROM beta_invitations m JOIN invites i ON i.id=m.invite_id
            WHERE i.revoked=0 AND i.expires>?''', (now,)):
        if state(db, records, ident) != 'completed':
            pending.append((ident, valid_from, expires))
    # 發碼與解牌分開：每個適用日期最多十二個新碼，舊碼不預留容量。
    # 包含已用、到期或撤銷的同批碼，不能藉狀態變更繞過發碼上限。
    issued = db.execute('SELECT count(*) FROM beta_invitations WHERE batch=?', (day,)).fetchone()[0]
    available = max(0, 12 - issued)
    return available, used, len(pending), start, end


def issue(db, records, day, now, source='待標記'):
    if source not in ('待標記', '一般體驗者', '前期學生'):
        raise ValueError('來源標記不正確')
    if now < START:
        raise ValueError('新制度尚未生效')
    today = datetime.fromtimestamp(now, TZ).date()
    target = datetime.strptime(day, '%Y-%m-%d').date()
    if target not in (today, today + timedelta(days=1)):
        raise ValueError('只可交付今日或隔日批次')
    db.execute('BEGIN IMMEDIATE')
    try:
        existing = db.execute('SELECT private_payload FROM beta_batches WHERE day=?', (day,)).fetchone()
        if existing:
            db.rollback()
            return json.loads(existing[0])
        count, used, pending, start, end = capacity(db, records, day, now)
        if count <= 0:
            raise ValueError('此適用日期已發滿十二個新邀請碼，未產生新碼')
        result = {'適用日期': day, '可開始使用': datetime.fromtimestamp(max(start, now), TZ).isoformat(),
                  '有效至': datetime.fromtimestamp(end, TZ).isoformat(), '數量': count,
                  '累計已計次': used, '剩餘總額度': max(0,100-used), '既有未完成邀請': pending,
                  '使用提醒': '邀請碼不保留解牌名額；送出 AI 解牌時檢查每日十二次及累計一百次。當日額滿請在邀請有效期限內隔天再試。', '邀請': []}
        for n in range(1, count+1):
            ident, code = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
            label = day + '-%02d' % n
            db.execute('INSERT INTO invites VALUES(?,?,?,0)', (ident, hashlib.sha256(code.encode()).hexdigest(), end))
            db.execute('INSERT INTO beta_invitations VALUES(?,?,?,?,?,?)', (ident, day, label, source, start, now))
            result['邀請'].append({'編號': label, '來源': source, '邀請碼': code})
        db.execute('INSERT INTO beta_batches VALUES(?,?,?)', (day, now, json.dumps(result, ensure_ascii=False)))
        db.commit()
        return result
    except Exception:
        db.rollback()
        raise


def report(db, records):
    rows = []
    for ident, batch, label, source, valid_from, created in db.execute('SELECT * FROM beta_invitations ORDER BY created,label'):
        requests = db.execute('SELECT cid,charged,state,day FROM requests WHERE invite_id=? ORDER BY created', (ident,)).fetchall()
        success = failure = unknown = incomplete = feedback = 0
        for cid, charged, request_state, day in requests:
            r = records.execute('SELECT api_status,feedback_status FROM consultations WHERE consultation_id=?', (cid,)).fetchone()
            feedback += bool(r and r[1] != 'not_submitted')
            completion = db.execute('SELECT state FROM beta_completion WHERE cid=?',(cid,)).fetchone() if accounting.exists(db) else None
            if completion:
                if completion[0]=='complete':success += 1
                elif completion[0]=='failed':failure += 1
                else:unknown += 1
                continue
            if not charged:
                continue
            status = r[0].removeprefix('mock_') if r else 'unknown'
            if status == 'grounded': success += 1
            elif status in ('api_failure_no_retry', 'failure_no_retry'): failure += 1
            elif status in ('needs_clarification', 'insufficient_approved_data'): incomplete += 1
            else: unknown += 1
        entries = db.execute('SELECT count(*) FROM beta_entries WHERE invite_id=?', (ident,)).fetchone()[0]
        rows.append({'編號': label, '批次': batch, '來源': source, '狀態': state(db, records, ident),
                     '進入': entries, '請求': len(requests), '成功': success, '失敗': failure,
                     '待確認': unknown, '資料不足': incomplete, '回饋': feedback})
    daily = db.execute('''SELECT day,count(*),count(distinct invite_id),sum(charged)
                         FROM requests GROUP BY day ORDER BY day''').fetchall()
    used = accounting.student_used(db)
    return {'累計已計次': used, '剩餘總額度': max(0,100-used), '每日摘要': [tuple(r) for r in daily], '邀請明細': rows}
