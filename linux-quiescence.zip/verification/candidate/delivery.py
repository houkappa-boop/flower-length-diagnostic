"""Pure presentation policy. Never writes records, calls models, or changes billing."""
import re

POLICY_VERSION = 'DELIVERY-CONTEXT-20261004-v1'
UNAVAILABLE = '這次暫時無法提供完整解讀，請保留牌面並聯絡老師；系統不會自動重新解牌。'
PARTIAL = '部分內容含內部資訊，暫未顯示；以下保留可顯示的原文，請聯絡老師確認完整解讀。'
SECRET = re.compile(r'sk-[A-Za-z0-9_-]{12,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bBearer\s+[A-Za-z0-9._~-]{16,}', re.I)
# Ordinary Chinese words, brackets and standalone product versions are NOT markers.
RULES = {
    'internal_identifier': re.compile(r'(?<![A-Za-z0-9_])(?:[A-Z]{2,}-(?:[A-Z0-9]+-)*\d{8}(?:-[A-Za-z0-9]+)*|ENGINE-V\d+-\d+|OUTPUT-[A-Z][A-Z0-9-]+|V7-[A-Z0-9-]+)(?![A-Za-z0-9_])'),
    'metadata_field': re.compile(r'(?i)\b(?:source[ _-]?ids?|rule[ _-]?ids?|rule_version|system_prompt|interpretation_text|client_display_text)\b\s*["\x27]?\s*[:=：]|(?:規則\s*ID|來源\s*ID|引用標記)\s*[:=：]'),
    'internal_version': re.compile(r'(?:系統|模型|規則|母資料|提示詞|輸出政策)版本(?:號)?\s*[:=：]?\s*(?:v?\d+(?:\.\d+)*|[A-Z][A-Z0-9_-]{3,})', re.I),
    'internal_explanation': re.compile(r'(?:系統提示詞|系統指令|隱藏提示詞|內部推理|系統推理過程|合規的判讀|母規則)\s*(?:[:：=]|要求|規定|指出|如下|顯示|是)|(?:依據|根據|依照|遵循|依)(?:本次|目前|上述|核准的?|內部的?)?(?:母規則|系統指令|系統提示詞|內部推理)'),
    'technical_explanation': re.compile(r'化氣(?:為|是)|(?:這張牌|本牌|牌義|牌理|星曜|太陽|太陰|七殺|紫微|天同|天梁|天機|武曲|巨門|破軍|天相|天府|貪狼|廉貞)[^。！？\n]{0,28}(?:官祿主|官祿宮主|福星|父母星|化氣)|(?:牌義|牌理|星曜)[^。！？\n]{0,16}(?:光熱|光與熱|先破後立)'),
    'structured_envelope': re.compile(r'^\s*(?:```(?:json|python|javascript)?\s*|\{\s*"(?:status|interpretation|source_ids|instructions)"\s*:)', re.I),
}

def present(text):
    """Keep safe paragraphs byte-for-byte; withhold explicit internal paragraphs."""
    if not isinstance(text, str) or not text.strip() or len(text) > 20000 or '\x00' in text:
        return {'text': UNAVAILABLE, 'status': 'unavailable', 'reasons': ['invalid_text']}
    if SECRET.search(text):
        return {'text': UNAVAILABLE, 'status': 'blocked', 'reasons': ['sensitive_content']}
    chunks = re.split(r'(\n\s*\n)', text)
    rejected = {}
    for i in range(0, len(chunks), 2):
        matches = [name for name, pattern in RULES.items() if pattern.search(chunks[i])]
        if matches:
            rejected[i] = matches
    if not rejected:
        return {'text': text, 'status': 'complete', 'reasons': []}
    kept = [chunks[i] for i in range(0, len(chunks), 2) if i not in rejected and chunks[i].strip()]
    reasons = sorted({reason for values in rejected.values() for reason in values})
    if not kept:
        return {'text': UNAVAILABLE, 'status': 'blocked', 'reasons': reasons}
    return {'text': PARTIAL + '\n\n' + '\n\n'.join(kept), 'status': 'partial', 'reasons': reasons}
