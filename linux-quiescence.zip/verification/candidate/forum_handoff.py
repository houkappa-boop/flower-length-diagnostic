"""Disabled-by-default signing boundary. No model calls or accounting writes.

Keys are supplied only through process environment. Configuration is deliberately
not generated here and must never be included in a release archive.
"""
import maintenance
import base64
import hashlib
import hmac
import json
import os
import re
import sqlite3
import uuid
from contextlib import closing

SOURCE = 'https://ziwei-flower-beta.onrender.com'
DESTINATION = 'https://anitahou.com'
AUDIENCE = DESTINATION + '/flower-handoff/receive'


def keyring(purpose):
    value = json.loads(os.environ['FLOWER_' + purpose + '_KEYRING'])
    active, keys = value['active'], value['keys']
    if not isinstance(keys, dict) or active not in keys or len(keys) > 4:
        raise ValueError('configuration')
    decoded = {}
    for kid, text in keys.items():
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,32}', kid):
            raise ValueError('configuration')
        raw = base64.b64decode(text, validate=True)
        if len(raw) != 32:
            raise ValueError('configuration')
        decoded[kid] = raw
    return active, decoded


def sign(value, ring):
    kid, keys = ring
    payload = base64.urlsafe_b64encode(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()).decode().rstrip('=')
    message = 'v1.' + kid + '.' + payload
    return message + '.' + hmac.new(keys[kid], message.encode(), hashlib.sha256).hexdigest()


def verify(token, ring):
    if not isinstance(token, str) or len(token) > 180000:
        raise ValueError('request')
    version, kid, payload, signature = token.split('.')
    message = '.'.join((version, kid, payload))
    if version != 'v1' or kid not in ring[1] or not hmac.compare_digest(signature, hmac.new(ring[1][kid], message.encode(), hashlib.sha256).hexdigest()):
        raise ValueError('request')
    return json.loads(base64.b64decode(payload + '=' * (-len(payload) % 4), altchars=b'-_', validate=True))


def uuid4(value):
    return isinstance(value, str) and str(uuid.UUID(value, version=4)) == value


@maintenance.method
def prepare(app, owner, data):
    if os.environ.get('FLOWER_FORUM_HANDOFF_ENABLED') != 'true':
        return 503, {'error': '老師諮詢交接暫未開放，原內容仍保留。'}
    try:
        challenge_ring, signing_ring = keyring('CHALLENGE'), keyring('SIGNING')
        if set(challenge_ring[1].values()) & set(signing_ring[1].values()):
            raise ValueError('configuration')
        now = int(app.clock())
        c = verify(data['challenge'], challenge_ring)
        if c.get('source') != SOURCE or c.get('destination') != DESTINATION or c.get('audience') != AUDIENCE or not uuid4(c.get('tx')) or not uuid4(c.get('flow')) or not now < c['until'] <= now + 300:
            raise ValueError('request')
        cid, draft = data['consultation_id'], data['draft']
        if not uuid4(cid) or draft.get('version') != 2 or draft.get('flow') != c['flow'] or not uuid4(draft.get('token')):
            raise ValueError('request')
        expiry = draft['expires'] // 1000
        if not now < expiry <= now + 7200:
            raise ValueError('request')
        fields = draft['draft']
        for field, limit in [('subject', 600), ('body', 92000)]:
            if not isinstance(fields[field], str) or not fields[field].strip() or len(fields[field].encode()) > limit:
                raise ValueError('request')
        # Ownership read only: never draw_gate(), reserve(), consult(), or feedback().
        with app.svc.lock:
            row = app.svc.db.execute('SELECT api_status FROM consultations WHERE consultation_id=? AND session_id=?', (cid, app.record_owner(owner,cid))).fetchone()
        if not row or row['api_status'] in ('processing', 'empty_no_api'):
            raise ValueError('request')
        # A flow's first expiry is immutable, even after draft/transaction cleanup.
        # This separate ledger contains no question, answer, feedback or credentials.
        with closing(sqlite3.connect(app.root / 'forum-handoff.sqlite3', timeout=5)) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS flow_receipts(flow TEXT PRIMARY KEY, owner TEXT NOT NULL, cid TEXT NOT NULL, expires INTEGER NOT NULL)')
            db.execute('INSERT OR IGNORE INTO flow_receipts VALUES(?,?,?,?)', (c['flow'], hashlib.sha256(owner.encode()).hexdigest(), cid, expiry))
            stored = db.execute('SELECT owner,cid,expires FROM flow_receipts WHERE flow=?', (c['flow'],)).fetchone()
            if stored[0] != hashlib.sha256(owner.encode()).hexdigest() or stored[1] != cid or stored[2] <= now:
                raise ValueError('request')
            expiry = min(expiry, stored[2])
        clean = {'version': 2, 'flow': c['flow'], 'token': draft['token'], 'expires': expiry * 1000,
                 'draft': {'subject': fields['subject'], 'body': fields['body']}}
        return 200, {'envelope': sign({'challenge': data['challenge'], 'draft': clean, 'audience': AUDIENCE}, signing_ring)}
    except (KeyError, ValueError, TypeError, AttributeError, OverflowError):
        return 403, {'error': '無法確認這次草稿的交接資格，原內容仍保留。'}
