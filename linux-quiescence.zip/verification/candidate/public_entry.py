"""Deployment entry candidate. Importing does nothing; defaults to locked transport.

Use public_entry:create_app() only AFTER an approved deployment/backup plan.
Tests use build_app with synthetic paths; create_app is never called in testing.
"""
import os
import backend
from hosting import check_volume
from public_experience import PublicHosting


def build_app(config,root,*,production=True,clock=None):
    mode=config.get('PUBLIC_EXPERIENCE_MODE','locked')
    approved=config.get('PUBLIC_RELEASE_APPROVED')=='true'
    paid=config.get('PAID_CALLS_ENABLED','false')=='true'
    if mode not in ('locked','mock','live') or (mode=='mock' and production):raise ValueError('invalid public mode')
    if mode=='live' and not (production and approved and paid and config.get('OPENAI_API_KEY')):
        raise ValueError('release and paid transport require explicit authorization')
    if mode!='live' and paid:raise ValueError('paid flag conflicts with locked mode')
    cap=int(config.get('PUBLIC_DAILY_VISITORS','10'))
    attempts=int(config.get('PUBLIC_DAILY_ATTEMPTS',str(cap*2)))
    backend.PAID_CALLS_APPROVED=mode=='live'
    kwargs={'clock':clock} if clock else {}
    return PublicHosting(root,config['EXPECTED_VOLUME_ID'],config['PUBLIC_ORIGIN'].rstrip('/'),config['SESSION_SECRET'],
        production=production,mode=mode,accepting=mode in ('live','mock'),paid_authorized=approved,
        daily_visitors=cap,attempt_limit=attempts,**kwargs)


def create_app():
    # Existing single-worker / persistent-volume architecture is retained.
    import fcntl
    root=check_volume('/var/data/flower',os.environ['EXPECTED_VOLUME_ID'])
    singleton=(root/'worker.lock').open('a+b')
    fcntl.flock(singleton,fcntl.LOCK_EX|fcntl.LOCK_NB)
    try:app=build_app(dict(os.environ),root)
    except Exception:singleton.close();raise
    app.singleton=singleton
    return app
