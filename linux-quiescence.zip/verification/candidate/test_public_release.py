import hashlib
import io
import json
import sqlite3
import tempfile
import threading
import unittest
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from unittest.mock import patch
import backend
import hosting
from public_entry import build_app
from public_experience import Rejected,TZ
from test_public_experience import PublicTests


class ReleaseTests(PublicTests):
    def test_start_uses_one_authoritative_clock_sample_inside_transaction(self):
        first=self.complete()
        before=datetime(2026,10,23,23,59,59,tzinfo=TZ).timestamp()
        calls=[]
        def advancing():
            calls.append(1);return before+len(calls)-1
        self.app.clock=advancing
        started=self.app.start_followup(self.owner,first['consultation_id'])
        self.assertEqual(started['day'],'2026-10-23')
        self.assertEqual(len(calls),1)

    def test_started_before_midnight_question_after_midnight_restart(self):
        first=self.complete()
        self.now=datetime(2026,10,23,23,59,59,tzinfo=TZ).timestamp()
        started=self.app.start_followup(self.owner,first['consultation_id'])
        self.now+=2;self.app.close();self.app=self.open()
        status=self.app.state(self.owner)
        self.assertEqual(status['day'],'2026-10-24')
        self.assertEqual(status['started_followup']['cid'],started['cid'])
        self.complete(parent=first['consultation_id'],cid=started['cid'],text='跨日後如何準備合作？')
        self.assertEqual(self.app.rounds(self.owner),[])
        self.complete()
        self.assertEqual(len(self.app.rounds(self.owner)),1)

    def test_unstarted_parent_cannot_start_at_midnight(self):
        first=self.complete();self.now=datetime(2026,10,24,0,0,tzinfo=TZ).timestamp()
        with self.assertRaises(Rejected) as exc:self.app.start_followup(self.owner,first['consultation_id'])
        self.assertEqual(exc.exception.payload['code'],'FOLLOWUP_EXPIRED')
        self.assertEqual(self.app.db.execute('SELECT count(*) FROM public_starts').fetchone()[0],0)

    def test_empty_followup_spans_midnight_and_keeps_both_day_quotas(self):
        first=self.complete();self.now=datetime(2026,10,23,23,59,59,tzinfo=TZ).timestamp()
        started=self.app.start_followup(self.owner,first['consultation_id'])
        q=self.q(parent=first['consultation_id'],cid=started['cid'],empty=True,text='如何安排下一步？')
        self.app.consultation(self.owner,q);self.now+=181
        self.app.close();self.app=self.open()
        self.assertEqual(self.app.state(self.owner)['empty_continuation']['consultation_id'],started['cid'])
        self.complete(parent=first['consultation_id'],cid=started['cid'],text=q['question_text'])
        self.assertEqual(self.app.db.execute("SELECT count(*) FROM public_rounds WHERE day='2026-10-24'").fetchone()[0],0)
        self.assertEqual(self.app.db.execute("SELECT sum(attempted) FROM public_rounds WHERE day='2026-10-23'").fetchone()[0],2)

    def test_midnight_parent_and_today_capacity_are_independent(self):
        first=self.complete()
        self.now=datetime(2026,10,23,23,59,59,tzinfo=TZ).timestamp()
        started=self.app.start_followup(self.owner,first['consultation_id'])
        self.now+=2
        for _ in range(10):self.complete(self.app.new_visitor()[1])
        self.complete(parent=first['consultation_id'],cid=started['cid'],text='跨日延伸的不同面向？')
        self.assertEqual(self.app.db.execute("SELECT count(distinct owner) FROM public_rounds WHERE day='2026-10-24' AND state='complete'").fetchone()[0],10)
        with self.assertRaises(Rejected):self.complete()

    def test_concurrent_start_doubleclick_only_one_persistent_ticket(self):
        first=self.complete();peer=self.open()
        barrier=threading.Barrier(2)
        def start(app):barrier.wait();return app.start_followup(self.owner,first['consultation_id'])['cid']
        try:
            with ThreadPoolExecutor(max_workers=2) as pool:ids=list(pool.map(start,[self.app,peer]))
            self.assertEqual(ids[0],ids[1]);self.assertEqual(self.app.db.execute('SELECT count(*) FROM public_starts').fetchone()[0],1)
        finally:peer.close()

    def test_inflight_followup_midnight_new_visitor_and_replay(self):
        first=self.complete();self.now=datetime(2026,10,23,23,59,59,tzinfo=TZ).timestamp()
        started=self.app.start_followup(self.owner,first['consultation_id'])
        entered=threading.Event();release=threading.Event();captured=[]
        def wait_transport(ctx):
            captured.append(ctx)
            if 'followup_context' in ctx:
                entered.set();self.assertTrue(release.wait(5))
            return backend.mock_request(ctx)
        self.app.svc.transport=wait_transport
        q=self.q(parent=first['consultation_id'],cid=started['cid'],text='明天該如何分工？')
        with ThreadPoolExecutor(max_workers=2) as pool:
            future=pool.submit(self.app.consultation,self.owner,q)
            self.assertTrue(entered.wait(5));self.now+=2
            try:self.complete(self.app.new_visitor()[1])
            finally:release.set()
            self.assertEqual(future.result()[1]['delivery_status'],'complete')
        self.app.consultation(self.owner,q)
        self.assertEqual(len(captured),2)
        self.assertNotIn('followup_context',captured[1])
        self.assertEqual(self.app.db.execute("SELECT count(*) FROM public_rounds WHERE day='2026-10-24'").fetchone()[0],1)

    def test_same_question_is_checked_after_start(self):
        first=self.complete();start=self.app.start_followup(self.owner,first['consultation_id'])
        with self.assertRaises(Rejected) as exc:self.app.consultation(self.owner,self.q(parent=first['consultation_id'],cid=start['cid']))
        self.assertEqual(exc.exception.payload['code'],'SAME_QUESTION')
        self.assertEqual(self.app.db.execute('SELECT sum(attempted) FROM public_rounds').fetchone()[0],1)

    def test_factory_locked_and_live_flags_do_not_call_provider(self):
        config={'PUBLIC_ORIGIN':'http://127.0.0.1:8790','EXPECTED_VOLUME_ID':'synthetic','SESSION_SECRET':'x'*40}
        with patch('backend.live_request',side_effect=AssertionError('paid transport forbidden')):
            locked=build_app(config,self.root,production=False,clock=lambda:self.now)
            try:
                self.assertEqual(locked.svc.mode,'locked');self.assertEqual(locked.state(self.owner)['beta_gate']['code'],'SERVICE_LOCKED')
            finally:locked.close()
            for changes in ({'PUBLIC_EXPERIENCE_MODE':'live'},{'PAID_CALLS_ENABLED':'true'},
                            {'PUBLIC_EXPERIENCE_MODE':'live','PAID_CALLS_ENABLED':'true','PUBLIC_RELEASE_APPROVED':'true','OPENAI_API_KEY':'synthetic'}):
                with self.assertRaises(ValueError):build_app({**config,**changes},self.root,production=False)


class LegacyCompatibilityTests(unittest.TestCase):
    def test_legacy_rows_startup_preserved_history_links_feedback_and_revocation(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/'data';hosting.bootstrap(root,'synthetic',False)
            now=datetime(2026,10,23,12,tzinfo=TZ).timestamp()
            old=hosting.Hosting(root,'synthetic','http://127.0.0.1:8790','x'*40,production=False,mode='mock',accepting=True,clock=lambda:now)
            owner,code=old.invite();cid=str(uuid.uuid4())
            old.consultation(owner,{'consultation_id':cid,'question_category':'工作事業','question_text':'歷史合成問題','drawn_card':'main_01','orientation':'upright'})
            old.svc.feedback(owner,{'consultation_id':cid,'feedback_status':'很貼近','feedback_text':'歷史合成回饋'})
            old.db.execute('INSERT INTO sessions VALUES(?,?,?)',(hosting.digest('old-session'),owner,now+10000))
            old.db.execute("INSERT INTO requests VALUES(?,?,?,?,?,?,?,?,?)",(str(uuid.uuid4()),owner,'synthetic',now,'2026-10-23','2026-10',0,'started',0))
            old.db.commit()
            old.handoff_events.record({'flow_id':str(uuid.uuid4()),'event':'teacher_clicked'})
            before_records=[tuple(r) for r in old.svc.db.execute('SELECT * FROM consultations')]
            before_access={name:[tuple(r) for r in old.db.execute('SELECT * FROM '+name)] for name in ['invites','sessions','requests','beta_completion']}
            old.close()
            event_bytes=(root/'handoff-events.sqlite3').read_bytes()
            from public_experience import PublicHosting
            app=PublicHosting(root,'synthetic','http://127.0.0.1:8790','x'*40,production=False,mode='mock',accepting=True,clock=lambda:now)
            try:
                self.assertEqual(before_records,[tuple(r) for r in app.svc.db.execute('SELECT * FROM consultations')])
                for name,rows in before_access.items():self.assertEqual(rows,[tuple(r) for r in app.db.execute('SELECT * FROM '+name)])
                self.assertEqual((root/'handoff-events.sqlite3').read_bytes(),event_bytes)
                token,new_owner=app.new_visitor()
                with self.assertRaises(Rejected):app.saved_result(new_owner,cid)
                def http(path,method='GET',data=None,cookie=None):
                    raw=json.dumps(data or {}).encode();reply={}
                    env={'PATH_INFO':path.partition('?')[0],'QUERY_STRING':path.partition('?')[2],
                         'REQUEST_METHOD':method,'HTTP_HOST':app.host,'HTTP_ORIGIN':app.origin,
                         'HTTP_COOKIE':cookie if cookie is not None else 'flower_visitor='+token,
                         'HTTP_X_CSRF_TOKEN':app.mac('csrf:'+token),'CONTENT_TYPE':'application/json',
                         'CONTENT_LENGTH':str(len(raw)),'wsgi.input':io.BytesIO(raw)}
                    def start(status,headers):reply['status']=int(status.split()[0])
                    reply['body']=json.loads(b''.join(app(env,start)));return reply
                response=http('/api/session',cookie='flower_visitor='+token+'; flower_session=old-session')
                self.assertEqual(response['status'],200)
                self.assertIn(cid,[r['consultation_id'] for r in http('/api/consultations')['body']['consultations']])
                self.assertEqual(http('/api/consultation?id='+cid)['status'],200)
                token2,owner2=app.new_visitor()
                previous_token=token;token=token2
                self.assertEqual(http('/api/legacy-link','POST',{'invite':'wrong'})['status'],403)
                self.assertEqual(http('/api/legacy-link','POST',{'invite':code})['status'],200)
                self.assertEqual(http('/api/consultation?id='+cid)['status'],200)
                token=previous_token
                saved=app.saved_result(new_owner,cid)
                self.assertEqual(saved['question']['question_text'],'歷史合成問題')
                self.assertEqual(app.svc.db.execute('SELECT feedback_text FROM consultations WHERE consultation_id=?',(cid,)).fetchone()[0],'歷史合成回饋')
                app.svc.feedback(app.record_owner(new_owner,cid),{'consultation_id':cid,'feedback_status':'部分貼近','feedback_text':'已授權測試更新回饋'})
                self.assertEqual(app.rounds(new_owner),[])
                stranger=app.new_visitor()[1]
                with self.assertRaises(Rejected):app.saved_result(stranger,cid)
                app.db.execute('UPDATE invites SET revoked=1 WHERE id=?',(owner,));app.db.commit()
                with self.assertRaises(Rejected):app.saved_result(new_owner,cid)
                self.assertEqual(http('/api/consultation?id='+cid)['status'],404)
            finally:app.close()

    def test_historical_fingerprint_difference_is_only_reminder_and_newline(self):
        root=Path(__file__).parent
        current=(root/'public/index.html').read_bytes()
        import re
        historical=re.sub(br'<p class="pre-draw-reminder".*?</p>',b'',current,count=1).rstrip(b'\r\n')
        self.assertEqual(hashlib.sha256(historical).hexdigest(),'275e5d64f3a77cd77dbe82c3eb7f0326e1f3a65a5c8b482ea8176993e84359e0')

if __name__=='__main__':unittest.main()
