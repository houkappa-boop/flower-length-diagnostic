"""Hosting boundary: default locked, explicit one-attempt teacher acceptance gate."""
import hashlib
import hmac
import json
import mimetypes
import os
import secrets
import shutil
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timezone, timedelta
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

import backend
import beta_policy
import completion_accounting as accounting
import invite_diagnostics
from handoff_events import HandoffEvents

ROOT = Path(__file__).resolve().parent
CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'"
TZ = timezone(timedelta(hours=8))
BETA_ONCE_START = datetime(2026,10,1,tzinfo=TZ).timestamp()


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def database(path):
    db = sqlite3.connect(path, check_same_thread=False, timeout=5)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=FULL')
    return db


def check_volume(root, expected, production=True):
    root = Path(root).resolve()
    if production and (root != Path('/var/data/flower') or not os.path.ismount('/var/data')):
        raise RuntimeError('persistent mount unavailable')
    if not expected or not (root / 'volume-id').is_file():
        raise RuntimeError('volume not initialized')
    if (root / 'volume-id').read_text().strip() != expected:
        raise RuntimeError('volume identity mismatch')
    for name in ('records/consultations.sqlite3', 'access/access.sqlite3'):
        if not (root / name).is_file():
            raise RuntimeError('required database missing')
    return root


def bootstrap(root, expected, production=True):
    root = Path(root).resolve()
    if production and (root != Path('/var/data/flower') or not os.path.ismount('/var/data')):
        raise RuntimeError('persistent mount unavailable')
    if not expected or (root.exists() and any(root.iterdir())):
        raise RuntimeError('bootstrap requires a new empty directory and identity')
    root.mkdir(parents=True, exist_ok=True)
    for part in ('records', 'access', 'backups'):
        (root / part).mkdir()
    svc = backend.Service(str(root / 'records/consultations.sqlite3'), 'locked')
    svc.db.close()
    db = database(root / 'access/access.sqlite3')
    db.executescript('''
      CREATE TABLE invites(id TEXT PRIMARY KEY, code_hash TEXT UNIQUE NOT NULL,
        expires REAL NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE sessions(token_hash TEXT PRIMARY KEY, invite_id TEXT NOT NULL,
        expires REAL NOT NULL);
      CREATE TABLE requests(cid TEXT PRIMARY KEY, invite_id TEXT NOT NULL,
        request_hash TEXT NOT NULL, created REAL NOT NULL, day TEXT NOT NULL,
        month TEXT NOT NULL, charged INTEGER NOT NULL, state TEXT NOT NULL,
        cooldown REAL NOT NULL DEFAULT 0);
      CREATE TABLE attempts(bucket TEXT PRIMARY KEY, start REAL NOT NULL, count INTEGER NOT NULL);
      CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
      INSERT INTO meta VALUES('schema','1');
    ''')
    db.commit()
    db.close()
    (root / 'volume-id').write_text(expected, encoding='utf-8')


class Hosting:
    def __init__(self, root, expected, origin, secret, *, production=True,
                 accepting=False, mode='locked', daily=3, global_daily=30,
                 monthly=300, clock=time.time, teacher_ids=(), student_ids=()):
        self.root = check_volume(root, expected, production)
        parsed = urlsplit(origin)
        if parsed.path or parsed.query or parsed.fragment or not parsed.netloc or parsed.username:
            raise RuntimeError('invalid origin')
        if production and parsed.scheme != 'https':
            raise RuntimeError('HTTPS required')
        legacy_student_ids = tuple(student_ids)
        teacher_ids = frozenset(teacher_ids)
        student_ids = frozenset(student_ids)
        if student_ids and (teacher_ids or len(student_ids)>12 or (daily,global_daily,monthly)!=(1,12,100)):
            raise RuntimeError('invalid student beta limits')
        if len(secret) < 32 or mode not in ('locked', 'mock', 'live') or (production and mode == 'mock'):
            raise RuntimeError('invalid configuration; live mode is not authorized')
        if mode == 'live' and (not (teacher_ids or student_ids) or not backend.PAID_CALLS_APPROVED):
            raise RuntimeError('teacher approval required')
        self.teacher_ids = teacher_ids
        self.student_ids = student_ids
        self.access_ids = teacher_ids or student_ids
        if min(daily, global_daily, monthly) < 1:
            raise RuntimeError('invalid limits')
        self.origin, self.host, self.secret = origin, parsed.netloc, secret.encode()
        self.production, self.accepting, self.clock = production, accepting, clock
        self.limits = daily, global_daily, monthly
        self.lock = threading.RLock()
        self.db = database(self.root / 'access/access.sqlite3')
        if self.db.execute("SELECT value FROM meta WHERE key='schema'").fetchone()[0] != '1':
            raise RuntimeError('unknown schema')
        if self.teacher_ids:
            for ident in self.teacher_ids:
                if not self.db.execute('SELECT 1 FROM invites WHERE id=? AND revoked=0 AND expires>?', (ident, clock())).fetchone():
                    self.db.close()
                    raise RuntimeError('teacher invitation unavailable')
        self.db.execute('CREATE TABLE IF NOT EXISTS teacher_paid_attempt (id INTEGER PRIMARY KEY CHECK(id=1), cid TEXT UNIQUE NOT NULL, created REAL NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS student_paid_attempts (cid TEXT PRIMARY KEY, created REAL NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS empty_continuations (empty_cid TEXT PRIMARY KEY, main_cid TEXT UNIQUE NOT NULL, created REAL NOT NULL)')
        self.db.commit()
        accounting.migrate(self.db)
        self.svc = backend.Service(str(self.root / 'records/consultations.sqlite3'), mode, clock=clock)
        self.svc.db.execute('PRAGMA synchronous=FULL')
        self.svc.db.execute('PRAGMA busy_timeout=5000')
        self.db.execute("UPDATE requests SET state='interrupted' WHERE state='started'")
        self.db.commit()
        self.active = set()
        self.handoff_events = HandoffEvents(self.root / 'handoff-events.sqlite3', clock, production)
        if self.student_ids:
            beta_policy.migrate(self.db, legacy_student_ids, clock())

    def close(self):
        self.handoff_events.close()
        self.db.close()
        self.svc.db.close()

    def invite(self, days=7):
        if not 1 <= days <= 90:
            raise ValueError('invalid expiry')
        code = secrets.token_urlsafe(32)
        ident = secrets.token_urlsafe(32)
        with self.lock:
            self.db.execute('INSERT INTO invites VALUES(?,?,?,0)',
                            (ident, digest(code), self.clock() + days * 86400))
            self.db.commit()
        return ident, code

    def mac(self, value):
        return hmac.new(self.secret, value.encode(), hashlib.sha256).hexdigest()

    def cookie(self, name, value, seconds):
        return f'{name}={value}; Path=/; HttpOnly; SameSite=Strict; Max-Age={seconds}' + ('; Secure' if self.production else '')

    def session(self, token):
        with self.lock:
            row = self.db.execute('''SELECT i.id FROM sessions s JOIN invites i ON i.id=s.invite_id
                WHERE token_hash=? AND s.expires>? AND i.expires>? AND i.revoked=0''',
                (digest(token), self.clock(), self.clock())).fetchone()
        return row['id'] if row and self.allowed(row['id']) else None

    def allowed(self, owner):
        if self.student_ids:
            if self.clock() < BETA_ONCE_START:
                return owner in self.student_ids
            return bool(self.db.execute('SELECT 1 FROM beta_invitations WHERE invite_id=?',(owner,)).fetchone())
        return not self.access_ids or owner in self.access_ids

    def beta_gate(self, owner, check_limits=True):
        if not self.student_ids or self.clock() < BETA_ONCE_START:
            return None
        if not self.allowed(owner):
            return {'code':'INVITE_REQUIRED','error':'請使用老師提供的邀請碼。'}
        invite = self.db.execute('SELECT expires,revoked FROM invites WHERE id=?',(owner,)).fetchone()
        if not invite:
            return {'code':'INVITE_REQUIRED','error':'請使用老師提供的邀請碼。'}
        if invite['revoked']:
            return {'code':'INVITE_REVOKED','error':'這份邀請已停用，目前不能開始新的占卜，請聯絡老師。'}
        if invite['expires'] <= self.clock():
            return {'code':'INVITE_EXPIRED','error':'這份邀請已過期，目前不能開始新的占卜，請聯絡老師。'}
        member = self.db.execute('SELECT valid_from FROM beta_invitations WHERE invite_id=?',(owner,)).fetchone()
        if member and self.clock() < member[0]:
            date = datetime.fromtimestamp(member[0],TZ).strftime('%Y/%m/%d %H:%M')
            return {'code':'BETA_NOT_YET_VALID','error':f'這份邀請尚未到適用日期，請於 {date}（台灣時間）起再開始占卜。'}
        with self.svc.lock:
            state = beta_policy.state(self.db, self.svc.db, owner)
        if state == 'completed':
            return {'code':'BETA_ALREADY_USED','error':'這個邀請碼已有成功保存的解牌，不再提供新占卜次數。請點「查看已保存的解牌」讀取原結果及提交回饋；不會再次呼叫 AI 或計次。'}
        if state == 'unknown':
            return {'code':'BETA_REVIEW_REQUIRED','error':'此邀請有先前狀態未明、待查核的紀錄，暫時不能開始新的占卜；請保留原結果並聯絡老師，系統不會自動重送。'}
        if state == 'review':
            return {'code':'BETA_FAILED_REVIEW','error':'此邀請有先前未完成、待查核的紀錄，暫時不能開始新的占卜；一次體驗權利保留，請聯絡老師查核，不會自動重送。'}
        if not check_limits:
            return None
        day=datetime.fromtimestamp(self.clock(),TZ).strftime('%Y-%m-%d')
        if accounting.student_used(self.db, reservations=True)>=100:
            return {'code':'BETA_TOTAL_LIMIT','error':'Beta 累計測試額度已用完，請等老師確認。'}
        if self.db.execute("SELECT count(*) FROM requests WHERE (charged=1 OR cid IN (SELECT cid FROM beta_completion WHERE state='reserved')) AND day=? AND cid IN (SELECT cid FROM student_paid_attempts)",(day,)).fetchone()[0]>=12:
            return {'code':'BETA_DAILY_LIMIT','error':'花房今日 12 次解牌額度已滿；這次尚未送出 AI 解牌，也未消耗邀請碼。請在邀請碼有效期限內，於明天（台灣時間）再試。'}
        return None

    def empty_pending(self, owner):
        """Derive legacy pending empties without rewriting historical records."""
        if not owner:
            return None
        last=self.db.execute('SELECT cid,charged FROM requests WHERE invite_id=? ORDER BY created DESC,rowid DESC LIMIT 1',(owner,)).fetchone()
        if not last or last['charged'] or self.db.execute('SELECT 1 FROM empty_continuations WHERE empty_cid=?',(last['cid'],)).fetchone():
            return None
        with self.svc.lock:
            row=self.svc.db.execute("SELECT consultation_id,question_category,question_text,drawn_card,orientation,cooldown_until FROM consultations WHERE consultation_id=? AND session_id=? AND api_status='empty_no_api'",(last['cid'],owner)).fetchone()
        return dict(row) if row else None

    def session_problem(self, token):
        row = self.db.execute('''SELECT s.expires AS session_expires,i.expires,i.revoked
            FROM sessions s JOIN invites i ON i.id=s.invite_id WHERE s.token_hash=?''',
            (digest(token),)).fetchone() if token else None
        if row and row['revoked']:
            return {'code':'INVITE_REVOKED','error':'這份邀請已停用，目前不能開始新的占卜，請聯絡老師。'}
        if row and row['expires'] <= self.clock():
            return {'code':'INVITE_EXPIRED','error':'這份邀請已過期，目前不能開始新的占卜，請聯絡老師。'}
        return {'code':'SESSION_REQUIRED','error':'目前沒有有效的登入授權，請重新使用有效邀請碼進入花房。'}

    def draw_gate(self, owner):
        gate = self.beta_gate(owner, check_limits=False)
        if gate:
            return gate
        if not self.accepting or (self.production and self.svc.mode == 'locked'):
            return {'code':'DRAW_UNAVAILABLE','error':'花房暫時無法開始新的占卜，請稍後再來。'}
        if owner in self.active or len(self.active) >= 2:
            return {'code':'DRAW_BUSY','error':'目前有問測進行中，請稍後再開始新的占卜。'}
        cooldown = self.db.execute('SELECT MAX(cooldown) FROM requests WHERE invite_id=?',(owner,)).fetchone()[0] or 0
        if cooldown > self.clock():
            return {'code':'DRAW_COOLDOWN','error':'請先完成三分鐘靜心，再開始新的占卜。'}
        if self.teacher_ids and self.db.execute('SELECT 1 FROM teacher_paid_attempt').fetchone():
            return {'code':'TEACHER_ALREADY_USED','error':'本階段的解牌驗收已使用，請查看原結果。'}
        space = shutil.disk_usage(self.root)
        if space.used / space.total >= .85:
            return {'code':'DRAW_UNAVAILABLE','error':'花房暫時休息，請稍後再開始新的占卜。'}
        return None

    def beta_policy(self):
        if not self.student_ids:
            return ''
        if self.clock() < BETA_ONCE_START:
            return '今天沿用原邀請規則。十月一日起，每個邀請碼限成功完成一次完整占卜。'
        return '每個邀請碼限成功完成一次完整占卜，不會每日重置。新碼含適用當日共三天有效，既有碼依原期限；邀請不保留解牌名額。送出 AI 解牌時檢查全站每日 12 次及 Beta 累計 100 次，當日額滿請在有效期限內隔天再試。舊人、新人與前期學生都可由老師再次邀請取得新碼。'

    def throttle(self, key, limit, window=60):
        now = self.clock()
        with self.lock:
            row = self.db.execute('SELECT * FROM attempts WHERE bucket=?', (key,)).fetchone()
            count = row['count'] + 1 if row and now - row['start'] < window else 1
            start = row['start'] if row and now - row['start'] < window else now
            self.db.execute('INSERT OR REPLACE INTO attempts VALUES(?,?,?)', (key, start, count))
            self.db.execute('DELETE FROM attempts WHERE start<?', (now - 86400,))
            self.db.commit()
        return count <= limit

    def consultation(self, owner, data):
        # Validate before reserving capacity; approved validation remains in Service too.
        if not isinstance(data, dict) or set(data) != {'consultation_id','question_category','question_text','drawn_card','orientation'}:
            raise ValueError('invalid fields')
        cid = data['consultation_id']
        if not isinstance(cid, str) or str(uuid.UUID(cid)) != cid:
            raise ValueError('invalid id')
        q = {k:v for k,v in data.items() if k != 'consultation_id'}
        if any(not isinstance(v,str) for v in q.values()) or q['question_category'] not in backend.CATEGORIES or q['drawn_card'] not in backend.CARDS or not 1 <= len(q['question_text'].strip()) <= 1000:
            raise ValueError('invalid question')
        empty = q['drawn_card'] == 'main_15'
        if q['orientation'] not in (('orientation-independent',) if empty else ('upright','reversed')):
            raise ValueError('invalid orientation')
        reqhash = digest(json.dumps(q, sort_keys=True, ensure_ascii=False))
        with self.lock:
            if not self.allowed(owner):
                return 403, {'error':'目前僅供受邀驗收。'}
            continuation=self.empty_pending(owner)
            if continuation and not empty:
                if q['drawn_card'] not in {f'main_{i:02d}' for i in range(1,15)}:
                    return 409, {'code':'MAIN_STAR_REQUIRED','error':'請接續抽一張主星牌。'}
                if any(q[k]!=continuation[k] for k in ('question_category','question_text')):
                    return 409, {'code':'CONTINUE_ORIGINAL_QUESTION','error':'請沿用原問題接續抽主星牌。'}
                # Older clients may send a fresh UUID; canonicalize to the original round.
                cid=continuation['consultation_id']
                data={**data,'consultation_id':cid}
            old = self.db.execute('SELECT * FROM requests WHERE cid=?', (cid,)).fetchone()
            if old and not (continuation and not empty):
                if old['invite_id'] != owner or old['request_hash'] != reqhash:
                    return 409, {'error':'這次問測識別碼不能用於另一筆問題。'}
                with self.svc.lock:
                    row = self.svc.db.execute('SELECT * FROM consultations WHERE consultation_id=? AND session_id=?', (cid, owner)).fetchone()
                    result = backend.client_payload(self.svc.public(row)) if row else {'consultation_id':cid,'api_status':'interrupted_no_retry','client_display_text':'這次問測狀態尚未確認，請保留牌面，沒有重新送出解牌。','cooldown_until':old['cooldown']}
                return 200, result
            continuation=self.empty_pending(owner)
            if continuation:
                if empty:
                    return 409, {'code':'MAIN_STAR_REQUIRED','error':'本次已抽到空宮，請接續抽一張主星牌；不會另扣占卜次數。'}
                if any(q[k]!=continuation[k] for k in ('question_category','question_text')):
                    return 409, {'code':'CONTINUE_ORIGINAL_QUESTION','error':'空宮後請接續原問題抽主星牌，這仍是同一次占卜。請重新開啟花房恢復原問題。'}
            if not self.accepting or (self.production and self.svc.mode == 'locked'):
                return 503, {'error':'花房正在準備中，請稍後再來。'}
            if owner in self.active or len(self.active) >= 2:
                return 429, {'error':'請等目前問測完成後再繼續。'}
            if self.db.execute('SELECT 1 FROM requests WHERE invite_id=? AND cooldown>?', (owner,self.clock())).fetchone():
                return 429, {'error':'請先完成三分鐘靜心。'}
            space = shutil.disk_usage(self.root)
            if space.used / space.total >= .85:
                return 503, {'error':'花房暫時休息，請稍後再來。'}
            now = self.clock()
            day = datetime.fromtimestamp(now,TZ).strftime('%Y-%m-%d')
            month = day[:7]
            self.db.execute('BEGIN IMMEDIATE')
            try:
                gate = self.beta_gate(owner)
                if gate:
                    self.db.rollback()
                    return 429, gate
                if not empty:
                    if self.student_ids:
                        if accounting.student_used(self.db, reservations=True) >= 100:
                            self.db.rollback()
                            return 429, {'error':'本批測試額度已用完，請等老師確認。'}
                        self.db.execute('INSERT INTO student_paid_attempts VALUES(?,?)', (cid,now))
                    if self.teacher_ids:
                        if self.db.execute('SELECT 1 FROM teacher_paid_attempt').fetchone():
                            self.db.rollback()
                            return 429, {'error':'本階段的一次解牌驗收已使用，請先確認結果。'}
                        self.db.execute('INSERT INTO teacher_paid_attempt VALUES(1,?,?)', (cid, now))
                    cohort_filter = ' AND cid IN (SELECT cid FROM student_paid_attempts)' if self.student_ids else ''
                    counts = [self.db.execute(sql+cohort_filter,args).fetchone()[0] for sql,args in (
                        ("SELECT count(*) FROM requests WHERE (charged=1 OR cid IN (SELECT cid FROM beta_completion WHERE state='reserved')) AND day=? AND invite_id=?",(day,owner)),
                        ("SELECT count(*) FROM requests WHERE (charged=1 OR cid IN (SELECT cid FROM beta_completion WHERE state='reserved')) AND day=?",(day,)),
                        ("SELECT count(*) FROM requests WHERE (charged=1 OR cid IN (SELECT cid FROM beta_completion WHERE state='reserved')) AND month=?",(month,)))]
                    if any(c >= cap for c,cap in zip(counts,self.limits)):
                        self.db.rollback()
                        return 429, {'error':'今天或本期的問測額度已用完，請稍後再來。'}
                    accounting.reserve(self.db,cid,'student' if self.student_ids else 'teacher' if self.teacher_ids else 'other',now)
                if continuation:
                    self.db.execute("UPDATE requests SET request_hash=?,day=?,month=?,charged=0,state='started',cooldown=0 WHERE cid=?",(reqhash,day,month,cid))
                    self.db.execute('INSERT INTO empty_continuations VALUES(?,?,?)',(cid,cid,now))
                else:
                    self.db.execute('INSERT INTO requests VALUES(?,?,?,?,?,?,?,?,?)',
                        (cid,owner,reqhash,now,day,month,0,'started',now+180 if empty else 0))
                self.db.commit()
            except Exception:
                self.db.rollback()
                raise
            self.active.add(owner)
        try:
            result = self.svc.consult(owner,data)
            with self.lock:
                accounting.finish(self.db,self.svc.db,cid,result,self.clock())
                self.db.execute("UPDATE requests SET state='finished',cooldown=MAX(cooldown,?) WHERE cid=?",(result.get('cooldown_until',0),cid))
                self.db.commit()
            return 200, backend.client_payload(result)
        finally:
            with self.lock:
                self.active.discard(owner)

    def __call__(self, env, start_response):
        if self.production:
            import fcntl
            # Separate file descriptions make the lock meaningful across threads.
            with (self.root/'io.lock').open('a+b') as guard:
                fcntl.flock(guard, fcntl.LOCK_SH)
                return self.respond(env, start_response)
        return self.respond(env, start_response)

    def respond(self, env, start_response):
        diagnostic = invite_diagnostics.begin(self.secret, self.clock, env)
        headers = [('Cache-Control','no-store'),('X-Content-Type-Options','nosniff'),
                   ('Referrer-Policy','same-origin'),('Content-Security-Policy',CSP)]
        if diagnostic is not None:
            headers.append(('X-Request-ID', diagnostic['fields']['request_id']))
        def send(code, value, kind='application/json; charset=utf-8'):
            raw = value if isinstance(value,bytes) else (value.encode() if isinstance(value,str) else json.dumps(value,ensure_ascii=False).encode())
            status = {200:'OK',303:'See Other',400:'Bad Request',401:'Unauthorized',403:'Forbidden',404:'Not Found',409:'Conflict',429:'Too Many Requests',503:'Service Unavailable'}[code]
            invite_diagnostics.finish(diagnostic, code)
            start_response(f'{code} {status}',headers+[('Content-Type',kind),('Content-Length',str(len(raw)))])
            return [raw]
        try:
            path, method = env.get('PATH_INFO','/'), env.get('REQUEST_METHOD','GET')
            # Platform liveness exposes no configuration or private data.
            if path == '/healthz' and method == 'GET':
                return send(200, {'ok':True})
            if env.get('HTTP_HOST') != self.host:
                return send(403, {'error':'request rejected'})
            if path == '/api/handoff-events':
                # Anonymous, write-only events in a separate DB. No invitation/session writes.
                origin = env.get('HTTP_ORIGIN', '')
                if origin not in (self.origin, 'https://anitahou.com'):
                    return send(403, {'error':'request rejected'})
                headers += [('Access-Control-Allow-Origin',origin),('Vary','Origin')]
                if method == 'OPTIONS':
                    headers += [('Access-Control-Allow-Methods','POST'),('Access-Control-Allow-Headers','Content-Type')]
                    return send(200, '')
                if method != 'POST':
                    return send(404, {'error':'not found'})
                size = int(env.get('CONTENT_LENGTH','0'))
                if not 0 < size <= 256 or env.get('CONTENT_TYPE') != 'application/json':
                    return send(400, {'error':'invalid event'})
                data = json.loads(env['wsgi.input'].read(size))
                ok = self.handoff_events.record(data)
                return send(200 if ok else 429, {'ok':ok})
            invite_diagnostics.note(diagnostic, stage='cookie_parse', reason='cookie_parse_error')
            cookies = SimpleCookie()
            cookies.load(env.get('HTTP_COOKIE',''))
            token = cookies['flower_session'].value if 'flower_session' in cookies else ''
            invite_diagnostics.note(diagnostic, stage='session_lookup', reason='storage_error')
            owner = self.session(token) if token else None
            invite_diagnostics.note(diagnostic, session_valid=bool(owner))
            if method == 'POST':
                invite_diagnostics.note(diagnostic, stage='origin', reason='origin_rejected')
                if env.get('HTTP_ORIGIN') != self.origin:
                    return send(403, {'error':'request rejected'})
                invite_diagnostics.note(diagnostic, stage='body', reason='invalid_body_length')
                size = int(env.get('CONTENT_LENGTH','0'))
                invite_diagnostics.note(diagnostic, body_length=max(-1,min(size,20001)))
                if not 0 < size <= 20000:
                    return send(400, {'error':'資料長度不正確。'})
                invite_diagnostics.note(diagnostic, stage='body_read', reason='body_read_error')
                raw = env['wsgi.input'].read(size)
                if path == '/enter':
                    # Do not trust arbitrary forwarded IP headers. Aggregate limit
                    # is deliberately conservative until the platform IP is verified.
                    invite_diagnostics.note(diagnostic, stage='rate_limit', reason='rate_limited_or_storage_error')
                    if not self.throttle('enter:'+digest(env.get('REMOTE_ADDR','unknown')),10):
                        invite_diagnostics.note(diagnostic, reason='rate_limited')
                        return send(429, {'error':'請稍後再試。'})
                    invite_diagnostics.note(diagnostic, stage='parse', reason='decode_or_parse_error')
                    data = parse_qs(raw.decode())
                    invite_diagnostics.capture_input(diagnostic, data)
                    nonce = cookies['flower_entry'].value if 'flower_entry' in cookies else ''
                    invite_diagnostics.note(diagnostic, stage='csrf', reason='csrf_mismatch' if nonce else 'csrf_cookie_missing', entry_cookie_present=bool(nonce))
                    if not nonce or not hmac.compare_digest(data.get('csrf',[''])[0],self.mac('entry:'+nonce)):
                        return send(403, {'error':'請重新開啟邀請頁。'})
                    code = data.get('invite',[''])[0].strip()
                    with self.lock:
                        invite_diagnostics.note(diagnostic, stage='invite_lookup', reason='storage_error')
                        invite = self.db.execute('SELECT * FROM invites WHERE code_hash=? AND revoked=0 AND expires>?',(digest(code),self.clock())).fetchone()
                        if invite is not None:
                            invite_diagnostics.note(diagnostic, stage='allowed', reason='storage_error')
                        if not invite or not self.allowed(invite['id']):
                            invite_diagnostics.lookup(diagnostic, self, code, invite, rejected=True)
                            target=data.get('consultation',[''])[0]
                            try:
                                target='/?consultation='+str(uuid.UUID(target))
                            except (ValueError,TypeError,AttributeError):
                                target='/'
                            return send(403,'<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>請確認邀請碼</title><body><h1>暫時無法驗證邀請碼</h1><p>請確認貼上的是老師提供的完整邀請碼。若仍無法進入，請把邀請編號交給老師查核有效期限或停用狀態。</p><p>這是登入驗證失敗，不代表已完成或重新進行占卜。既有結果不會因此刪除，也沒有呼叫 AI。</p><a href="'+target+'">回邀請頁重新驗證，接續查看原結果</a></body></html>','text/html; charset=utf-8')
                        invite_diagnostics.lookup(diagnostic, self, code, invite, rejected=False)
                        invite_diagnostics.note(diagnostic, stage='session_create', reason='storage_error')
                        session = secrets.token_urlsafe(32)
                        self.db.execute('INSERT INTO sessions VALUES(?,?,?)',(digest(session),invite['id'],min(invite['expires'],self.clock()+7*86400)))
                        self.db.commit()
                    target=data.get('consultation',[''])[0]
                    try:
                        target=str(uuid.UUID(target))
                    except (ValueError,TypeError,AttributeError):
                        target=''
                    headers += [('Set-Cookie',self.cookie('flower_session',session,7*86400)),('Set-Cookie',self.cookie('flower_entry','',0)),('Location','/?resume=1&consultation='+target if target else '/?resume=1')]
                    invite_diagnostics.note(diagnostic, stage='complete', reason='success')
                    return send(303,'')
                if not owner:
                    return send(403, self.session_problem(token))
                if not hmac.compare_digest(env.get('HTTP_X_CSRF_TOKEN',''),self.mac('csrf:'+token)):
                    return send(403, {'error':'請重新進入花房。'})
                if not self.throttle('api:'+owner,30):
                    return send(429, {'error':'請稍後再試。'})
                if env.get('CONTENT_TYPE') != 'application/json':
                    return send(400, {'error':'資料格式不正確。'})
                data = json.loads(raw)
                if path == '/api/consult':
                    status,result = self.consultation(owner,data)
                    return send(status,result)
                if path == '/api/feedback':
                    return send(200,self.svc.feedback(owner,data))
                return send(404, {'error':'not found'})
            if method != 'GET':
                return send(404, {'error':'not found'})
            if path == '/invite-entry.js':
                # Public entry-page helper only; no session or invitation mutation.
                return send(200, (ROOT/'public'/'invite-entry.js').read_bytes(), 'text/javascript; charset=utf-8')
            if path == '/api/eligibility':
                # Read-only preflight: no new session, entry event, draw, reservation or model call.
                with self.lock:
                    gate = self.draw_gate(owner) if owner else self.session_problem(token)
                return send(200 if owner else 401, {'can_draw':gate is None,'beta_gate':gate,'empty_continuation':self.empty_pending(owner)})
            if path == '/api/session' and not owner:
                return send(401, {'can_draw':False,'beta_gate':self.session_problem(token)})
            # An existing cookie identifies the previous invitation, not today's new code.
            # The shared entry URL always offers a choice without clearing that session.
            entry_choice = path == '/' and parse_qs(env.get('QUERY_STRING','')).get('resume') != ['1']
            if not owner or entry_choice:
                if path != '/':
                    return send(401, {'error':'請先使用邀請碼進入花房。'})
                nonce = secrets.token_urlsafe(24)
                headers.append(('Set-Cookie',self.cookie('flower_entry',nonce,600)))
                html = '<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>進入花房</title><body style="font:18px/1.8 serif;background:#faf6ed;color:#534432;max-width:420px;margin:12vh auto;padding:24px"><h1>紫微牌卡占卜花房</h1><p>請帶著老師的邀請，慢慢走進來。</p><p>'+self.beta_policy()+'</p><form method="post" action="/enter"><input type="hidden" name="csrf" value="'+self.mac('entry:'+nonce)+'"><label>邀請碼<input name="invite" autocomplete="off" required maxlength="100" style="display:block;width:100%;font:inherit;margin:12px 0"></label><button style="font:inherit;padding:8px 18px">進入花房</button></form></body></html>'
                target=parse_qs(env.get('QUERY_STRING','')).get('consultation',[''])[0]
                html=html.replace('name="invite" autocomplete=', 'name="invite" aria-describedby="invite-help" autocomplete=')
                html=html.replace('</label><button', '</label><p id="invite-help" style="font-size:16px">請只貼上邀請碼本身，勿包含「」、“ ”、&quot; &quot;、反引號或其他文字。</p><button')
                html=html.replace('</body>', '<script src="/invite-entry.js" defer></script></body>')
                try:
                    target=str(uuid.UUID(target))
                    html=html.replace('</form>','<input type="hidden" name="consultation" value="'+target+'"></form>')
                except (ValueError,TypeError,AttributeError):
                    target=''
                if owner:
                    resume='/?resume=1'+('&amp;consultation='+target if target else '')
                    choice='<p>此瀏覽器保留了先前的登入，尚未驗證你這次取得的新邀請碼。請輸入這次的邀請碼，或選擇沿用先前邀請。</p><p><a href="'+resume+'">沿用先前邀請，查看結果或接續未完成占卜</a></p>'
                    html=html.replace('<form method="post"',choice+'<form method="post"')
                return send(200,html,'text/html; charset=utf-8')
            if path == '/api/session':
                with self.lock:
                    if self.student_ids:
                        day=datetime.fromtimestamp(self.clock(),TZ).strftime('%Y-%m-%d')
                        self.db.execute('INSERT INTO beta_entries(invite_id,created,day) VALUES(?,?,?)',(owner,self.clock(),day))
                        self.db.commit()
                    cooldown = self.db.execute('SELECT MAX(cooldown) FROM requests WHERE invite_id=?',(owner,)).fetchone()[0] or 0
                    gate = self.draw_gate(owner)
                    paid_locked = self.svc.mode != 'live' or (bool(self.teacher_ids) and bool(self.db.execute('SELECT 1 FROM teacher_paid_attempt').fetchone()))
                return send(200,{'csrf':self.mac('csrf:'+token),'cooldown_until':cooldown,'mode':self.svc.mode,'paid_locked':paid_locked,'beta_gate':gate,'beta_policy':self.beta_policy(),'empty_continuation':self.empty_pending(owner)})
            if path == '/api/consultation':
                cid = parse_qs(env.get('QUERY_STRING','')).get('id',[''])[0]
                with self.svc.lock:
                    row = self.svc.db.execute('SELECT * FROM consultations WHERE consultation_id=? AND session_id=?',(cid,owner)).fetchone()
                    if not row:
                        return send(404, {'error':'找不到本次問測；請勿自動重新送出。'})
                    return send(200,{'question':{k:row[k] for k in ('question_category','question_text','drawn_card','orientation')},'result':backend.client_payload(self.svc.public(row))})
            if path == '/api/consultations':
                # Authenticated discovery only; every result still passes owner checks.
                with self.svc.lock:
                    rows=self.svc.db.execute('SELECT consultation_id,timestamp FROM consultations WHERE session_id=? ORDER BY timestamp DESC LIMIT 50',(owner,)).fetchall()
                return send(200,{'consultations':[dict(r) for r in rows]})
            path = path.encode('latin-1').decode('utf-8')  # WSGI PATH_INFO preserves UTF-8 bytes as Latin-1.
            file = (ROOT/'public'/('index.html' if path == '/' else path.lstrip('/'))).resolve()
            if not file.is_relative_to(ROOT/'public') or not file.is_file() or file.suffix.lower() not in ('.html','.css','.js','.json','.png','.jpg','.jpeg','.svg','.webp'):
                return send(404, {'error':'not found'})
            return send(200,file.read_bytes(),mimetypes.guess_type(file.name)[0] or 'application/octet-stream')
        except (ValueError,TypeError,KeyError,UnicodeError):
            return send(400, {'error':'請確認填寫內容，或重新開啟花房。'})
        except Exception:
            # Never include exception strings, request bodies or secrets in logs.
            return send(503, {'error':'暫時無法保存或讀取資料，沒有自動重試。'})


def create_app():
    mode = os.environ.get('BETA_MODE','locked')
    paid = os.environ.get('PAID_CALLS_ENABLED','false')
    teacher_test = mode == 'teacher-test' and paid == 'true'
    student_beta = mode == 'student-beta' and paid == 'true'
    teacher_ids = tuple(v.strip() for v in os.environ.get('TEACHER_TEST_INVITE_IDS','').split(',') if v.strip())
    student_ids = tuple(v.strip() for v in os.environ.get('STUDENT_BETA_INVITE_IDS','').split(',') if v.strip())
    if not ((mode == 'locked' and paid == 'false') or teacher_test or student_beta):
        raise RuntimeError('paid transport remains locked')
    if student_beta and (not 1<=len(student_ids)<=12 or len(set(student_ids))!=len(student_ids) or not os.environ.get('OPENAI_API_KEY') or os.environ.get('BOOTSTRAP_PENDING','false')!='false'):
        raise RuntimeError('student beta configuration incomplete')
    if teacher_test and (not teacher_ids or not os.environ.get('OPENAI_API_KEY') or os.environ.get('BOOTSTRAP_PENDING','false') != 'false'):
        raise RuntimeError('teacher test configuration incomplete')
    if os.environ.get('BOOTSTRAP_PENDING','false') == 'true':
        if not os.path.ismount('/var/data'):
            raise RuntimeError('persistent mount unavailable')
        def waiting(env, start_response):
            healthy = env.get('PATH_INFO') == '/healthz'
            text = b'{"process_alive":true,"ready":false}' if healthy else '花房正在準備中。'.encode()
            start_response('200 OK' if healthy else '503 Service Unavailable', [('Content-Type','application/json' if healthy else 'text/plain; charset=utf-8'),('Cache-Control','no-store'),('Content-Length',str(len(text)))])
            return [text]
        return waiting
    # Refuse an accidental second worker/instance before Service crash recovery.
    import fcntl
    root = check_volume('/var/data/flower',os.environ['EXPECTED_VOLUME_ID'])
    singleton = (root/'worker.lock').open('a+b')
    fcntl.flock(singleton,fcntl.LOCK_EX | fcntl.LOCK_NB)
    # Only the explicitly configured teacher test can unlock the existing transport.
    backend.PAID_CALLS_APPROVED = teacher_test or student_beta
    app = Hosting('/var/data/flower',os.environ['EXPECTED_VOLUME_ID'],
                   os.environ['PUBLIC_ORIGIN'].rstrip('/'),os.environ['SESSION_SECRET'],
                   accepting=teacher_test or student_beta, mode='live' if teacher_test or student_beta else 'locked',
                   teacher_ids=teacher_ids if teacher_test else (), student_ids=student_ids if student_beta else (),
                   daily=1 if student_beta else 3, global_daily=12 if student_beta else 30, monthly=100 if student_beta else 300)
    app.singleton = singleton
    return app
