"""Minimal anonymous handoff telemetry. Never stores drafts or account identifiers."""
import maintenance
from pathlib import Path
import collections
import sqlite3
import threading
import time
import uuid

EVENTS = frozenset(('teacher_clicked', 'draft_confirmed', 'forum_draft_received'))
RETENTION = 30 * 86400


class HandoffEvents:
    def __init__(self, path, clock=time.time, background=False):
        self.root=Path(path).resolve().parent
        with maintenance.writer(self.root):
            self._initialize(path,clock,background)

    def _initialize(self, path, clock, background):
        self.clock = clock
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False, timeout=5)
        self.db.execute('CREATE TABLE IF NOT EXISTS events (flow_id TEXT NOT NULL, event TEXT NOT NULL, created REAL NOT NULL, PRIMARY KEY(flow_id,event))')
        self.db.execute('CREATE INDEX IF NOT EXISTS event_age ON events(created)')
        self.recent = collections.deque()
        self.stop = threading.Event()
        self.prune()
        self.worker = None
        if background:
            self.worker = threading.Thread(target=self._clean, daemon=True)
            self.worker.start()

    @maintenance.method
    def prune(self):
        with self.lock:
            self.db.execute('DELETE FROM events WHERE created < ?', (self.clock()-RETENTION,))
            self.db.commit()

    def _clean(self):
        while not self.stop.wait(3600):
            try:
                self.prune()
            except (sqlite3.Error, maintenance.Busy):
                pass  # Retry cleanup next hour; never log event payloads.

    @maintenance.method
    def record(self, data):
        if not isinstance(data, dict) or set(data) != {'flow_id', 'event'}:
            raise ValueError('invalid event fields')
        flow, event = data['flow_id'], data['event']
        if not isinstance(flow, str) or not isinstance(event, str) or event not in EVENTS:
            raise ValueError('invalid event')
        parsed = uuid.UUID(flow)
        if parsed.version != 4 or str(parsed) != flow:
            raise ValueError('invalid flow')
        with self.lock:
            now = self.clock()
            while self.recent and self.recent[0] <= now-60:
                self.recent.popleft()
            if len(self.recent) >= 120:
                return False
            self.recent.append(now)
            self.db.execute('DELETE FROM events WHERE created < ?', (now-RETENTION,))
            self.db.execute('INSERT OR IGNORE INTO events VALUES(?,?,?)', (flow,event,now))
            self.db.commit()
        return True

    @maintenance.method
    def close(self):
        self.stop.set()
        if self.worker:
            self.worker.join(timeout=2)
        with self.lock:
            self.db.close()
