"""Private operator CLI. No HTTP endpoint; report uses SQLite mode=ro.

Backup drains a cooperating worker, or requires a stopped legacy worker.
No public maintenance endpoint. Never constructs an application.
"""
import argparse
import json
import sqlite3
import tempfile
from contextlib import ExitStack
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import public_backup
import backend
import maintenance

def readonly(path):
    db=sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)
    db.row_factory=sqlite3.Row
    db.execute('PRAGMA query_only=ON')
    return db

def report(root):
    root=Path(root)
    with ExitStack() as stack:
        a=readonly(root/'access/access.sqlite3');stack.callback(a.close)
        b=readonly(root/'records/consultations.sqlite3');stack.callback(b.close)
        tables={r[0] for r in a.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'public_rounds' not in tables:return {'public_schema_present':False,'days':[]}
        rounds=[dict(r) for r in a.execute('SELECT * FROM public_rounds')]
        empty={r[0] for r in a.execute('SELECT cid FROM public_empty_draws')}
        replays=dict(a.execute('SELECT day,count FROM public_replays')) if 'public_replays' in tables else {}
        times=dict(a.execute('SELECT cid,started FROM public_attempt_times')) if 'public_attempt_times' in tables else {}
        saved={r['consultation_id']:dict(r) for r in b.execute('SELECT * FROM consultations WHERE session_id LIKE ?',('public:%',))}
        days=[];anomalies=[];wall={}
        for d in sorted({r['day'] for r in rounds}|set(replays)):
            rs=[r for r in rounds if r['day']==d];complete=[r for r in rs if r['state']=='complete']
            days.append({'day':d,'completed_visitors':len({r['owner'] for r in complete}),
              'first_completed_visitors':len({r['owner'] for r in complete if r['ordinal']==1}),
              'complete_rounds':len(complete),'first_complete':sum(r['ordinal']==1 for r in complete),
              'followup_complete':sum(r['ordinal']==2 for r in complete),
              'empty_continuations_started':sum(r['cid'] in empty for r in rs),
              'empty_pending':sum(r['state']=='empty' for r in rs),
              'failed':sum(r['state']=='failed' for r in rs),'unknown':sum(r['state']=='unknown' for r in rs),
              'reserved':sum(r['state']=='reserved' for r in rs),'admitted_attempts':sum(r['attempted'] for r in rs),
              'replays_received_on_day':replays.get(d,0)})
        for r in rounds:
            s=saved.get(r['cid'])
            if r['state']=='complete' and not backend.saved_complete(s):
                anomalies.append({'cid':r['cid'],'type':'completion_requires_review'})
            if r['ordinal']==2 and not any(x['cid']==r['parent'] and x['owner']==r['owner'] and x['day']==r['day'] and x['ordinal']==1 for x in rounds):
                anomalies.append({'cid':r['cid'],'type':'invalid_parent'})
            if s and (s['request_attempts'] or 0)>1:anomalies.append({'cid':r['cid'],'type':'multiple_provider_attempts'})
            if r['cid'] in times:
                day=datetime.fromtimestamp(times[r['cid']],ZoneInfo('Asia/Taipei')).date().isoformat()
                bucket=wall.setdefault(day,{'admitted_attempts':0,'saved_provider_attempts':0,'estimated_cost_sum':0,'unknown_cost_rows':0})
                bucket['admitted_attempts']+=1
                if s:
                    bucket['saved_provider_attempts']+=s['request_attempts'] or 0
                    if s['estimated_cost'] is None:bucket['unknown_cost_rows']+=1
                    else:bucket['estimated_cost_sum']+=s['estimated_cost']
                else:bucket['unknown_cost_rows']+=1
        alerts=[]
        for d in days:
            if d['first_completed_visitors']>10:anomalies.append({'day':d['day'],'type':'over_approved_ten_visitors'})
            if d['unknown'] or d['failed']:alerts.append({'day':d['day'],'type':'review_unknown_or_failed'})
            if d['admitted_attempts']>=16:alerts.append({'day':d['day'],'type':'near_default_attempt_budget'})
        for key in {(r['owner'],r['day']) for r in rounds}:
            if sum(r['owner']==key[0] and r['day']==key[1] and r['state']=='complete' for r in rounds)>2:
                anomalies.append({'day':key[1],'type':'over_two_per_visitor'})
        return {'public_schema_present':True,'days':days,'attempt_start_days':wall,'anomalies':anomalies,'alerts':alerts,
          'notes':['No legacy Beta rows included. Completion days mean admission day, not finish time.',
          'Replay counters and attempt timestamps cover only requests after this version.',
          'Read-only live report can span concurrent commits; run under io.lock for a stable snapshot.',
          'Estimated costs are not invoices; unknown consumption is not zero.']}

def set_control(root,mode):
    with maintenance.writer(root):
        return _set_control(root,mode)

def _set_control(root,mode):
    if mode not in ('open','drain','halt'):raise ValueError('invalid control')
    db=sqlite3.connect((Path(root)/'access/access.sqlite3').resolve().as_uri()+'?mode=rw',uri=True)
    try:
        db.execute('INSERT INTO public_control VALUES(1,?) ON CONFLICT(id) DO UPDATE SET mode=excluded.mode',(mode,));db.commit()
    finally:db.close()

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['report','backup','verify','control','recover-maintenance'])
    p.add_argument('--root');p.add_argument('--public-key');p.add_argument('--private-key');p.add_argument('--archive');p.add_argument('--destination');p.add_argument('--mode',choices=['open','drain','halt'])
    p.add_argument('--drain-timeout',type=float,default=120)
    p.add_argument('--backup-timeout',type=float,default=60)
    args=p.parse_args()
    if args.action=='verify':
        if not args.private_key or not args.archive:p.error('verify requires archive and private key paths')
        with tempfile.TemporaryDirectory() as temp:
            public_backup.restore(args.archive,Path(args.private_key).read_bytes(),Path(temp)/'restored')
        print('Encrypted archive, checksums and SQLite integrity verified in isolated restore.')
        return
    if not args.root:p.error('root required')
    root=Path(args.root).resolve()
    if args.action=='recover-maintenance':
        maintenance.recover(root);print('maintenance safely cleared');return
    if args.action=='backup':
        if not args.public_key or not args.destination:p.error('backup requires public key and destination')
        # Key/config validation before stopping admission.
        key=Path(args.public_key).read_bytes()
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        parsed=serialization.load_pem_public_key(key)
        if not isinstance(parsed,rsa.RSAPublicKey) or parsed.key_size<3072:raise ValueError('invalid backup recipient')
        if Path(args.destination).exists():raise ValueError('backup destination already exists')
        with maintenance.quiesce(root,args.drain_timeout):
            with maintenance.compatible_worker(root):
                with maintenance.file_lock(root/'io.lock',exclusive=True,timeout=1):
                    print(public_backup.backup(root,key,args.destination,timeout=args.backup_timeout))
        return
    with maintenance.writer(root):
        with maintenance.file_lock(root/'io.lock',exclusive=True,timeout=5):
            if args.action=='report':print(json.dumps(report(root),ensure_ascii=False))
            else:set_control(root,args.mode);print('control saved')

if __name__=='__main__':main()
