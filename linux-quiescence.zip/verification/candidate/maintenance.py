"""Local operator protocol. Linux only; no HTTP control or credentials.

Lock order: controller -> maintenance -> io. All application writers take
maintenance shared before any database/other lock. A pending marker refuses new
work while accepted requests finish. A crashed controller leaves fail-closed
state; recovery proves both locks are free before clearing it.
"""
import functools
import math
import os
import threading
import time
from contextlib import contextmanager
from pathlib import Path

class Busy(RuntimeError):
    pass

_local = threading.local()

@contextmanager
def file_lock(path, *, exclusive, timeout=0):
    import fcntl
    if not math.isfinite(timeout) or timeout < 0:
        raise ValueError('invalid lock timeout')
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    with os.fdopen(fd, 'r+b') as guard:
        end = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(guard, (fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH) | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= end:
                    raise Busy('lock unavailable') from None
                time.sleep(min(.01, max(0, end-time.monotonic())))
        try:
            yield guard
        finally:
            fcntl.flock(guard, fcntl.LOCK_UN)

@contextmanager
def writer(root):
    root = Path(root).resolve()
    depths = getattr(_local, 'depths', None)
    if depths is None:
        depths = _local.depths = {}
    # Accepted requests can finish nested writes after pending was raised.
    if depths.get(root, 0):
        depths[root] += 1
        try:
            yield
        finally:
            depths[root] -= 1
        return
    with file_lock(root/'maintenance.lock', exclusive=False):
        if (root/'maintenance.pending').exists():
            raise Busy('maintenance pending')
        depths[root] = 1
        try:
            yield
        finally:
            del depths[root]

def constructor(fn):
    @functools.wraps(fn)
    def wrapped(self, root, *args, **kwargs):
        with writer(root):
            return fn(self, root, *args, **kwargs)
    return wrapped

def method(fn):
    @functools.wraps(fn)
    def wrapped(self, *args, **kwargs):
        with writer(self.root):
            return fn(self, *args, **kwargs)
    return wrapped

@contextmanager
def quiesce(root, timeout=120):
    root = Path(root).resolve()
    if not math.isfinite(timeout) or not 0 < timeout <= 120:
        raise ValueError('drain timeout must be within 120 seconds')
    with file_lock(root/'controller.lock', exclusive=True):
        marker = root/'maintenance.pending'
        # Exclusive create: never take ownership of an orphaned controller.
        fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(b'flower-maintenance-v1\n'); f.flush(); os.fsync(f.fileno())
            with file_lock(root/'maintenance.lock', exclusive=True, timeout=timeout):
                yield
        finally:
            marker.unlink(missing_ok=True)

def recover(root):
    root = Path(root).resolve()
    with file_lock(root/'controller.lock', exclusive=True):
        with file_lock(root/'maintenance.lock', exclusive=True):
            (root/'maintenance.pending').unlink(missing_ok=True)

def worker_support(root):
    """Held shared for the lifetime of a cooperating worker, never a stale flag."""
    import fcntl
    fd = os.open(Path(root)/'maintenance.worker.lock', os.O_RDWR | os.O_CREAT, 0o600)
    guard = os.fdopen(fd, 'r+b')
    try:
        fcntl.flock(guard, fcntl.LOCK_SH | fcntl.LOCK_NB)
        return guard
    except BaseException:
        guard.close(); raise

@contextmanager
def compatible_worker(root):
    """Caller already owns maintenance exclusive. Reject an old live worker."""
    from contextlib import ExitStack
    root = Path(root)
    with ExitStack() as stack:
        try:
            stack.enter_context(file_lock(root/'worker.lock', exclusive=True))
        except Busy:
            try:
                with file_lock(root/'maintenance.worker.lock', exclusive=True):
                    pass
            except Busy:
                pass  # Cooperating live worker holds the support lock.
            else:
                raise Busy('live worker does not support maintenance')
        yield

def unavailable(start_response):
    body = '{"code":"MAINTENANCE_NOT_ACCEPTED","error":"花房暫時維護中，本次操作尚未受理，請保留目前頁面，稍後再試。"}'.encode()
    start_response('503 Service Unavailable', [('Content-Type','application/json; charset=utf-8'),
        ('Content-Length',str(len(body))),('Cache-Control','no-store'),('Retry-After','30')])
    return [body]
