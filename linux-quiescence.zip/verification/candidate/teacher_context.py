"""Approved context scoping. Pure/offline: no services, databases, or transport."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def load_health():
    return json.loads((ROOT / 'private/runtime/single_star_health_rules.json').read_text(encoding='utf-8'))

def health_question(q, health):
    # Conservative routing, including mixed-domain questions and known health topics.
    text = q.get('question_category', '') + q.get('question_text', '')
    terms = ['健康','身體','身心','就醫','住院','醫療','治療','手術','病','症','痛','不舒服','不適','睡眠','熬夜','失眠','發燒','發炎','照護','照顧','檢查','檢驗','復健','康復','痊癒','受傷','骨折','滑脫','血壓','血糖','血脂','腫','暈','咳','喘','累','疲','恐慌','焦慮','精神','注意力']
    # A body examination remains health-related even under the work category.
    if '體檢' in text and not re.search('系統體檢|網站體檢|財務體檢|企業體檢|專案體檢', text):
        return True
    terms += ['感冒','臟腑','臟府','腎臟','心血管','血液']
    terms += [t for r in health['rules'] for t in r['health_topics']]
    return any(t in text for t in terms)

def goods_question_target(text):
    """Conservative, offline question frame: object + predicate + discourse role.

    A noun mention is not an asked-about object. Resolve local references only
    from an explicit physical object, and discard background when the question
    shifts to another subject. This is a bounded parser, not unrestricted NLU.
    Return evidence for tests; never turn inferred facts into model knowledge.
    """
    house = r'中古屋|新成屋|房屋|房子|大樓|公寓|住宅|透天|屋況|房(?!東|仲|貸|價)'
    goods = r'中古車|二手車|家具|電器|冰箱|洗衣機|汽車|機車|腳踏車|相機|電腦|手機|物品|商品'
    objects = rf'{house}|{goods}'
    transaction = r'購買|採買|買賣|購入|買|賣|出售|出價|成交|議價|殺價|估價'
    condition = r'屋況|狀況|耗損|修繕|維修|待修|修理|漏水|瑕疵|損壞|耐用|品質'
    other_target = r'升遷|職涯|工作表現|同事|上司|主管|男友|女友|戀情|感情|分手|考試|學業|成績|課程|課業|學習|股票|基金|期貨|保險|服務|軟體|遊戲'
    query = r'嗎|呢|如何|怎麼|是否|會不會|能不能|有沒有|請問|想問|詢問|請教|要注意|該注意'
    # Explicit focus markers discard the preceding narrative within a clause.
    clauses = [c.strip() for c in re.split(r'[，,。！？!?；;\n]|但是|不過|另外|至於', text) if c.strip()]
    pending = None
    matches = []
    for index, original in enumerate(clauses):
        clause = re.split(r'我(?:只|主要|這次)?(?:想問|要問)|請問|詢問', original)[-1]
        if not clause:clause = original
        clause = re.sub(r'^(?:我)?(?:和|跟|與)(?:男友|女友|同事|主管)(?:一起)?', '', clause)
        is_query = bool(re.search(query, original))
        # Embedded nouns (a housing course, an office in a building) do not own
        # the question's predicate. An explicit new question may still follow.
        if re.search(other_target, clause):
            pending = None
            continue
        if re.search(r'(?:不問|不是問|不想問|不考慮|不打算|沒有要|不想)(?:.*)', clause):
            pending = None
            continue
        mention = re.search(objects, clause)
        subject = None
        if mention:
            noun = mention.group()
            subject = 'house' if re.fullmatch(house, noun) else 'physical_goods'
            # Bind an acquisition predicate to its object, rather than matching
            # the two independently anywhere in the entire question.
            before, after = clause[:mention.start()], clause[mention.end():]
            acquired = bool(re.search(rf'(?:{transaction}|看中|看到|看上|挑選|選購)[^，,。！？!?；;]{{0,12}}$', before))
            predicated = bool(re.search(rf'^(?:的|目前|現在|可能|需要|是否|有沒有|能否|能不能|有機會|可以|能|會|要|值得|適合|還|再|該|有|會不會|不會|不|\s)*(?:{transaction}|{condition})', after))
            # Locative/occupational mentions are background, never antecedents.
            if re.search(r'^(?:裡|內|中|旁|附近|樓下|樓上|上班|工作|打工)', after):
                pending = None
                continue
            eligible = subject == 'house' or bool(re.search(r'二手|中古|舊', clause))
            if eligible and (acquired or predicated or noun == '屋況'):
                pending = (subject, noun, index)
                if is_query or index == len(clauses)-1:
                    matches.append({'target':subject,'object':noun,'clause':original,'relation':'explicit_object_predicate'})
                continue
            # A property named without a predicate can be an antecedent only;
            # a standalone noun alone never activates the branch.
            pending = (subject, noun, index) if eligible else None
        elif pending:
            # Resolve a following transaction/condition question, not a new
            # topic. A pronoun without an explicit object has no antecedent.
            relevant = bool(re.search(rf'{transaction}|{condition}|(?:要|該|需)注意|注意事項', clause))
            if relevant and (is_query or index == len(clauses)-1):
                matches.append({'target':pending[0],'object':pending[1],'clause':original,'relation':'local_reference'})
            elif is_query:
                pending = None
    return matches


def scope_matches(scope, q):
    text=q.get('question_text','');cat=q.get('question_category','')
    work=cat=='工作事業' or bool(re.search('工作|職場|職務|主管|同事|專案',text))
    project=bool(re.search('專案|接案|案子',text)) and bool(re.search('接|承接|承擔|負責',text))
    return {
        'romance_loss':cat=='感情' or bool(re.search('曖昧|戀愛|戀情|伴侶|交往|男朋友|女朋友|戀人|夫妻|婚姻|感情',text)),
        'goods_wear':bool(goods_question_target(text)),
        'panic_action':bool(re.search('恐慌|缺乏自信|沒[有有]*自信|過度操煩|無謂思慮|不必要.*操煩',text)),
        'organizing_responsibility':bool(re.search('主辦|籌辦|承辦|辦.*(家族|家庭).*旅遊|人際協調',text)) or (bool(re.search('付出|承擔|協調',text)) and (work or cat=='家庭人際' or bool(re.search('家人|家族|朋友|團隊|人際',text)))),
        'goods_selection':bool(re.search('購買|採買|購物|逛街|選購|買.*(物品|商品|鞋|衣|家具|電器)|挑選.*(物品|商品)|取得.*(物品|商品)',text)) and not bool(re.search('股票|期貨|基金|投資|合作夥伴|人才',text)),
        'blood_kidney_care':bool(re.search('血液|血壓|心臟|心血管|頸動脈|腎|泌尿|皮膚|臟[腑府]|器官|身體部位|健康弱點|疾病來源|病因',text)),
        'health_fear':bool(re.search('恐懼|恐慌|害怕|過度擔憂',text)),
        'sun_responsibility':bool(re.search('工作|管理|主管|團隊|服務|照顧|照護|責任|奔波|承擔|補位',text)),
        'sun_recognition':bool(re.search('升遷|嘉獎|工作表現|競爭|人際|團隊|同事|職場',text)),
        'sun_wealth_method':bool(re.search('如何|怎麼|怎樣|建議|方法|方向',text)) and bool(re.search('財富|財運|賺錢|收入|獲利|投資',text)),
        'study_preparation':bool(re.search('國考|考試|補習|讀書|學習|備考|準備.*考|考.*準備',text)),
        'purchase_service':bool(re.search('購買|採買|商品|交易|客服|售後|購物|下單|淘寶|買.*(櫃|產品|商品)|服務.*(疑|流程|問題)',text)),
        'purchase_savings':bool(re.search('購買|採買|商品|淘寶|購物|下單|買',text)) and bool(re.search('省錢|會省|能省|省嗎|便宜|總價',text)),
        'cooperation':bool(re.search('合作|合夥|協作',text)),
        'wealth_network':cat=='金錢財運' or bool(re.search('財運|有錢|進帳|收入|賺錢',text)),
        'wealth_timing':(cat=='金錢財運' or bool(re.search('財運|有錢|進帳|收入|賺錢',text))) and bool(re.search('何時|什麼時候|多久|幾時|時機',text)),
        'venture_action':bool(re.search('開業|創業|開店|踏出|第一步|開始行動|投入',text)),
        'retirement_blessing':bool(re.search('退休|好命|享福|福氣|無憂.*生活',text)),
        'romantic_relationship':cat=='感情' or bool(re.search('伴侶|交往|男朋友|女朋友|戀人|夫妻',text)),
        'career':work or bool(re.search('求職|離職|找工作|上班|職業|事業|就業',text)),
        'difficulty':bool(re.search('關卡|困難|手術|難關|難題|引流|平安|過關',text)),
        'faith_difficulty':bool(re.search('關卡|困難|手術|難關|引流',text)) and bool(re.search('信仰|宗教|祈福|祝禱|神祇|廟宇|信佛|信主|基督徒|佛教徒',text)) and not bool(re.search('沒[有有任何]*信仰|無宗教|不信教|沒有宗教',text)),
        'checkup_or_pass':bool(re.search('體檢|過關|合格',text)),
        'finance':cat=='金錢財運' or bool(re.search('投資|股票|期貨|財運|投機',text)),
        'promotion_network':work and bool(re.search('推廣|銷售|產品|拓展|陌生|新領域|人脈|資源',text)),
        'communication':bool(re.search('溝通|合作|往來|夥伴|人際|討論|相處|說話|同事|朋友|家人|伴侶',text)) or cat=='家庭人際',
        'learning_work_strain':(work or bool(re.search('學|讀書|考試|all.pass',text,re.I))) and bool(re.search('壓力|焦慮|恐慌|延畢|出錯|錯誤|注意力|精神|累|熬夜|睡|倦怠|用功',text)),
        'work_burnout':work and bool(re.search('倦怠|心累|悶|疲|累',text)),
        'family':bool(re.search('家運|家庭運|家裡|家中|家人',text)),
        'work_attention':work and not project,
        'project_acceptance':project,
    }.get(scope, False)

def question_focus(q, is_health):
    """Routing hints, not facts or answer templates; retain multiple explicit intents."""
    text=q.get('question_text','')
    patterns=[('能否長久','一輩子|長久|白頭|一生'),('原因','原因|為什麼|病因'),
              ('隱憂','隱憂|隱患'),('選擇','選擇|哪個|哪一個|哪一年|何者|比較|較好'),
              ('時間','何時|什麼時候|多久|這禮拜|這週|月底|年底|之前|以前'),
              ('結果','會不會|能否|能不能|可不可以|可以.*嗎|會.*嗎|是否|能.*嗎'),
              ('建議','建議|注意|怎麼辦|如何做'),('現況','目前|現況|狀況|如何')]
    intents=[label for label,pattern in patterns if re.search(pattern,text)]
    if not intents:intents=['依原問句判斷']
    focus={'intents':intents,'instruction':'依實際問句選擇回答焦點；多問意分別回應，不把路由提示當作已知事實。'}
    if '能否長久' in intents:
        focus['instruction']='先回答長期發展傾向，再以星性說明影響長久的因素與條件；不可套用相處隱憂題的答案結構，不保證結果。'
    elif '隱憂' in intents:
        focus['instruction']='先辨識目前相處隱憂、注意事項與建議；未提供的衝突只能條件式提醒，不補故事。'
    methods=bool(re.search('如何|怎麼做|怎樣',text)) and not bool(re.search('運勢如何|財運如何|狀況如何',text))
    if methods and '建議' not in intents:intents.append('建議')
    priorities=[('方法',methods),('原因','原因' in intents),('比較','選擇' in intents),('時間','時間' in intents),('結果','結果' in intents)]
    focus['primary_intent']=next((label for label,matched in priorities if matched),'依原問句判斷')
    focus['answer_order']=['先回答問題','說明牌面依據','補充條件、風險與解方']
    focus['instruction']+=' 如何／怎麼做先給具體方向；為什麼先答原因；會不會先答傾向；時間題先答有據的時機或條件，不虛構日期；比較題先比較，依據不足明示限制，不編造優劣。多問意逐項回答。'
    if is_health:
        organ=bool(re.search('(具體|哪[個些]|什麼).*(臟[腑府]|器官)|牌面.*(臟[腑府]|器官)',text))
        body=organ or bool(re.search('哪[個些裡].*(部位|問題)|什麼病|疾病來源|病因|身體部位|健康弱點|為什麼|原因|源頭',text))
        recovery=bool(re.search('恢復|痊癒|康復|休養|休息|會好|好起來|能好',text))
        focus['health_intents']=(['疾病／部位或病因'] if body else [])+(['恢復時間／能否痊癒／結果'] if recovery else [])
        if not focus['health_intents']:focus['health_intents']=['依原問句辨識結果或注意事項']
        focus['body_topics_allowed']=body or not recovery
        focus['explicit_organ_question']=organ
        if organ:
            focus['instruction']+=' 明確詢問具體臟腑時，先回答抽中單星已確認的牌義照顧方向，再說明這不是醫療確診或病因確診；不得以整體評估取代牌義回答。'
        focus['instruction']+=' 健康題先辨識疾病／部位、病因、結果、恢復時間、能否痊癒、注意事項；已知疾病的恢復題先答恢復傾向與期限限制，不另推論疾病來源或身體部位；不診斷、不保證。'
    return focus

def enhance_context(context):
    q=context['question'];health=load_health()
    names=['紫微','天機','太陽','武曲','天同','廉貞','天府','太陰','貪狼','巨門','天相','天梁','七殺','破軍','空宮']
    name=dict((f'main_{i+1:02}',n) for i,n in enumerate(names))[q['drawn_card']]
    is_health=health_question(q,health)
    focus=question_focus(q,is_health)
    context['question_focus']=focus
    rules=[]
    for r in context['rules']:
        if r.get('context_scope') and not scope_matches(r['context_scope'],q):continue
        # A legacy category must not invent a work problem in a panic question.
        if (r.get('id')=='TLIANG-REVERSED-WORK-20261006-v1'
                and scope_matches('panic_action',q)
                and not re.search('工作|職場|職務|主管|同事|專案|上班|部屬',q.get('question_text',''))):continue
        # Project only explicitly attributed shared knowledge; keep the source
        # archive intact. Unknown pair records are not safe single-star input.
        if r.get('relationship')=='對星' or isinstance(r.get('star'),list):
            if is_health:continue
            if r.get('id')=='SUN-MOON-PAIR-20260927-v1' and name in ('太陽','太陰'):
                brightness=r['brightness'][name][q['orientation']]
                rules.append({'id':'SINGLE-'+name+'-BRIGHTNESS-20261007-v1','star':name,
                    'structured_points':[name+'本次亮度：'+brightness,'保留亮度軸；只依抽中單星核心判讀'],
                    'source_rule_id':r['id']})
            continue
        # No pair or other-star rule can enter a health context, including future pairs.
        owner=r.get('star',r.get('star_name',r.get('card_name')))
        if is_health and owner is not None and owner != name:continue
        if is_health and (r.get('relationship')=='對星' or r.get('health_topics')):continue
        rules.append(r)
    if is_health:
        for r in health['rules']:
            if r['star']==name and r['approval_status']=='approved':
                selected={k:v for k,v in r.items() if k not in ('source','approval_status','context_branches')}
                if not focus['body_topics_allowed']:
                    selected={k:v for k,v in selected.items() if k not in ('health_topics','elements','teacher_associations')}
                    selected['selection_note']='恢復題不載入未被詢問的部位／疾病清單；母資料完整保留。'
                if '恢復時間／能否痊癒／結果' not in focus['health_intents']:
                    selected.pop('recovery_guidance',None)
                rules.append(selected)
                for branch in r.get('context_branches',[]):
                    if branch.get('approval_status')!='approved':continue
                    if q['orientation'] not in branch['orientation_applicability']:continue
                    if not focus['body_topics_allowed']:continue
                    if not scope_matches(branch['context_scope'],q):continue
                    rules.append({k:v for k,v in branch.items() if k not in ('source','approval_status')})
        # Reference answers can contain health extrapolations: do not feed them into health readings.
        context['reference_cases']=[]
    else:
        context['reference_cases']=[c for c in context['reference_cases'] if c['case_id']!='TLIANG-APPROVED-20260927-V4' or scope_matches('project_acceptance',q)]
    context['rules']=rules
    from review_20261013 import supplement_context
    from review_20261014 import supplement_context as supplement_latest
    return supplement_latest(supplement_context(context))
