import io
import json
import tempfile
import threading
import unittest
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import backend
import hosting
from public_experience import PublicHosting, Rejected, TZ, FULL


class PublicTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)/'synthetic'
        self.now=datetime(2026,10,23,12,tzinfo=TZ).timestamp()
        hosting.bootstrap(self.root,'synthetic',False)
        self.app=self.open()
        self.token,self.owner=self.app.new_visitor()
        self.network=patch('urllib.request.OpenerDirector.open',side_effect=AssertionError('network forbidden'))
        self.network.start()

    def open(self,cap=10):
        return PublicHosting(self.root,'synthetic','http://127.0.0.1:8790','x'*40,
            production=False,accepting=True,mode='mock',clock=lambda:self.now,daily_visitors=cap)

    def tearDown(self):
        self.network.stop();self.app.close();self.tmp.cleanup()

    def q(self,parent=None,empty=False,text='目前工作的發展方向？',cid=None):
        return dict(consultation_id=cid or str(uuid.uuid4()),question_category='工作事業',
                    question_text=text,drawn_card='main_15' if empty else 'main_03',
                    orientation='orientation-independent' if empty else 'upright',parent_id=parent)

    def complete(self,owner=None,**kw):
        if kw.get('parent') and not kw.get('cid'):
            kw['cid']=self.app.start_followup(owner or self.owner,kw['parent'])['cid']
        q=self.q(**kw);status,result=self.app.consultation(owner or self.owner,q)
        self.assertEqual(status,200);self.assertEqual(result['delivery_status'],'complete')
        return q

    def request(self,path='/',method='GET',data=None,token=None,csrf=None,origin=None):
        token=self.token if token is None else token
        raw=json.dumps(data or {}).encode()
        env={'PATH_INFO':path.partition('?')[0],'QUERY_STRING':path.partition('?')[2],
             'REQUEST_METHOD':method,'HTTP_HOST':self.app.host,'HTTP_ORIGIN':origin or self.app.origin,
             'HTTP_COOKIE':'flower_visitor='+token,'HTTP_X_CSRF_TOKEN':csrf if csrf is not None else self.app.mac('csrf:'+token),
             'CONTENT_LENGTH':str(len(raw)),'CONTENT_TYPE':'application/json','wsgi.input':io.BytesIO(raw)}
        result={}
        def start(status,headers):result.update(status=int(status.split()[0]),headers=headers)
        result['body']=b''.join(self.app(env,start));return result

    def test_ten_people_second_right_and_third_denied(self):
        first=self.complete()
        for _ in range(9):self.complete(self.app.new_visitor()[1])
        other=self.app.new_visitor()[1]
        with self.assertRaises(Rejected) as exc:self.app.consultation(other,self.q())
        self.assertEqual(exc.exception.payload['error'],FULL)
        self.complete(parent=first['consultation_id'],text='我可以如何準備下一步的合作？')
        with self.assertRaises(Rejected):self.app.consultation(self.owner,self.q())
        self.assertEqual(self.app.db.execute("SELECT count(distinct owner) FROM public_rounds WHERE state='complete'").fetchone()[0],10)

    def test_first_context_and_new_card_and_duplicate_replay(self):
        first=self.complete()
        captured=[]
        def transport(context):captured.append(context);return backend.mock_request(context)
        self.app.svc.transport=transport
        start=self.app.start_followup(self.owner,first['consultation_id'])
        q=self.q(parent=first['consultation_id'],cid=start['cid'],text='如何改善與合作夥伴的分工？');q['drawn_card']='main_01'
        self.app.consultation(self.owner,q);self.app.consultation(self.owner,q)
        self.assertEqual(len(captured),1)
        self.assertEqual(captured[0]['question']['drawn_card'],'main_01')
        self.assertEqual(captured[0]['followup_context']['first_question']['drawn_card'],'main_03')
        self.assertIn('first_interpretation',captured[0]['followup_context'])

    def test_same_question_foreign_parent_and_extra_fields(self):
        first=self.complete()
        for q in (self.q(parent=first['consultation_id'],text='目前 工作 的發展方向！'),self.q(parent=str(uuid.uuid4()),text='合作要注意什麼')):
            with self.assertRaises(Rejected):self.app.consultation(self.owner,q)
        other=self.app.new_visitor()[1]
        with self.assertRaises(Rejected):self.app.consultation(other,self.q(parent=first['consultation_id']))
        q=self.q();q['followup_context']={'invented':'context'}
        self.assertEqual(self.request('/api/consult','POST',q)['status'],400)

    def test_empty_both_rounds_same_id_no_extra_attempt(self):
        q=self.q(empty=True)
        self.app.consultation(self.owner,q)
        self.assertEqual(self.app.db.execute('SELECT sum(attempted) FROM public_rounds').fetchone()[0],0)
        with self.assertRaises(Rejected):self.app.consultation(self.owner,self.q(cid=q['consultation_id']))
        self.now+=181
        self.complete(cid=q['consultation_id'])
        start=self.app.start_followup(self.owner,q['consultation_id'])
        q2=self.q(parent=q['consultation_id'],cid=start['cid'],empty=True,text='如何提升我與同事的溝通？')
        self.app.consultation(self.owner,q2);self.now+=181
        self.complete(parent=q['consultation_id'],text=q2['question_text'],cid=q2['consultation_id'])
        self.assertEqual(self.app.db.execute('SELECT count(*),sum(attempted) FROM public_rounds').fetchone()[:],(2,2))
        self.assertEqual(self.app.db.execute('SELECT count(*) FROM public_empty_draws').fetchone()[0],2)

    def test_day_reset_and_old_parent_rejected(self):
        first=self.complete();self.now+=86400
        with self.assertRaises(Rejected):self.app.consultation(self.owner,self.q(parent=first['consultation_id'],text='接著怎麼做？'))
        self.complete()
        self.assertEqual(self.app.db.execute('SELECT count(distinct day) FROM public_rounds').fetchone()[0],2)

    def test_midnight_started_result_is_delivered_and_counted_on_start_day(self):
        first=self.complete()
        self.now=datetime(2026,10,23,23,59,tzinfo=TZ).timestamp()
        start=self.app.start_followup(self.owner,first['consultation_id'])
        def late(context):self.now+=121;return backend.mock_request(context)
        self.app.svc.transport=late
        q=self.q(parent=first['consultation_id'],cid=start['cid'],text='下一步如何分工？');self.app.consultation(self.owner,q)
        row=self.app.db.execute('SELECT state,day FROM public_rounds WHERE cid=?',(q['consultation_id'],)).fetchone()
        self.assertEqual(tuple(row),('complete','2026-10-23'))
        self.assertEqual(self.app.saved_result(self.owner,q['consultation_id'])['result']['delivery_status'],'complete')

    def test_failure_not_complete_no_retry_budget_protects_second(self):
        self.app.close();self.app=self.open(cap=2)
        first=self.complete()
        def fail(context):raise TimeoutError('synthetic failure')
        self.app.svc.transport=fail
        other=self.app.new_visitor()[1];q=self.q()
        self.app.consultation(other,q);self.app.consultation(other,q)
        self.assertEqual(self.app.db.execute('SELECT sum(attempted) FROM public_rounds').fetchone()[0],2)
        with self.assertRaises(Rejected) as exc:self.app.consultation(self.app.new_visitor()[1],self.q())
        self.assertEqual(exc.exception.payload['code'],'COST_PAUSED')
        self.app.svc.transport=None
        self.complete(parent=first['consultation_id'],text='怎樣準備下一場會議？')

    def test_concurrent_last_slot_independent_connections(self):
        self.app.close();self.app=self.open(cap=1)
        peers=[self.open(cap=1) for _ in range(7)]
        owners=[a.new_visitor()[1] for a in peers]
        barrier=threading.Barrier(len(peers))
        def run(pair):
            a,owner=pair;barrier.wait()
            try:return a.consultation(owner,self.q())[0]
            except Rejected:return 429
        try:
            with ThreadPoolExecutor(max_workers=7) as pool:results=list(pool.map(run,zip(peers,owners)))
            self.assertEqual(results.count(200),1)
            self.assertEqual(self.app.db.execute("SELECT count(*) FROM public_rounds WHERE ordinal=1 AND state='complete'").fetchone()[0],1)
        finally:
            for a in peers:a.close()

    def test_restart_saved_result_feedback_and_reconciliation(self):
        first=self.complete()
        self.app.svc.feedback(self.owner,{'consultation_id':first['consultation_id'],'feedback_status':'很貼近','feedback_text':'合成回饋'})
        self.app.db.execute("UPDATE public_rounds SET state='reserved' WHERE cid=?",(first['consultation_id'],));self.app.db.commit()
        self.app.close();self.app=self.open()
        self.assertEqual(self.app.saved_result(self.owner,first['consultation_id'])['result']['delivery_status'],'complete')
        self.assertEqual(self.app.svc.db.execute('SELECT feedback_text FROM consultations').fetchone()[0],'合成回饋')
        self.assertEqual(self.app.session(self.token),self.owner)

    def test_unknown_never_released_by_timeout_or_restart(self):
        def crash(*args,**kwargs):raise RuntimeError('crash')
        self.app.svc.consult=crash
        q=self.q()
        with self.assertRaises(RuntimeError):self.app.consultation(self.owner,q)
        self.now+=600;self.app.close();self.app=self.open()
        self.assertEqual(self.app.db.execute('SELECT state FROM public_rounds').fetchone()[0],'unknown')
        with self.assertRaises(Rejected):self.app.consultation(self.owner,self.q())
        self.assertEqual(self.app.consultation(self.owner,q)[1]['api_status'],'unknown')

    def test_http_identity_security_and_record_ownership(self):
        anonymous=self.request('/api/session',token='')
        cookie=next(v for k,v in anonymous['headers'] if k=='Set-Cookie')
        self.assertIn('HttpOnly',cookie);self.assertIn('SameSite=Strict',cookie)
        self.assertNotIn('action="/enter"',self.request('/')['body'].decode())
        self.assertEqual(self.request('/api/consult','POST',self.q(),csrf='bad')['status'],403)
        self.assertEqual(self.request('/api/consult','POST',self.q(),origin='https://wrong.invalid')['status'],403)
        first=self.complete();other_token,_=self.app.new_visitor()
        self.assertEqual(self.request('/api/consultation?id='+first['consultation_id'],token=other_token)['status'],404)
        self.assertEqual(self.request('/../backend.py')['status'],404)
        started=json.loads(self.request('/api/followup/start','POST',{'parent_id':first['consultation_id']})['body'])['started_followup']
        self.assertEqual(self.request('/api/consult','POST',self.q(parent=first['consultation_id'],cid=started['cid'],text='下一步如何準備？'))['status'],200)

    def test_production_paid_rejected_and_parameter_validated(self):
        with self.assertRaises(ValueError):PublicHosting(self.root,'synthetic','https://example.invalid','x'*40,production=True,mode='live')
        with self.assertRaises(ValueError):self.open(cap=0)

    def test_existing_anonymous_handoff_event_route(self):
        response=self.request('/api/handoff-events','POST',{'flow_id':str(uuid.uuid4()),'event':'teacher_clicked'},token='')
        self.assertEqual(response['status'],200)
        self.assertEqual(json.loads(response['body']),{'ok':True})


if __name__=='__main__':unittest.main()
