"""Best-effort, secret-free /enter diagnostics; never change an auth decision."""
import hashlib
import hmac
import json
import re
import unicodedata
import uuid
from datetime import datetime, timezone, timedelta

import beta_policy


def begin(secret, clock, env):
    if env.get('PATH_INFO') != '/enter' or env.get('REQUEST_METHOD') != 'POST':
        return None
    try:
        ua = env.get('HTTP_USER_AGENT', '').lower()
        browser = ('line' if 'line/' in ua else 'edge' if 'edg/' in ua else
                   'chrome' if 'chrome/' in ua or 'crios/' in ua else
                   'safari' if 'safari/' in ua else 'other')
        content_type = env.get('CONTENT_TYPE', '').split(';')[0].lower().strip()
        event = {
            'event': 'invite_validation', 'schema': 1, 'request_id': uuid.uuid4().hex,
            'time_taipei': datetime.fromtimestamp(clock(), timezone(timedelta(hours=8))).isoformat(),
            'stage': 'host', 'reason': 'host_rejected',
            'browser': browser, 'line_webview': browser == 'line',
            'session_cookie_present': bool(re.search(r'(?:^|;)\s*flower_session\s*=', env.get('HTTP_COOKIE', ''))),
            'content_type': content_type if content_type in (
                'application/x-www-form-urlencoded', 'application/json', 'multipart/form-data', 'text/plain') else 'other',
        }
        key = hmac.new(secret, b'flower-invite-diagnostics:v1', hashlib.sha256).digest()
        return {'fields': event, 'key': key}
    except Exception:
        return None


def note(event, **fields):
    if event is not None:
        event['fields'].update(fields)


def capture_input(event, data):
    if event is None:
        return
    try:
        values = data.get('invite', [])
        value = values[0] if values else ''
        stripped = value.strip()
        identify = lambda s: hmac.new(event['key'], s.encode(), hashlib.sha256).hexdigest()
        note(event, invite_hmac=identify(stripped), input_hmac=identify(value),
             invite_field_count=len(values), input_length=len(value), normalized_length=len(stripped),
             outer_whitespace=value != stripped, has_newline='\r' in value or '\n' in value,
             internal_whitespace=any(c.isspace() for c in stripped),
             has_invisible=any(unicodedata.category(c) in ('Cc', 'Cf') for c in value),
             non_ascii=not value.isascii())
    except Exception:
        note(event, input_diagnostics='unavailable')


def lookup(event, app, code, invite, rejected):
    """Read-only enrichment AFTER the existing authorization decision."""
    if event is None:
        return
    note(event, stage='invite_lookup' if invite is None else 'allowed',
         reason='invite_rejected_unclassified' if rejected else 'qualified')
    try:
        row = invite if invite is not None else app.db.execute(
            'SELECT * FROM invites WHERE code_hash=?', (hashlib.sha256(code.encode()).hexdigest(),)).fetchone()
        if row is None:
            note(event, reason='hash_not_found')
            return
        expired = row['expires'] <= app.clock()
        note(event, revoked=bool(row['revoked']), expired=expired)
        if rejected:
            reason = ('not_allowed' if invite is not None else 'revoked' if row['revoked'] else
                      'expired' if expired else 'qualification_changed_or_unknown')
            note(event, reason=reason)
        label = app.db.execute('SELECT label FROM beta_invitations WHERE invite_id=?', (row['id'],)).fetchone()
        # Do not let free-form database labels become a secret/PII logging channel.
        if label and re.fullmatch(r'\d{4}-\d{2}-\d{2}-\d{2,4}', label[0]):
            note(event, invite_label=label[0])
        with app.svc.lock:
            note(event, usage_state=beta_policy.state(app.db, app.svc.db, row['id']))
    except Exception:
        note(event, lookup_diagnostics='unavailable')


def emit(fields):
    print(json.dumps(fields, ensure_ascii=True, separators=(',', ':')), flush=True)


def finish(event, status):
    if event is None:
        return
    try:
        # Only fields (not the derived HMAC key) ever reach the log sink.
        note(event, status=status)
        emit(event['fields'])
    except Exception:
        pass  # Logging failure must not alter the original HTTP response.
