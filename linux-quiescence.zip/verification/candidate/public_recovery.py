"""Compatible drain entry: preserve public identity, records and admitted rounds.

This intentionally retains the public schema/API rather than starting legacy
Hosting, whose startup rewrites processing records. Live still needs approvals.
"""
from public_entry import create_app as normal_app

def create_app():
    app=normal_app()
    app.recovery_drain=True
    return app
