"""Completion entitlements, separate from immutable model-attempt history.

Legacy charges are grandfathered, never reclassified or refunded by migration.
Only requests explicitly reserved under this policy enter the new state machine.
"""
import json


def migrate(db):
    db.execute('''CREATE TABLE IF NOT EXISTS beta_completion (
        cid TEXT PRIMARY KEY, cohort TEXT NOT NULL, state TEXT NOT NULL,
        reserved REAL NOT NULL, finished REAL, failure_code TEXT)''')
    db.commit()


def exists(db):
    return bool(db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='beta_completion'").fetchone())


def student_used(db, reservations=False):
    if not exists(db):
        return db.execute('SELECT count(*) FROM student_paid_attempts').fetchone()[0]
    legacy = db.execute('''SELECT count(*) FROM student_paid_attempts p
        WHERE NOT EXISTS(SELECT 1 FROM beta_completion b WHERE b.cid=p.cid)''').fetchone()[0]
    states = "('complete','reserved')" if reservations else "('complete')"
    return legacy + db.execute("SELECT count(*) FROM beta_completion WHERE cohort='student' AND state IN " + states).fetchone()[0]


def capacity_predicate():
    return "(charged=1 OR cid IN (SELECT cid FROM beta_completion WHERE state='reserved'))"


def reserve(db, cid, cohort, now):
    db.execute('INSERT INTO beta_completion VALUES(?,?,?, ?,NULL,NULL)', (cid, cohort, 'reserved', now))


def finish(db, records, cid, result, now):
    """Called in the host transaction, after durable answer save; never on replay."""
    import backend
    saved = records.execute('SELECT * FROM consultations WHERE consultation_id=?', (cid,)).fetchone()
    durable = json.loads(saved['response_json'] or '{}') if saved else {}
    complete = bool(saved and backend.saved_complete(saved)
                    and durable.get('delivery_status') == 'complete'
                    and result.get('delivery_status') == 'complete'
                    and not result.get('recovered_from_saved'))
    code = result.get('failure_code') or ('delivery_preparation_failed' if not complete else None)
    changed = db.execute("UPDATE beta_completion SET state=?,finished=?,failure_code=? WHERE cid=? AND state='reserved'",
                         ('complete' if complete else 'failed', now, code, cid)).rowcount
    if changed:
        db.execute('UPDATE requests SET charged=? WHERE cid=?', (int(complete), cid))
    return complete
