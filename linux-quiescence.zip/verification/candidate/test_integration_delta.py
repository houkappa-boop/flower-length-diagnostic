import base64, json, os, sqlite3, uuid
from unittest.mock import patch
from test_public_experience import PublicTests
import forum_handoff as f

class Integration(PublicTests):
    def setUp(self):
        super().setUp()
        p=patch.dict(os.environ,{'FLOWER_FORUM_HANDOFF_ENABLED':'true',
            'FLOWER_CHALLENGE_KEYRING':json.dumps({'active':'c1','keys':{'c1':base64.b64encode(b'c'*32).decode()}}),
            'FLOWER_SIGNING_KEYRING':json.dumps({'active':'s1','keys':{'s1':base64.b64encode(b's'*32).decode()}})})
        p.start();self.addCleanup(p.stop)

    def packet(self):
        q=self.complete();flow=str(uuid.uuid4())
        c={'tx':str(uuid.uuid4()),'flow':flow,'source':f.SOURCE,'destination':f.DESTINATION,'audience':f.AUDIENCE,'until':int(self.now)+300}
        return {'consultation_id':q['consultation_id'],'challenge':f.sign(c,f.keyring('CHALLENGE')),
            'draft':{'version':2,'flow':flow,'token':str(uuid.uuid4()),'expires':int(self.now+7200)*1000,
                     'draft':{'subject':'合成草稿','body':'原問題、星曜、解牌、評價、回饋及補充'}}}

    def snapshot(self):
        # HTTP abuse throttling is expected; quota/result/history rows must not change.
        return ('\n'.join(x for x in self.app.db.iterdump() if not x.startswith('INSERT INTO "attempts"')),'\n'.join(self.app.svc.db.iterdump()))

    def test_signed_handoff_at_limit_and_halt_preserves_data(self):
        packet=self.packet();self.complete(parent=packet['consultation_id'],text='延伸準備方向？')
        from public_ops import set_control
        set_control(self.root,'halt');before=self.snapshot()
        with patch.object(self.app.svc,'consult',side_effect=AssertionError('no AI')):
            r=self.request('/api/forum-handoff','POST',packet)
        self.assertEqual(r['status'],200)
        envelope=f.verify(json.loads(r['body'])['envelope'],f.keyring('SIGNING'))
        self.assertEqual(envelope['draft'],packet['draft'])
        self.assertEqual(self.snapshot(),before)

    def test_csrf_owner_signature_and_destination_rejected(self):
        packet=self.packet()
        for kw in [{'csrf':'bad'},{'origin':'https://evil.invalid'},{'token':self.app.new_visitor()[0]},{'token':'unknown'}]:
            self.assertEqual(self.request('/api/forum-handoff','POST',packet,**kw)['status'],403)
        good=packet['challenge'];packet['challenge']+='x'
        self.assertEqual(self.request('/api/forum-handoff','POST',packet)['status'],403)
        c=f.verify(good,f.keyring('CHALLENGE'));c['destination']='https://evil.invalid'
        packet['challenge']=f.sign(c,f.keyring('CHALLENGE'))
        self.assertEqual(self.request('/api/forum-handoff','POST',packet)['status'],403)

    def test_verified_legacy_link_only_and_revocation(self):
        packet=self.packet();cid=packet['consultation_id']
        legacy,code=self.app.invite()
        self.app.svc.db.execute('UPDATE consultations SET session_id=? WHERE consultation_id=?',(legacy,cid));self.app.svc.db.commit()
        self.assertEqual(self.request('/api/forum-handoff','POST',packet)['status'],403)
        self.assertEqual(self.request('/api/legacy-link','POST',{'invite':code})['status'],200)
        before=self.snapshot()
        self.assertEqual(self.request('/api/forum-handoff','POST',packet)['status'],200)
        self.assertEqual(self.snapshot(),before)
        self.app.db.execute('UPDATE invites SET revoked=1 WHERE id=?',(legacy,));self.app.db.commit()
        self.assertEqual(self.request('/api/forum-handoff','POST',packet)['status'],403)

    def test_expiry_rotation_and_receipt(self):
        packet=self.packet();r=self.request('/api/forum-handoff','POST',packet);self.assertEqual(r['status'],200)
        envelope=json.loads(r['body'])['envelope'];ring=f.keyring('SIGNING')
        self.assertEqual(f.verify(envelope,('s2',dict(ring[1],s2=b'n'*32)))['draft'],packet['draft'])
        with self.assertRaises(ValueError):f.verify(envelope,('s1',{'s1':b'w'*32}))
        self.now+=120;packet['draft']['expires']+=120000
        c=f.verify(packet['challenge'],f.keyring('CHALLENGE'));c['until']=int(self.now)+300;packet['challenge']=f.sign(c,f.keyring('CHALLENGE'))
        r=self.request('/api/forum-handoff','POST',packet)
        self.assertEqual(f.verify(json.loads(r['body'])['envelope'],ring)['draft']['expires'],packet['draft']['expires']-120000)
        self.now+=7201;c['until']=int(self.now)+300;packet['challenge']=f.sign(c,f.keyring('CHALLENGE'));packet['draft']['expires']=int(self.now+7200)*1000
        self.assertEqual(self.request('/api/forum-handoff','POST',packet)['status'],403)

    def test_feedback_recovery_isolated_no_other_changes(self):
        packet=self.packet();cid=packet['consultation_id']
        before=dict(self.app.svc.db.execute('SELECT * FROM consultations WHERE consultation_id=?',(cid,)).fetchone())
        for rating in ['很貼近','部分貼近','不太貼近']:
            r=self.request('/api/feedback','POST',{'consultation_id':cid,'feedback_status':rating,'feedback_text':'合成回饋'})
            self.assertEqual(r['status'],200)
            saved=json.loads(self.request('/api/consultation?id='+cid)['body'])
            self.assertEqual(saved['feedback'],{'consultation_id':cid,'status':rating,'text':'合成回饋'})
        after=dict(self.app.svc.db.execute('SELECT * FROM consultations WHERE consultation_id=?',(cid,)).fetchone())
        self.assertEqual({k:v for k,v in before.items() if not k.startswith('feedback_')},{k:v for k,v in after.items() if not k.startswith('feedback_')})
        self.assertEqual(self.request('/api/consultation?id='+cid,token=self.app.new_visitor()[0])['status'],404)

    def test_large_draft_return_csp_disabled(self):
        packet=self.packet();packet['draft']['draft']['body']='合成完整內容'*3000
        self.assertEqual(self.request('/api/forum-handoff','POST',packet)['status'],200)
        page=self.request('/');self.assertIn(b'forum-post.js',page['body'])
        self.assertIn("form-action 'self' https://anitahou.com",dict(page['headers'])['Content-Security-Policy'])
        self.assertEqual(self.request('/handoff-return')['status'],200)
        os.environ['FLOWER_FORUM_HANDOFF_ENABLED']='false'
        self.assertFalse(json.loads(self.request('/api/session')['body'])['forum_handoff_enabled'])
        self.assertEqual(self.request('/api/forum-handoff','POST',packet)['status'],503)
        self.assertEqual(self.request('/handoff-return')['status'],404)

    def test_receipt_in_encrypted_backup_restore(self):
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        import public_backup
        packet=self.packet();self.assertEqual(self.request('/api/forum-handoff','POST',packet)['status'],200)
        # All synthetic. Explicitly quiesce this isolated service before snapshot.
        db=sqlite3.connect(self.root/'handoff-events.sqlite3');db.execute('CREATE TABLE IF NOT EXISTS synthetic(x)');db.close()
        self.app.close()
        k=rsa.generate_private_key(public_exponent=65537,key_size=3072)
        pub=k.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
        pri=k.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
        archive=self.root.parent/'synthetic.enc';restored=self.root.parent/'restored'
        public_backup.backup(self.root,pub,archive);public_backup.restore(archive,pri,restored)
        db=sqlite3.connect(restored/'forum-handoff.sqlite3')
        try:
            self.assertEqual(db.execute('SELECT flow,expires FROM flow_receipts').fetchone(),(packet['draft']['flow'],packet['draft']['expires']//1000))
        finally:db.close()
        self.app=self.open()
