"""Candidate offline backup format; adds the event DB and retains legacy restore support.

Caller must stop writers or hold the deployment's exclusive io.lock. Not exposed
by HTTP and not invoked against production by the preview or tests.
"""
import base64
import hashlib
import io
import json
import os
import time
import math
from pathlib import Path
import secrets
import sqlite3
import tempfile
import zipfile
from contextlib import closing
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import operations

FILES={'records/consultations.sqlite3','access/access.sqlite3','handoff-events.sqlite3'}
OPTIONAL_FILES={'public-handoff-events.sqlite3','forum-handoff.sqlite3','volume-id'}
FORMAT='flower-backup-v2'

def backup(root,public_pem,destination,*,timeout=60):
    if not math.isfinite(timeout) or not 0 < timeout <= 60:
        raise ValueError('backup timeout must be within 60 seconds')
    end=time.monotonic()+timeout
    def budget(*unused):
        if time.monotonic()>=end:raise TimeoutError('backup deadline exceeded')
    root=Path(root)
    key=serialization.load_pem_public_key(public_pem)
    if not isinstance(key,rsa.RSAPublicKey) or key.key_size<3072:raise ValueError('backup key too small')
    archive=io.BytesIO();manifest={}
    with tempfile.TemporaryDirectory() as temp,zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for rel in sorted(FILES|{f for f in OPTIONAL_FILES if (root/f).is_file()}):
            budget()
            if rel=='volume-id':
                data=(root/rel).read_bytes();manifest[rel]=hashlib.sha256(data).hexdigest();z.writestr(rel,data)
                continue
            with closing(sqlite3.connect((root/rel).as_uri()+'?mode=ro',uri=True,timeout=1)) as source:
                target=Path(temp)/Path(rel).name
                out=sqlite3.connect(target)
                try:
                    source.backup(out,pages=128,progress=budget,sleep=.01)
                    if out.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('integrity')
                finally:out.close()
            data=target.read_bytes();manifest[rel]=hashlib.sha256(data).hexdigest();z.writestr(rel,data)
        z.writestr('manifest.json',json.dumps({'files':manifest}))
    budget()
    aes=AESGCM.generate_key(bit_length=256);nonce=secrets.token_bytes(12)
    wrapped=key.encrypt(aes,padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),algorithm=hashes.SHA256(),label=None))
    item={'format':FORMAT,'key':base64.b64encode(wrapped).decode(),'nonce':base64.b64encode(nonce).decode(),
          'data':base64.b64encode(AESGCM(aes).encrypt(nonce,archive.getvalue(),FORMAT.encode())).decode()}
    encoded=json.dumps(item).encode()
    budget()
    created=False
    try:
        fd=os.open(destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        created=True
        with os.fdopen(fd,'wb') as f:
            f.write(encoded);f.flush();os.fsync(f.fileno())
        budget()
    except BaseException:
        if created:Path(destination).unlink(missing_ok=True)
        raise
    return hashlib.sha256(encoded).hexdigest()

def restore(backup_file,private_pem,destination):
    dst=Path(destination)
    if dst.exists():raise ValueError('restore destination must not exist')
    item=json.loads(Path(backup_file).read_bytes())
    if item['format']=='flower-backup-v1':return operations.restore(backup_file,private_pem,dst)
    if item['format']!=FORMAT:raise ValueError('unknown format')
    key=serialization.load_pem_private_key(private_pem,password=None).decrypt(base64.b64decode(item['key']),
        padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),algorithm=hashes.SHA256(),label=None))
    plain=AESGCM(key).decrypt(base64.b64decode(item['nonce']),base64.b64decode(item['data']),FORMAT.encode())
    with zipfile.ZipFile(io.BytesIO(plain)) as z:
        manifest=json.loads(z.read('manifest.json'))['files']
        names=set(manifest)
        if not FILES<=names<=FILES|OPTIONAL_FILES or set(z.namelist())!=names|{'manifest.json'} or len(z.namelist())!=len(names)+1:raise ValueError('invalid manifest')
        for rel in names:
            if hashlib.sha256(z.read(rel)).hexdigest()!=manifest[rel]:raise ValueError('checksum mismatch')
        dst.mkdir(parents=True)
        for rel in names:
            target=dst/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(rel))
            if rel=='volume-id':continue
            db=sqlite3.connect(target)
            try:
                if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('integrity')
            finally:db.close()
