"""私人操作入口：不啟動正式 Service、不呼叫模型，邀請碼不輸出至服務日誌。"""
import argparse
import json
import os
import sqlite3
import time
from pathlib import Path
import beta_policy
import maintenance


def main():
    p = argparse.ArgumentParser(description='花房每日新碼管理')
    p.add_argument('action', choices=['report', 'issue'])
    p.add_argument('--date')
    p.add_argument('--source', default='待標記', choices=['待標記','一般體驗者','前期學生'])
    args = p.parse_args()
    root = Path('/var/data/flower')
    import hosting
    hosting.check_volume(root, os.environ['EXPECTED_VOLUME_ID'])
    import fcntl
    with maintenance.writer(root), (root/'io.lock').open('a+b') as guard:
        fcntl.flock(guard, fcntl.LOCK_EX)
        mode = 'rw' if args.action == 'issue' else 'ro'
        with sqlite3.connect((root/'access/access.sqlite3').as_uri()+'?mode='+mode, uri=True) as db, sqlite3.connect((root/'records/consultations.sqlite3').as_uri()+'?mode=ro', uri=True) as records:
            records.row_factory = sqlite3.Row
            if args.action == 'report':
                print(json.dumps(beta_policy.report(db, records), ensure_ascii=False))
                return
            if not args.date: p.error('請提供適用日期')
            result = beta_policy.issue(db, records, args.date, time.time(), args.source)
            result['入口'] = os.environ['PUBLIC_ORIGIN']
            outdir = root/'invitations'
            outdir.mkdir(mode=0o700, exist_ok=True)
            target = outdir/(args.date+'.json')
            temporary = outdir/(args.date+'.tmp')
            fd = os.open(temporary, os.O_WRONLY|os.O_CREAT|os.O_TRUNC, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
                f.flush(); os.fsync(f.fileno())
            os.replace(temporary, target)
            print('私人交付檔：'+str(target))
            print('適用日期：'+args.date+'；可用數量：'+str(result['數量']))


if __name__ == '__main__': main()
