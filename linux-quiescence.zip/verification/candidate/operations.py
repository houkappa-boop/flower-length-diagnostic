"""Operator-only bootstrap, invitation and encrypted consistent backup commands.

Not imported by the HTTP router. Never uploads data or invokes a model.
"""
import argparse
import base64
import hashlib
import io
import json
import os
import secrets
import sqlite3
import tempfile
import time
import zipfile
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import hosting
import maintenance


def backup(root, public_pem, destination):
    """Caller holds io.lock exclusively in production; snapshot both DBs."""
    root, destination = Path(root), Path(destination)
    key = serialization.load_pem_public_key(public_pem)
    if not isinstance(key,rsa.RSAPublicKey) or key.key_size < 3072:
        raise ValueError('RSA backup key must be at least 3072 bits')
    manifest = {}
    archive = io.BytesIO()
    with tempfile.TemporaryDirectory(dir=root/'backups') as temp:
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
            for rel in ('records/consultations.sqlite3','access/access.sqlite3'):
                source = sqlite3.connect((root/rel).as_uri()+'?mode=ro',uri=True)
                target = Path(temp)/Path(rel).name
                out = sqlite3.connect(target)
                try:
                    source.backup(out)
                    if out.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                        raise RuntimeError('backup integrity failed')
                finally:
                    out.close(); source.close()
                data = target.read_bytes()
                manifest[rel] = hashlib.sha256(data).hexdigest()
                z.writestr(rel,data)
            z.writestr('manifest.json',json.dumps({'created':time.time(),'files':manifest}))
    aes = AESGCM.generate_key(bit_length=256)
    nonce = secrets.token_bytes(12)
    envelope = key.encrypt(aes,padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),algorithm=hashes.SHA256(),label=None))
    body = AESGCM(aes).encrypt(nonce,archive.getvalue(),b'flower-backup-v1')
    encoded = json.dumps({'format':'flower-backup-v1','key':base64.b64encode(envelope).decode(), 'nonce':base64.b64encode(nonce).decode(),'data':base64.b64encode(body).decode()}).encode()
    with destination.open('xb') as f:
        f.write(encoded); f.flush(); os.fsync(f.fileno())
    return hashlib.sha256(encoded).hexdigest()


def restore(backup_file, private_pem, destination):
    """Offline only. Never replace or restore over a populated directory."""
    dst = Path(destination)
    if dst.exists():
        raise ValueError('restore destination must not exist')
    item = json.loads(Path(backup_file).read_bytes())
    if item['format'] != 'flower-backup-v1':
        raise ValueError('unknown format')
    private = serialization.load_pem_private_key(private_pem,password=None)
    key = private.decrypt(base64.b64decode(item['key']),padding.OAEP(mgf=padding.MGF1(hashes.SHA256()),algorithm=hashes.SHA256(),label=None))
    data = AESGCM(key).decrypt(base64.b64decode(item['nonce']),base64.b64decode(item['data']),b'flower-backup-v1')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        manifest=json.loads(z.read('manifest.json'))
        expected={'records/consultations.sqlite3','access/access.sqlite3'}
        if set(manifest['files']) != expected or set(z.namelist()) != expected|{'manifest.json'}:
            raise ValueError('invalid manifest')
        for rel,checksum in manifest['files'].items():
            if hashlib.sha256(z.read(rel)).hexdigest()!=checksum:
                raise ValueError('hash mismatch')
        dst.mkdir(parents=True)
        for rel in expected:
            target=dst/rel;target.parent.mkdir(exist_ok=True)
            target.write_bytes(z.read(rel))
            db=sqlite3.connect(target)
            try:
                if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                    raise ValueError('restored integrity failed')
            finally:db.close()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['bootstrap','invite','revoke','backup'])
    parser.add_argument('--days',type=int,default=7)
    parser.add_argument('--invite-id')
    args=parser.parse_args()
    root=Path('/var/data/flower')
    expected=os.environ['EXPECTED_VOLUME_ID']
    if args.action=='backup':
        raise RuntimeError('Use public_ops backup for complete maintenance-controlled backup')
    if args.action=='bootstrap':
        hosting.bootstrap(root,expected)
        print('Initialized empty persistent databases. Disable BOOTSTRAP_PENDING and restart locked.')
        return
    hosting.check_volume(root,expected)
    # No Service is constructed by operator tasks: never mark running calls interrupted.
    import fcntl
    with maintenance.writer(root), (root/'io.lock').open('a+b') as guard:
        fcntl.flock(guard,fcntl.LOCK_EX)
        if args.action=='backup':
            public=os.environ['BACKUP_RECIPIENT'].encode()
            name=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+secrets.token_hex(3)+'.enc'
            checksum=backup(root,public,root/'backups'/name)
            print(json.dumps({'file':name,'sha256':checksum}))
            return
        db=hosting.database(root/'access/access.sqlite3')
        try:
            if args.action=='revoke':
                changed=db.execute('UPDATE invites SET revoked=1 WHERE id=?',(args.invite_id,)).rowcount
                db.commit();print(json.dumps({'revoked':changed}))
            else:
                if not 1<=args.days<=90:raise ValueError('expiry')
                code=secrets.token_urlsafe(32);ident=secrets.token_urlsafe(32)
                db.execute('INSERT INTO invites VALUES(?,?,?,0)',(ident,hosting.digest(code),time.time()+args.days*86400))
                db.commit()
                # Private operator terminal only; never application logs or a public route.
                print(json.dumps({'invite_id':ident,'invite_code':code,'expires_days':args.days}))
        finally:db.close()


if __name__=='__main__':main()
